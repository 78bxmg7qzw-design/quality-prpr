"""Unified cache for query embeddings and LLM relevance scores."""

from __future__ import annotations

import hashlib
from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F

from autoeval_lib.constants import Columns


class QueryCache:
    """Manages caching of query embeddings and LLM relevance scores.

    Provides a unified interface for caching both embeddings (for ANN/HYBRID
    searches) and LLM scores (for relevance evaluation). Uses a single Delta
    table to store both types of data, keyed by query hash.

    The cache table schema:
        - query_text: The original query text
        - query_hash: SHA-256 hash of index_name + query_text
        - query_embedding: Vector embedding (NULL for FULL_TEXT only queries)
        - rated_documents: Array of (doc_id, rating) pairs from LLM scoring

    Example:
        cache = QueryCache(
            index_name="catalog.schema.index",
            cache_table="catalog.schema.query_cache"
        )

        # Embedding operations
        cached_df, uncached_df = cache.get_cached_embeddings(queries_df, primary_key)
        cache.store_embeddings_batch(embeddings_df)

        # LLM score operations
        scores = cache.get_cached_scores_batch(["query1", "query2"])
        cache.store_scores_batch({"query1": {"doc1": 3.0}, "query2": {"doc2": 1.0}})
    """

    def __init__(self, index_name: str, cache_table: str):
        """Initialize the QueryCache.

        Args:
            index_name: Fully qualified index name (catalog.schema.index).
                Used in hash computation to ensure cache entries are specific
                to each index.
            cache_table: Fully qualified cache table name (catalog.schema.table).
        """
        self.spark = SparkSession.builder.getOrCreate()
        self.index_name = index_name
        self.cache_table = cache_table
        self._table_available: bool | None = None

    def ensure_table_exists(self) -> None:
        """Ensure the cache table exists, creating it if necessary.

        Uses CREATE TABLE IF NOT EXISTS for atomicity.

        Raises:
            ValueError: If table creation fails due to permissions or other errors.
        """
        if self._table_available:
            return

        try:
            self.spark.sql(f"""
                CREATE TABLE IF NOT EXISTS {self.cache_table} (
                    query_text STRING NOT NULL,
                    query_hash STRING NOT NULL,
                    query_embedding ARRAY<FLOAT>,
                    rated_documents ARRAY<STRUCT<doc_id: STRING, rating: FLOAT>>
                )
                USING DELTA
                COMMENT 'Unified cache table for query embeddings and LLM scores'
            """)
            self._table_available = True

        except Exception as e:
            error_msg = str(e).lower()
            if "permission" in error_msg or "denied" in error_msg or "access" in error_msg:
                raise ValueError(
                    f"Cannot create cache table '{self.cache_table}'. "
                    f"Ensure you have CREATE TABLE permission."
                ) from e
            raise ValueError(f"Failed to create cache table '{self.cache_table}': {e}") from e

    def compute_query_hash(self, query_text: str) -> str:
        """Compute SHA-256 hash of index name + query text.

        Including the index name ensures cache entries are specific to each
        index, since relevance scores depend on the documents in that index.

        Args:
            query_text: The query text to hash

        Returns:
            SHA-256 hash of index_name + query_text
        """
        combined = f"{self.index_name}:{query_text}"
        return hashlib.sha256(combined.encode('utf-8')).hexdigest()

    # -------------------------------------------------------------------------
    # Embedding cache operations
    # -------------------------------------------------------------------------

    def get_cached_embeddings(
        self,
        queries_df: DataFrame,
        primary_key: str
    ) -> tuple[DataFrame, DataFrame]:
        """Get cached embeddings and identify uncached queries.

        Args:
            queries_df: DataFrame with primary_key and 'generated_query' columns
            primary_key: Column name of the primary key in queries_df

        Returns:
            Tuple of (cached_df, uncached_df) where:
            - cached_df has columns: primary_key, generated_query, query_embedding
            - uncached_df has columns: primary_key, generated_query (queries not in cache)
        """
        self.ensure_table_exists()

        # Read cache table
        cache_df = self.spark.table(self.cache_table).select(
            F.col(Columns.QUERY_TEXT),
            F.col(Columns.QUERY_EMBEDDING)
        )

        # Join queries with cache
        queries_with_cache = queries_df.join(
            cache_df,
            queries_df[Columns.GENERATED_QUERY] == cache_df[Columns.QUERY_TEXT],
            "left"
        ).select(
            queries_df[primary_key],
            queries_df[Columns.GENERATED_QUERY],
            cache_df[Columns.QUERY_EMBEDDING]
        )

        # Split into cached and uncached
        cached_df = queries_with_cache.filter(F.col(Columns.QUERY_EMBEDDING).isNotNull())
        uncached_df = queries_with_cache.filter(F.col(Columns.QUERY_EMBEDDING).isNull()).select(
            primary_key, Columns.GENERATED_QUERY
        )

        return cached_df, uncached_df

    def store_embeddings_batch(self, embeddings_df: DataFrame) -> None:
        """Store embeddings in a single MERGE operation.

        Args:
            embeddings_df: DataFrame with 'generated_query' and 'query_embedding' columns
        """
        self.ensure_table_exists()

        try:

            # Collect data
            data = embeddings_df.select(Columns.GENERATED_QUERY, Columns.QUERY_EMBEDDING).collect()
            if not data:
                return

            # Build rows with query_hash
            rows = []
            for row in data:
                query_text = row[Columns.GENERATED_QUERY]
                query_hash = self.compute_query_hash(query_text)
                embedding = list(row[Columns.QUERY_EMBEDDING]) if row[Columns.QUERY_EMBEDDING] else None
                rows.append({
                    "query_text": query_text,
                    "query_hash": query_hash,
                    "query_embedding": embedding
                })

            if not rows:
                return

            # Create DataFrame with explicit schema
            from pyspark.sql.types import StructType, StructField, StringType, FloatType, ArrayType

            schema = StructType([
                StructField("query_text", StringType(), False),
                StructField("query_hash", StringType(), False),
                StructField("query_embedding", ArrayType(FloatType()), True)
            ])

            updates_df = self.spark.createDataFrame(rows, schema)

            # Single MERGE using temp view
            temp_view_name = f"_embedding_updates_{id(updates_df)}"
            updates_df.createOrReplaceTempView(temp_view_name)

            try:
                # Use unconditional SET - if embedding model changed, we want the latest
                self.spark.sql(f"""
                    MERGE INTO {self.cache_table} AS target
                    USING {temp_view_name} AS source
                    ON target.query_hash = source.query_hash
                    WHEN MATCHED THEN
                        UPDATE SET query_embedding = source.query_embedding
                    WHEN NOT MATCHED THEN
                        INSERT (query_text, query_hash, query_embedding)
                        VALUES (source.query_text, source.query_hash, source.query_embedding)
                """)
            finally:
                self.spark.catalog.dropTempView(temp_view_name)

        except Exception as e:
            print(f"Warning: Failed to batch cache embeddings: {e}")

    # -------------------------------------------------------------------------
    # LLM score cache operations
    # -------------------------------------------------------------------------

    def get_cached_scores_batch(self, query_texts: list[str]) -> dict[str, dict[str, float]]:
        """Get cached LLM scores for multiple queries in a single SQL call.

        Args:
            query_texts: List of query texts to look up

        Returns:
            Dict mapping query_text -> {doc_id -> rating}
        """
        if not query_texts:
            return {}

        self.ensure_table_exists()

        try:

            # Build mapping of hash -> query_text for reverse lookup
            hash_to_query: dict[str, str] = {}
            for query_text in query_texts:
                query_hash = self.compute_query_hash(query_text)
                hash_to_query[query_hash] = query_text

            if not hash_to_query:
                return {}

            # Single SQL query with IN clause
            hash_list = ", ".join(f"'{h}'" for h in hash_to_query.keys())
            result = self.spark.sql(f"""
                SELECT query_hash, rated_documents
                FROM {self.cache_table}
                WHERE query_hash IN ({hash_list})
            """).collect()

            # Build result dict
            scores_by_query: dict[str, dict[str, float]] = {}
            for row in result:
                query_hash = row.query_hash
                query_text = hash_to_query.get(query_hash)
                if query_text and row.rated_documents:
                    scores_by_query[query_text] = {
                        item.doc_id: item.rating for item in row.rated_documents
                    }

            return scores_by_query

        except Exception as e:
            print(f"Warning: Failed to batch read cached scores: {e}")
            return {}

    def store_scores_batch(self, scores_by_query: dict[str, dict[str, float]]) -> None:
        """Store all scores in a single MERGE operation.

        Args:
            scores_by_query: Dict mapping query_text -> {doc_id -> rating}
        """
        if not scores_by_query:
            return

        self.ensure_table_exists()

        try:

            # Build rows for the updates DataFrame
            rows = []
            for query_text, doc_scores in scores_by_query.items():
                if not doc_scores:
                    continue
                query_hash = self.compute_query_hash(query_text)
                rated_docs = [{"doc_id": str(doc_id), "rating": float(rating)}
                              for doc_id, rating in doc_scores.items()]
                rows.append({
                    "query_text": query_text,
                    "query_hash": query_hash,
                    "rated_documents": rated_docs
                })

            if not rows:
                return

            # Create DataFrame with explicit schema to avoid type inference issues
            from pyspark.sql.types import StructType, StructField, StringType, FloatType, ArrayType

            rated_doc_schema = ArrayType(StructType([
                StructField("doc_id", StringType(), False),
                StructField("rating", FloatType(), False)
            ]))

            schema = StructType([
                StructField("query_text", StringType(), False),
                StructField("query_hash", StringType(), False),
                StructField("rated_documents", rated_doc_schema, True)
            ])

            updates_df = self.spark.createDataFrame(rows, schema)

            # Single MERGE using temp view
            temp_view_name = f"_cache_updates_{id(updates_df)}"
            updates_df.createOrReplaceTempView(temp_view_name)

            try:
                # Define the array type for consistent casting
                array_type = "ARRAY<STRUCT<doc_id: STRING, rating: FLOAT>>"

                # Note: array_union removes exact duplicates but allows the same doc_id
                # with different ratings. In practice, cache hits prevent re-scoring,
                # so duplicate doc_ids are rare.
                self.spark.sql(f"""
                    MERGE INTO {self.cache_table} AS target
                    USING {temp_view_name} AS source
                    ON target.query_hash = source.query_hash
                    WHEN MATCHED THEN
                        UPDATE SET
                            rated_documents = array_union(
                                COALESCE(target.rated_documents, CAST(ARRAY() AS {array_type})),
                                source.rated_documents
                            )
                    WHEN NOT MATCHED THEN
                        INSERT (query_text, query_hash, rated_documents)
                        VALUES (source.query_text, source.query_hash, source.rated_documents)
                """)
            finally:
                self.spark.catalog.dropTempView(temp_view_name)

        except Exception as e:
            print(f"Warning: Failed to batch cache scores: {e}")
