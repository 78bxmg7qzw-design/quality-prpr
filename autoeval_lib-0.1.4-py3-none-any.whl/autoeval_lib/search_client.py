"""Vector search client wrapper for batch queries."""

from __future__ import annotations

from typing import Any
from pyspark.sql import SparkSession, DataFrame, Row
from tqdm import tqdm
from databricks.vector_search.client import VectorSearchClient

from autoeval_lib.query_cache import QueryCache
from autoeval_lib.constants import Columns, QueryType, APIKeys


class SearchClient:
    """Client for executing batch vector search queries.

    Wraps the Databricks VectorSearchClient to provide batch query
    functionality with progress tracking.

    Example:
        client = SearchClient("my_endpoint", "my_catalog.my_schema.my_index", "doc_id")
        results_df = client.search_batch(
            queries_df=queries_df,
            columns=["doc_id", "title", "text"],
            num_results=10,
            query_type="FULL_TEXT"
        )
    """

    def __init__(self, endpoint_name: str, index_name: str, primary_key: str):
        """Initialize the SearchClient.

        Args:
            endpoint_name: Vector search endpoint name
            index_name: Fully qualified index name (catalog.schema.index)
            primary_key: Primary key column name for the index
        """
        self.endpoint_name = endpoint_name
        self.index_name = index_name
        self.primary_key = primary_key
        self.spark = SparkSession.builder.getOrCreate()
        self.vsc = VectorSearchClient(disable_notice=True)
        self.index = self.vsc.get_index(
            endpoint_name=endpoint_name,
            index_name=index_name
        )

    def search_batch(
        self,
        queries_df: DataFrame,
        columns: list[str],
        num_results: int = 10,
        query_type: str = QueryType.FULL_TEXT,
        embedding_model: str | None = None,
        query_cache_table: str = "",
        reranker: Any | None = None
    ) -> DataFrame:
        """Execute batch searches for all queries.

        Args:
            queries_df: DataFrame with primary_key and 'generated_query' columns.
            columns: Columns to retrieve. Primary key column is always included.
            num_results: Number of results to fetch per query
            query_type: Search type - "FULL_TEXT", "ANN", or "HYBRID"
            embedding_model: Model endpoint for generating query embeddings (required for ANN/HYBRID
                if index is self-managed). If not specified, attempts to get from index status.
            query_cache_table: Table to cache query embeddings. Format: "catalog.schema.table".
                Embeddings are cached/retrieved from this table.
            reranker: Optional DatabricksReranker instance for reranking results.
                Example: DatabricksReranker(columns_to_rerank=["text", "title"])

        Returns:
            DataFrame with columns: original_doc_id, query, result_rank, retrieved_doc_id,
                                   retrieved_text, search_score
        """
        if query_type.lower() not in QueryType.VALID_LOWERCASE:
            raise ValueError(f"query_type must be one of {QueryType.ALL}, got '{query_type}'")

        primary_key = self.primary_key

        if primary_key not in columns:
            columns = [primary_key] + list(columns)

        # For ANN/HYBRID, we need embeddings
        use_embeddings = query_type in (QueryType.ANN, QueryType.HYBRID)
        query_embeddings_map = {}

        if use_embeddings:
            # Resolve embedding model
            resolved_model = self._resolve_embedding_model(embedding_model)
            print(f"Using embedding model: {resolved_model}")

            # Get embeddings (with caching if specified)
            embeddings_df = self._get_query_embeddings(
                queries_df, resolved_model, query_cache_table, primary_key
            )

            # Collect embeddings into a map for lookup
            for row in embeddings_df.collect():
                query_embeddings_map[row[Columns.GENERATED_QUERY]] = row[Columns.QUERY_EMBEDDING]

        queries_data = queries_df.collect()
        all_results = []

        for query_row in tqdm(queries_data, desc=f"Searching ({query_type})"):
            query_text = query_row[Columns.GENERATED_QUERY]
            original_doc_id = query_row[primary_key]

            try:
                if use_embeddings:
                    # Use query_vector for ANN/HYBRID searches
                    query_embedding = query_embeddings_map.get(query_text)
                    if query_embedding is None:
                        print(f"  Warning: No embedding found for query '{query_text[:50]}...'")
                        continue

                    # Pass query_text for HYBRID, or when reranker is enabled (reranker needs text)
                    include_query_text = query_type == QueryType.HYBRID or reranker is not None
                    search_results = self.index.similarity_search(
                        query_vector=list(query_embedding),
                        query_text=query_text if include_query_text else None,
                        query_type=query_type,
                        columns=columns,
                        num_results=num_results,
                        disable_notice=True,
                        reranker=reranker
                    )
                else:
                    # Use query_text for FULL_TEXT searches
                    search_results = self.index.similarity_search(
                        query_text=query_text,
                        query_type=query_type,
                        columns=columns,
                        num_results=num_results,
                        disable_notice=True,
                        reranker=reranker
                    )

                # Parse results
                if search_results and APIKeys.RESULT in search_results:
                    data_array = search_results[APIKeys.RESULT].get(APIKeys.DATA_ARRAY, [])
                    # Build column index map: columns are returned in order, score is last
                    col_idx = {col: i for i, col in enumerate(columns)}

                    for rank, result_row in enumerate(data_array, start=1):
                        # Get primary key (first column)
                        retrieved_doc_id = result_row[col_idx[primary_key]] if primary_key in col_idx else None

                        # Get text content - use first non-primary-key column as retrieved_text
                        # This handles both single and multiple query columns
                        text_columns = [c for c in columns if c != primary_key]
                        if text_columns:
                            text_parts = []
                            for text_col in text_columns:
                                if text_col in col_idx:
                                    val = result_row[col_idx[text_col]]
                                    if val is not None:
                                        text_parts.append(str(val))
                            retrieved_text = " ".join(text_parts) if text_parts else ""
                        else:
                            retrieved_text = ""

                        # Score is always the last element
                        search_score = result_row[-1] if len(result_row) > len(columns) else 0.0

                        all_results.append({
                            Columns.ORIGINAL_DOC_ID: original_doc_id,
                            Columns.QUERY: query_text,
                            Columns.RESULT_RANK: rank,
                            Columns.RETRIEVED_DOC_ID: retrieved_doc_id,
                            Columns.RETRIEVED_TEXT: retrieved_text,
                            Columns.SEARCH_SCORE: search_score
                        })

            except (RuntimeError, ValueError, KeyError) as e:
                # RuntimeError: API/network errors from Vector Search client
                # ValueError: Invalid response format
                # KeyError: Missing expected fields in response
                print(f"  Error searching for query '{query_text[:50]}...': {e}")

        print(f"Search complete! Retrieved {len(all_results)} results.")

        return self.spark.createDataFrame([Row(**r) for r in all_results])

    def _resolve_embedding_model(self, embedding_model: str | None) -> str:
        """Resolve the embedding model to use.

        If embedding_model is provided, use it. Otherwise, attempt to get it
        from the index status (for managed embedding indexes).

        Args:
            embedding_model: User-provided embedding model, or None

        Returns:
            The embedding model endpoint name to use

        Raises:
            ValueError: If no embedding model provided and index is self-managed
        """
        if embedding_model:
            return embedding_model

        # Try to get embedding model from index status
        try:
            index_status = self.index.describe()
            # Check for embedding_model in delta_sync_index_spec
            delta_sync_spec = index_status.get(APIKeys.DELTA_SYNC_INDEX_SPEC, {})
            model_from_spec = delta_sync_spec.get(APIKeys.EMBEDDING_SOURCE_COLUMNS, [{}])
            if model_from_spec and len(model_from_spec) > 0:
                embedding_model_name = model_from_spec[0].get(APIKeys.EMBEDDING_MODEL_ENDPOINT_NAME)
                if embedding_model_name:
                    return embedding_model_name
        except (RuntimeError, KeyError, TypeError) as e:
            # RuntimeError: API errors from index.describe()
            # KeyError: Missing fields in index configuration
            # TypeError: Unexpected response structure
            print(f"Warning: Could not get index status: {e}")

        raise ValueError(
            "No embedding_model specified and index appears to be self-managed "
            "(no embedding model found in index configuration). "
            "Please specify the embedding_model parameter for ANN/HYBRID queries."
        )

    def _generate_embeddings(
        self,
        queries_df: DataFrame,
        embedding_model: str,
        primary_key: str
    ) -> DataFrame:
        """Generate embeddings for queries using ai_query.

        Args:
            queries_df: DataFrame with primary_key and 'generated_query' columns
            embedding_model: Model endpoint for embedding generation
            primary_key: Column name of the primary key in queries_df

        Returns:
            DataFrame with columns: primary_key, generated_query, query_embedding
        """
        # Register as temp view for SQL
        temp_view_name = f"_autoeval_queries_{id(queries_df)}"
        queries_df.createOrReplaceTempView(temp_view_name)

        try:
            result_df = self.spark.sql(f"""
                SELECT
                    `{primary_key}`,
                    {Columns.GENERATED_QUERY},
                    ai_query(
                        '{embedding_model}',
                        {Columns.GENERATED_QUERY}
                    ) as {Columns.QUERY_EMBEDDING}
                FROM {temp_view_name}
            """)
            # Force materialization before dropping temp view to avoid lazy evaluation issues
            # This ensures the SQL query executes while the temp view still exists
            materialized_data = result_df.collect()
            return self.spark.createDataFrame(materialized_data)
        finally:
            self.spark.catalog.dropTempView(temp_view_name)

    def _get_query_embeddings(
        self,
        queries_df: DataFrame,
        embedding_model: str,
        cache_table: str,
        primary_key: str
    ) -> DataFrame:
        """Get embeddings for all queries, using cache.

        Args:
            queries_df: DataFrame with primary_key and 'generated_query' columns
            embedding_model: Model endpoint for embedding generation
            cache_table: Cache table name
            primary_key: Column name of the primary key in queries_df

        Returns:
            DataFrame with columns: primary_key, generated_query, query_embedding
        """
        cache = QueryCache(self.index_name, cache_table)

        # Get cached and uncached queries
        cached_df, uncached_df = cache.get_cached_embeddings(queries_df, primary_key)

        cached_count = cached_df.count()
        uncached_count = uncached_df.count()

        if cached_count > 0:
            print(f"Found {cached_count} cached embeddings")

        if uncached_count > 0:
            print(f"Generating {uncached_count} new embeddings...")

            # Generate embeddings for uncached queries
            new_embeddings_df = self._generate_embeddings(uncached_df, embedding_model, primary_key)

            # Cache the new embeddings (batch operation for efficiency)
            cache.store_embeddings_batch(new_embeddings_df)

            # Union cached and new embeddings
            return cached_df.union(new_embeddings_df)
        else:
            return cached_df

