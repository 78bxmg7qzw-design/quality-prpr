"""Prompt templates for query generation and relevance scoring."""

from __future__ import annotations

# Default few-shot examples for query generation
DEFAULT_FEW_SHOT_EXAMPLES = [
    {
        "document": "Antibiotics fight bacterial infections by killing bacteria or stopping their growth. They are ineffective against viral infections like the common cold or flu.",
        "query": "what do antibiotics do"
    },
    {
        "document": "Wag the Dog is a 1997 black comedy film produced and directed by Barry Levinson. The screenplay by Hilary Henkin and David Mamet was loosely adapted from Larry Beinhart's novel American Hero. The film stars Dustin Hoffman and Robert De Niro, with Anne Heche, Denis Leary, and William H. Macy in supporting roles.",
        "query": "who wrote the screenplay for wag the dog"
    },
    {
        "document": "Machine learning algorithms can be supervised or unsupervised. Supervised learning uses labeled data to train models, while unsupervised learning finds patterns in unlabeled data.",
        "query": "machine learning algorithms"
    },
    {
        "document": "Since sarcopenia has no single cause, its prevention and treatment require an integrated approach that incorporates dietary strategies, hormone replacement, nutritional supplementation, and exercise. Sarcopenia is the age-related loss of muscle mass, strength, and functionality. It generally appears after the age of 40 and accelerates after the age of approximately 75.",
        "query": "sarcopenia age"
    },
]


QUERY_GENERATION_BASE_PROMPT_NATURAL = """You are a search query generator. Given a document's 
text content, generate a concise search query (1-15 words) that someone would likely use to 
find this document.

Guidelines:
- Generate natural language queries (e.g., "what is lyme disease", "how do antibiotics work")
- Queries should be about information contained in the document
- Queries can be about the main topic or secondary topics, as long as the document contains a relevant answer
- If it doesn't make sense to generate a query from a document, output "None"

"""

QUERY_GENERATION_BASE_PROMPT_KEYWORD = """You are a search query generator. Given a document's text
content, generate a concise keyword-style search query (1-10 words) that someone would 
likely use to find this document. 

Guidelines:
- Generate keyword-style queries (e.g., "lyme disease symptoms", "antibiotic mechanism")
- Focus on key terms and concepts from the document
- Queries can be about the main topic or secondary topics, as long as the document contains a relevant answer
- If it doesn't make sense to generate a query from a document, output "None"

"""


RELEVANCE_SCORING_PROMPT = """You are a relevance judge for search results. Given a search query 
and a retrieved document, rate how relevant the document is to answering the query.

Use this scale:
3 - Highly Relevant: Document directly answers the query or provides exactly the information sought
2 - Relevant: Document is related and provides useful information, but may not fully answer the query
1 - Partially Relevant: Document mentions the topic but doesn't provide useful information for the query
0 - Not Relevant: Document is unrelated to the query

Respond with ONLY the number (0, 1, 2, or 3).

Query: {query}
Document: {document}

Relevance Score:"""


def build_query_generation_prompt(
    doc_text: str,
    few_shot_examples: list[dict[str, str]],
    style: str = "natural"
) -> str:
    """Build a complete query generation prompt with few-shot examples.

    Args:
        doc_text: The document text to generate a query for
        few_shot_examples: List of {"document": ..., "query": ...} examples
        style: "natural" for natural language queries, "keyword" for keyword-style

    Returns:
        Complete prompt string for ai_gen()
    """
    if style == "keyword":
        base_prompt = QUERY_GENERATION_BASE_PROMPT_KEYWORD
    else:
        base_prompt = QUERY_GENERATION_BASE_PROMPT_NATURAL

    prompt = base_prompt + "Examples:\n"

    for example in few_shot_examples:
        doc = _clean_text(example["document"])
        query = example["query"]
        prompt += f'Document: "{doc}"\nQuery: {query}\n\n'

    # Add the target document
    clean_doc = _clean_text(doc_text)
    prompt += f'Document: "{clean_doc}"\nQuery:'

    return prompt


def build_relevance_scoring_prompt(query: str, document: str) -> str:
    """Build a relevance scoring prompt.

    Args:
        query: The search query
        document: The retrieved document text

    Returns:
        Complete prompt string for ai_gen()
    """
    clean_query = _clean_text(query)
    clean_doc = _clean_text(document)

    return RELEVANCE_SCORING_PROMPT.format(query=clean_query, document=clean_doc)


def _clean_text(text: str) -> str:
    """Clean text for safe embedding in prompts.

    Removes quotes and newlines to prevent them from breaking prompt structure,
    since prompts use quotes as delimiters around document content.

    Args:
        text: Raw text string

    Returns:
        Cleaned text safe for prompt embedding

    Raises:
        TypeError: If text is not a string (and not None).
    """
    if text is None:
        return ""
    if not isinstance(text, str):
        raise TypeError(f"Expected text to be a string, but got {type(text).__name__}: {text!r}")
    return text.replace('"', '').replace("'", "").replace('\n', ' ').strip()
