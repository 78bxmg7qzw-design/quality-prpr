"""MLFlow integration for tracking autoeval results."""

from __future__ import annotations

import hashlib
import time
from typing import Any, TYPE_CHECKING
import mlflow
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from .metrics import MetricsAnalyzer
from .constants import MLflowTags, MLflowParams, Columns, TracingFields, Defaults

if TYPE_CHECKING:
    from .config import AutoEvalConfig
    from .evaluator import EvalResult


# Try to import Document class (requires MLflow 2.14.0+)
try:
    from mlflow.entities import Document
    MLFLOW_TRACING_AVAILABLE = True
except ImportError:
    Document = None
    MLFLOW_TRACING_AVAILABLE = False


def generate_experiment_path(index_name: str) -> str:
    """Generate a valid Databricks MLFlow experiment path.

    Creates an experiment path in format: /Users/$username/vs_autoeval_$hash
    where:
    - $username is from session_user() (e.g., "john.doe@databricks.com")
    - $hash is a short hash of (timestamp, username, index_name) for uniqueness

    Args:
        index_name: Name of the vector search index being evaluated

    Returns:
        Valid Databricks experiment path like "/Users/john.doe@databricks.com/vs_autoeval_a1b2c3"

    Example:
        >>> path = generate_experiment_path("my_catalog.my_schema.my_index")
        >>> # Returns something like "/Users/john.doe@databricks.com/vs_autoeval_a1b2c3d4"
    """
    # Get spark session
    spark = SparkSession.builder.getOrCreate()

    # Get username from Spark session
    result = spark.range(1).select(
        F.session_user().alias("username")
    ).collect()

    if not result or result[0]["username"] is None:
        raise RuntimeError(
            "Failed to get current user from Spark session. "
            "Ensure this is running in a Databricks environment."
        )
    username = result[0]["username"]

    # Generate short hash from timestamp + username + index_name
    timestamp = str(int(time.time()))
    hash_input = f"{timestamp}:{username}:{index_name}"
    short_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:8]

    # Construct the experiment path
    experiment_path = f"/Users/{username}/vs_autoeval_{short_hash}"

    return experiment_path


class MLFlowTracker:
    """Tracks autoeval results to MLFlow experiments.

    This class provides optional MLFlow integration for saving evaluation
    configurations, metrics, and detailed results to MLFlow experiments.

    Example:
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"]
        ).validate()

        tracker = MLFlowTracker(
            scored_df=scored_df,
            analyzer=analyzer,
            config=config,
            query_type="ANN",
            eval_queryset_size=200
        )
        run_id, experiment_id, trace_ids = tracker.log_to_mlflow()
    """

    def __init__(
        self,
        scored_df: DataFrame,
        analyzer: MetricsAnalyzer,
        config: AutoEvalConfig,
        query_type: str,
        eval_queryset_size: int,
        reranker_enabled: bool = False,
        experiment_path: str | None = None
    ):
        """Initialize tracker with evaluation results and config.

        Args:
            scored_df: DataFrame with llm_relevance_score column
            analyzer: MetricsAnalyzer instance with cached metrics
            config: AutoEvalConfig object (must be validated)
            query_type: The query type being evaluated (e.g., "ANN", "HYBRID")
            eval_queryset_size: Number of queries evaluated
            reranker_enabled: Whether reranker was used for this evaluation
            experiment_path: Optional experiment path to use. If provided, this
                takes precedence over config.mlflow_experiment_path and avoids
                calling generate_experiment_path(). Use this to ensure all runs
                from a single evaluation are logged to the same experiment.

        Raises:
            ValueError: If config is not validated
        """
        if not config.is_validated():
            raise ValueError("Config must be validated. Call config.validate() first.")

        self.scored_df = scored_df
        self.analyzer = analyzer
        self.config = config
        self.query_type = query_type
        self.eval_queryset_size = eval_queryset_size
        self.reranker_enabled = reranker_enabled
        self.experiment_path = (
            experiment_path or
            config.mlflow_experiment_path or
            generate_experiment_path(config.index_name)
        )

    def log_to_mlflow(
        self,
        run_name: str | None = None
    ) -> tuple[str, str, list[str]]:
        """Log evaluation to MLFlow.

        Args:
            run_name: Optional name for the MLFlow run

        Returns:
            Tuple of (run_id, experiment_id, trace_ids)
        """
        experiment_id = self._get_or_create_experiment(self.experiment_path)
        mlflow.set_experiment(experiment_id=experiment_id)

        with mlflow.start_run(run_name=run_name) as run:
            # Log all parameters, metrics, and artifacts
            self._log_parameters()
            self._log_metrics()
            self._log_artifacts()
            
            # Log per-query traces (only if tracing available)
            if MLFLOW_TRACING_AVAILABLE:
                trace_ids = self._log_per_query_traces()
            else:
                trace_ids = []

            return run.info.run_id, run.info.experiment_id, trace_ids

    def _get_or_create_experiment(self, name: str) -> str:
        """Get existing experiment or create new one.

        Args:
            name: Experiment name

        Returns:
            Experiment ID
        """
        experiment = mlflow.get_experiment_by_name(name=name)
        if experiment is None:
            experiment_id = mlflow.create_experiment(
                name=name,
                tags={
                    MLflowTags.PRODUCT: MLflowTags.PRODUCT_VALUE,
                    MLflowTags.TYPE: MLflowTags.TYPE_VALUE_AUTOEVAL
                }
            )
        else:
            experiment_id = experiment.experiment_id
        return experiment_id

    def _log_parameters(self):
        """Log all configuration parameters."""
        config = self.config
        mlflow.log_param(MLflowParams.ENDPOINT_NAME, config.endpoint_name)
        mlflow.log_param(MLflowParams.INDEX_NAME, config.index_name)
        mlflow.log_param(MLflowParams.CORPUS_TABLE, config.corpus_table)
        mlflow.log_param(MLflowParams.EVAL_QUERYSET_SIZE, self.eval_queryset_size)
        mlflow.log_param(MLflowParams.NUM_RESULTS, config.num_results)
        mlflow.log_param(MLflowParams.QUERY_STYLE, config.query_style)
        mlflow.log_param(MLflowParams.QUERY_COLUMNS, ",".join(config.query_columns))
        mlflow.log_param(MLflowParams.NUM_FEW_SHOT_EXAMPLES, len(config.few_shot_examples))
        mlflow.log_param(MLflowParams.QUERY_TYPE, self.query_type)
        mlflow.log_param(MLflowParams.RERANKER_ENABLED, self.reranker_enabled)
        # Optional params
        if config.random_seed is not None:
            mlflow.log_param(MLflowParams.RANDOM_SEED, config.random_seed)
        if self.reranker_enabled and config.columns_to_rerank:
            mlflow.log_param(MLflowParams.COLUMNS_TO_RERANK, ",".join(config.columns_to_rerank))

    def _log_metrics(self):
        """Log summary metrics with 95% confidence intervals."""
        analyzer = self.analyzer
        config = self.config

        # Get all metrics with CI, including @k metrics at all standard k values
        metrics = analyzer.get_metrics(k_values=config.k_values)

        # Log point estimates and CI margins
        for metric_name, (value, ci_margin) in metrics.items():
            mlflow.log_metric(metric_name, value)
            mlflow.log_metric(f"{metric_name}_ci", ci_margin)

    def _log_artifacts(self):
        """Log result artifacts.

        Logs 7 artifacts:
        - Few-shot examples
        - Score distribution
        - Top/bottom queries (10 each)
        - High/low relevance examples (10 each)
        - Full scored results
        """
        analyzer = self.analyzer
        config = self.config

        # Few-shot examples
        mlflow.log_dict(
            {"examples": config.few_shot_examples},
            "few_shot_examples.json"
        )

        # Score distribution
        mlflow.log_table(
            analyzer.score_distribution().toPandas(),
            "score_distribution.json"
        )

        # Top/bottom queries (10 each)
        mlflow.log_table(
            analyzer.top_queries(10).toPandas(),
            "top_queries.json"
        )
        mlflow.log_table(
            analyzer.bottom_queries(10).toPandas(),
            "bottom_queries.json"
        )

        # High/low relevance examples (10 each)
        mlflow.log_table(
            analyzer.high_relevance_examples(10).toPandas(),
            "high_relevance_examples.json"
        )
        mlflow.log_table(
            analyzer.low_relevance_examples(10).toPandas(),
            "low_relevance_examples.json"
        )

        # Full results
        mlflow.log_table(
            self.scored_df.toPandas(),
            "full_results.json"
        )

    def _log_per_query_traces(self) -> list[str]:
        """Log traces for all queries in the evaluation.

        Creates one trace per query using the @trace decorator. Each trace is
        a RETRIEVER span containing Document objects with search results and
        LLM relevance scores.

        Note:
            Trace ID retrieval uses mlflow.get_last_active_trace_id() which may
            not be available in older MLflow versions. In such cases, an empty
            list is returned but traces are still logged to MLflow.

        Returns:
            List of trace IDs for the logged traces (empty if MLflow version
            doesn't support trace ID retrieval)
        """
        # Group results by query
        rows = self.scored_df.collect()
        queries: dict[str, dict[str, Any]] = {}

        for row in rows:
            row_dict = row.asDict()
            query = row_dict.get(Columns.QUERY)
            original_doc_id = row_dict.get(Columns.ORIGINAL_DOC_ID)

            # Skip rows with missing required fields
            if query is None or original_doc_id is None:
                continue

            if query not in queries:
                queries[query] = {
                    Columns.ORIGINAL_DOC_ID: original_doc_id,
                    TracingFields.RESULTS: []
                }
            queries[query][TracingFields.RESULTS].append({
                Columns.RETRIEVED_DOC_ID: row_dict.get(Columns.RETRIEVED_DOC_ID),
                TracingFields.RANK: row_dict.get(Columns.RESULT_RANK),
                Columns.TITLE: row_dict.get(Columns.RETRIEVED_TITLE),
                Columns.TEXT_PREVIEW: row_dict.get(Columns.RETRIEVED_TEXT),
                Columns.SEARCH_SCORE: row_dict.get(Columns.SEARCH_SCORE) or 0,
                Columns.LLM_RELEVANCE_SCORE: row_dict.get(Columns.LLM_RELEVANCE_SCORE)
            })

        # Log trace for each query
        trace_ids = []
        warned_once = False
        for query_text, data in queries.items():
            original_doc_id = data[Columns.ORIGINAL_DOC_ID]
            results = sorted(data[TracingFields.RESULTS], key=lambda x: x[TracingFields.RANK])

            # Call traced function - creates one trace per query
            _trace_single_query(query_text, original_doc_id, self.query_type, results)

            # Get the trace ID (only works with MLflow 2.14.0+)
            try:
                trace_id = mlflow.get_last_active_trace_id()
                if trace_id:
                    trace_ids.append(trace_id)
            except AttributeError:
                # get_last_active_trace_id not available in older MLflow
                # Only log once to avoid spam
                if not warned_once:
                    print("Note: MLflow tracing API not available. Trace IDs will not be returned.")
                    warned_once = True

        return trace_ids


# =============================================================================
# Tracing Helper Functions (module-level for decorator support)
# =============================================================================


def _to_mlflow_document(result: dict[str, Any], original_doc_id: str):
    """Convert a result dict to MLflow Document for tracing.

    Args:
        result: Dictionary with result fields (from Columns/TracingFields constants)
        original_doc_id: The doc_id that generated the query (for recall check)

    Returns:
        MLflow Document with page_content and metadata, or dict if Document not available
    """
    truncate_limit = Defaults.TEXT_TRUNCATION_LIMIT

    retrieved_doc_id = result.get(Columns.RETRIEVED_DOC_ID)

    metadata = {
        "doc_id": retrieved_doc_id,
        "title": (result.get(Columns.TITLE) or "")[:truncate_limit],
        "rank": result.get(TracingFields.RANK),
        "search_score": result.get(Columns.SEARCH_SCORE, 0),
        "llm_relevance_score": result.get(Columns.LLM_RELEVANCE_SCORE),
        "original_doc_id": original_doc_id,
        # Type-safe comparison: cast both to string to handle int/string mismatches
        "is_recall_hit": str(retrieved_doc_id) == str(original_doc_id) if retrieved_doc_id is not None else False
    }

    page_content = (result.get(Columns.TEXT_PREVIEW) or "")[:truncate_limit]

    if MLFLOW_TRACING_AVAILABLE and Document is not None:
        return Document(page_content=page_content, metadata=metadata)
    else:
        # Fallback for older MLflow versions - return dict
        return {"page_content": page_content, "metadata": metadata}


def _trace_single_query(
    query_text: str,
    original_doc_id: str,
    query_type: str,
    results: list[dict[str, Any]]
) -> list[Any]:
    """Trace a single query's results.

    Each call creates one trace in MLflow (when tracing available).

    Args:
        query_text: The search query text
        original_doc_id: The doc_id that generated this query
        query_type: The search mode (FULL_TEXT, ANN, HYBRID)
        results: List of result dicts with TraceFields keys

    Returns:
        List of MLflow Document objects (or dicts) representing search results
    """
    return [_to_mlflow_document(r, original_doc_id) for r in results]


# Apply tracing decorator if available
if MLFLOW_TRACING_AVAILABLE:
    _trace_single_query = mlflow.trace(name="eval_query", span_type="RETRIEVER")(_trace_single_query)

