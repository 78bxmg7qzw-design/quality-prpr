"""Plotting utilities for visualizing evaluation metrics."""

from __future__ import annotations

from typing import TYPE_CHECKING

from autoeval_lib.constants import MetricType, PlotColors, PlotDataKeys, PlotLabels, PlotConfig

if TYPE_CHECKING:
    import plotly.graph_objects as go
    from .evaluator import EvalResult


def _get_k_colors(k_values: list[int]) -> dict[int, str]:
    """Generate color mapping for k values dynamically.

    Uses Plotly's default color palette, cycling if more k values than colors.

    Args:
        k_values: List of k values to assign colors to

    Returns:
        Dict mapping k value to hex color string
    """
    return {k: PlotColors.PLOTLY_PALETTE[i % len(PlotColors.PLOTLY_PALETTE)] for i, k in enumerate(k_values)}


def plot_metrics_at_k(
    results: dict[str, EvalResult],
    metric_type: str,
    k_values: list[int],
    title: str | None = None,
    y_range: tuple[float, float] | None = None
) -> go.Figure | None:
    """Plot metric@k comparison across query types with CI error bars.

    Args:
        results: Dict mapping query_type to EvalResult
        metric_type: One of "recall", "precision", "ndcg", "map", "dcg"
        k_values: k values to plot (required)
        title: Plot title (auto-generated if None)
        y_range: Y-axis range. Default: (-0.01, 1.01) for normalized metrics,
                 None (auto-scale) for DCG

    Returns:
        Plotly Figure object, or None if error
    """
    try:
        import plotly.graph_objects as go
    except ImportError:
        print("Error: plotly not installed. Run: pip install plotly")
        return None

    try:
        if not results:
            print(f"Error: No results to plot for {metric_type}.")
            return None

        # Get query types in consistent order
        query_types = list(results.keys())

        # Build data structure: {k: {QUERY_TYPES: [], VALUES: [], CI_MARGINS: []}}
        data_by_k: dict[int, dict[str, list]] = {
            k: {PlotDataKeys.QUERY_TYPES: [], PlotDataKeys.VALUES: [], PlotDataKeys.CI_MARGINS: []}
            for k in k_values
        }

        # Collect data for each query type and k value
        for query_type in query_types:
            result = results[query_type]
            for k in k_values:
                if metric_type == MetricType.RECALL:
                    val, ci = result.analyzer.recall_at_k(k=k)
                elif metric_type == MetricType.PRECISION:
                    val, ci = result.analyzer.precision_at_k(k=k)
                elif metric_type == MetricType.NDCG:
                    val, ci = result.analyzer.ndcg_at_k(k=k)
                elif metric_type == MetricType.MAP:
                    val, ci = result.analyzer.map_at_k(k=k)
                elif metric_type == MetricType.DCG:
                    val, ci = result.analyzer.dcg_at_k(k=k)
                else:
                    raise ValueError(f"Unknown metric_type: {metric_type}")

                data_by_k[k][PlotDataKeys.QUERY_TYPES].append(query_type)
                data_by_k[k][PlotDataKeys.VALUES].append(val)
                data_by_k[k][PlotDataKeys.CI_MARGINS].append(ci)

        k_colors = _get_k_colors(k_values)

        # Calculate jitter offsets for k values to spread them horizontally
        num_k = len(k_values)
        jitter_offsets = {
            k: (i - (num_k - 1) / 2) * (PlotConfig.JITTER_WIDTH / max(num_k - 1, 1))
            for i, k in enumerate(k_values)
        }

        fig = go.Figure()

        # Add trace for each k value with jittered x positions
        metric_label = MetricType.LABELS.get(metric_type, metric_type)
        prec = PlotConfig.DECIMAL_PRECISION
        for k in k_values:
            k_data = data_by_k[k]
            x_positions = [i + jitter_offsets[k] for i in range(len(k_data[PlotDataKeys.QUERY_TYPES]))]
            hover_labels = [f"{qt} {metric_label}@{k}" for qt in k_data[PlotDataKeys.QUERY_TYPES]]

            fig.add_trace(go.Scatter(
                x=x_positions,
                y=k_data[PlotDataKeys.VALUES],
                error_y=dict(
                    type="data",
                    symmetric=True,
                    array=k_data[PlotDataKeys.CI_MARGINS]
                ),
                mode="markers",
                marker=dict(size=PlotConfig.MARKER_SIZE, color=k_colors[k], opacity=PlotConfig.MARKER_OPACITY),
                name=f"@{k}",
                text=hover_labels,
                customdata=k_data[PlotDataKeys.CI_MARGINS],
                hovertemplate=f"%{{text}}: %{{y:.{prec}f}} ± %{{customdata:.{prec}f}}<extra></extra>"
            ))

        # Determine y_range: use provided value, or default based on metric type
        # Normalized metrics (recall, precision, ndcg, map) default to (0, 1)
        # Unnormalized metrics (dcg) default to auto-scale (None)
        if y_range is None:
            if metric_type == MetricType.DCG:
                effective_y_range = None  # Auto-scale for DCG
            else:
                effective_y_range = (-0.01, 1.01)  # Default for normalized metrics
        else:
            effective_y_range = y_range

        # Layout with custom x-axis labels
        layout_kwargs = dict(
            title=title or f"{metric_label}@k by {PlotLabels.QUERY_TYPE}",
            xaxis_title=PlotLabels.QUERY_TYPE,
            yaxis_title=f"{metric_label}@k",
            xaxis=dict(
                tickmode='array',
                tickvals=list(range(len(query_types))),
                ticktext=query_types
            ),
            legend_title=PlotLabels.K_VALUE,
            template="plotly_white"
        )
        if effective_y_range is not None:
            layout_kwargs["yaxis_range"] = list(effective_y_range)

        fig.update_layout(**layout_kwargs)

        return fig

    except Exception as e:
        print(f"Error generating {metric_type} plot: {e}")
        return None


def plot_mrr(
    results: dict[str, EvalResult],
    title: str | None = None,
    y_range: tuple[float, float] = (-0.01, 1.01)
) -> go.Figure | None:
    """Plot MRR comparison across query types with CI error bars.

    Args:
        results: Dict mapping query_type to EvalResult
        title: Plot title (auto-generated if None)
        y_range: Y-axis range (default: -0.01 to 1.01)

    Returns:
        Plotly Figure object, or None if error
    """
    try:
        import plotly.graph_objects as go
    except ImportError:
        print("Error: plotly not installed. Run: pip install plotly")
        return None

    # Define label before try block to ensure it's available in except handler
    mrr_label = MetricType.LABELS.get(MetricType.MRR, "MRR")

    try:
        if not results:
            print(f"Error: No results to plot for {mrr_label}.")
            return None

        # Collect MRR values
        query_types = []
        values = []
        ci_margins = []

        for query_type, result in results.items():
            val, ci = result.analyzer.mrr()
            query_types.append(query_type)
            values.append(val)
            ci_margins.append(ci)

        hover_labels = [f"{qt} {mrr_label}" for qt in query_types]
        prec = PlotConfig.DECIMAL_PRECISION

        fig = go.Figure()

        fig.add_trace(go.Scatter(
            x=query_types,
            y=values,
            error_y=dict(
                type="data",
                symmetric=True,
                array=ci_margins
            ),
            mode="markers",
            marker=dict(size=PlotConfig.MARKER_SIZE, color=PlotColors.MRR, opacity=PlotConfig.MARKER_OPACITY),
            name=mrr_label,
            text=hover_labels,
            customdata=ci_margins,
            hovertemplate=f"%{{text}}: %{{y:.{prec}f}} ± %{{customdata:.{prec}f}}<extra></extra>"
        ))

        fig.update_layout(
            title=title or f"{mrr_label} by {PlotLabels.QUERY_TYPE}",
            xaxis_title=PlotLabels.QUERY_TYPE,
            yaxis_title=MetricType.MRR_FULL_NAME,
            yaxis_range=list(y_range),
            template="plotly_white",
            showlegend=False
        )

        return fig

    except Exception as e:
        print(f"Error generating {mrr_label} plot: {e}")
        return None
