"""Centralized constants for AutoEval library.

This module provides a single source of truth for all string literals
used throughout the library, preventing subtle bugs from inconsistent
string usage across files.
"""

# Note: Literal type hints removed for Python 3.6 compatibility
# Type aliases are defined as comments for documentation purposes


# =============================================================================
# DataFrame Column Names
# =============================================================================

class Columns:
    """Standard column names used across DataFrames."""

    # Query-related columns
    QUERY = "query"
    GENERATED_QUERY = "generated_query"

    # Primary key column (DEPRECATED - use config.primary_key instead)
    # This is only used for internal pipeline DataFrames, not source table reads
    DOC_ID = "doc_id"

    # Search result columns (internal pipeline columns, not source table columns)
    # ORIGINAL_DOC_ID: Contains the value of the primary key for the doc that generated the query
    # RETRIEVED_DOC_ID: Contains the value of the primary key for retrieved docs
    ORIGINAL_DOC_ID = "original_doc_id"
    RETRIEVED_DOC_ID = "retrieved_doc_id"
    RETRIEVED_TEXT = "retrieved_text"
    RETRIEVED_TITLE = "retrieved_title"
    RESULT_RANK = "result_rank"
    SEARCH_SCORE = "search_score"

    # Scoring columns
    LLM_RELEVANCE_SCORE = "llm_relevance_score"
    RAW_SCORE = "raw_score"

    # Cache columns
    QUERY_TEXT = "query_text"
    QUERY_HASH = "query_hash"
    QUERY_EMBEDDING = "query_embedding"
    RATED_DOCUMENTS = "rated_documents"
    RATING = "rating"

    # Prompt column (for LLM scoring)
    PROMPT = "prompt"

    # Query generator working columns
    DOC_TEXT = "doc_text"
    SAMPLED_TEXT = "sampled_text"
    TEXT_PREVIEW = "text_preview"
    NATURAL_QUERY = "natural_query"
    KEYWORD_QUERY = "keyword_query"

    # Common source table columns (for defaults)
    TITLE = "title"
    TEXT = "text"
    SCORE = "score"


# =============================================================================
# Query Types and Styles
# =============================================================================

class QueryType:
    """Valid query type values for vector search."""
    FULL_TEXT = "FULL_TEXT"
    ANN = "ANN"
    HYBRID = "HYBRID"

    ALL = [FULL_TEXT, ANN, HYBRID]
    VALID_LOWERCASE = {"full_text", "ann", "hybrid"}


class QueryStyle:
    """Valid query style values for query generation."""
    NATURAL = "natural"
    KEYWORD = "keyword"
    MIXED = "mixed"

    ALL = [NATURAL, KEYWORD, MIXED]
    VALID = {NATURAL, KEYWORD, MIXED}


class MetricType:
    """Metric type identifiers and display labels."""

    # Metric identifiers (used as function parameters)
    RECALL = "recall"
    PRECISION = "precision"
    NDCG = "ndcg"
    DCG = "dcg"
    MAP = "map"
    MRR = "mrr"

    # All valid metric types for @k metrics
    ALL_AT_K = [RECALL, PRECISION, NDCG, DCG, MAP]

    # Display labels for UI
    LABELS = {
        "recall": "Recall",
        "precision": "Precision",
        "ndcg": "NDCG",
        "dcg": "DCG",
        "map": "MAP",
        "mrr": "MRR",
    }

    # Full display name for MRR
    MRR_FULL_NAME = "Mean Reciprocal Rank"


# Type aliases (for documentation - Literal not available in Python 3.6)
# QueryTypeValue = "FULL_TEXT" | "ANN" | "HYBRID"
# QueryStyleValue = "natural" | "keyword" | "mixed"


# =============================================================================
# API Response Keys
# =============================================================================

class APIKeys:
    """Keys used when parsing Vector Search API responses."""
    RESULT = "result"
    DATA_ARRAY = "data_array"

    # Index describe() response keys
    ENDPOINT_NAME = "endpoint_name"
    PRIMARY_KEY = "primary_key"
    STATUS = "status"
    READY = "ready"
    DETAILED_STATE = "detailed_state"
    DELTA_SYNC_INDEX_SPEC = "delta_sync_index_spec"
    SOURCE_TABLE = "source_table"
    EMBEDDING_SOURCE_COLUMNS = "embedding_source_columns"
    EMBEDDING_MODEL_ENDPOINT_NAME = "embedding_model_endpoint_name"


# =============================================================================
# MLflow Parameter and Metric Names
# =============================================================================

class MLflowParams:
    """Parameter names for MLflow logging."""
    ENDPOINT_NAME = "endpoint_name"
    INDEX_NAME = "index_name"
    CORPUS_TABLE = "corpus_table"
    EVAL_QUERYSET_SIZE = "eval_queryset_size"
    NUM_RESULTS = "num_results"
    QUERY_STYLE = "query_style"
    QUERY_COLUMNS = "query_columns"
    NUM_FEW_SHOT_EXAMPLES = "num_few_shot_examples"
    QUERY_TYPE = "query_type"
    RERANKER_ENABLED = "reranker_enabled"
    COLUMNS_TO_RERANK = "columns_to_rerank"
    RANDOM_SEED = "random_seed"


class MLflowMetrics:
    """Metric names for MLflow logging."""
    AVG_RELEVANCE_SCORE = "avg_relevance_score"
    HIGHLY_RELEVANT_PCT = "highly_relevant_pct"
    RELEVANT_PLUS_PCT = "relevant_plus_pct"
    NOT_RELEVANT_PCT = "not_relevant_pct"
    MRR = "mrr"

    # Formatted metric name templates
    RECALL_AT_K = "recall_at_{k}"
    PRECISION_AT_K = "precision_at_{k}"
    NDCG_AT_K = "ndcg_at_{k}"
    MAP_AT_K = "map_at_{k}"
    DCG_AT_K = "dcg_at_{k}"

    # CI suffix
    CI_SUFFIX = "_ci"


class MLflowTags:
    """Tags for MLflow experiments."""
    PRODUCT = "product"
    PRODUCT_VALUE = "vector_search"
    TYPE = "type"
    TYPE_VALUE_AUTOEVAL = "autoeval"
    TYPE_VALUE_VALIDATION = "autoeval_validation"

    # Lifecycle stages
    LIFECYCLE_STAGE_DELETED = "deleted"


# =============================================================================
# Scoring Constants
# =============================================================================

class Scoring:
    """Constants for relevance scoring."""

    # Score scale (0-3)
    MIN_SCORE = 0
    MAX_SCORE = 3

    # Relevance thresholds
    HIGHLY_RELEVANT_SCORE = 3
    RELEVANT_THRESHOLD = 2  # score >= 2 is "relevant"
    NOT_RELEVANT_THRESHOLD = 1  # score <= 1 is "not relevant"

    # Regex pattern for parsing scores
    SCORE_REGEX = r'[0-3]'


# =============================================================================
# Default Values
# =============================================================================

class Defaults:
    """Default configuration values."""
    # LLM endpoints for different tasks
    QUERY_GENERATION_LLM_ENDPOINT = "databricks-gemini-3-flash"
    RELEVANCE_JUDGE_LLM_ENDPOINT = "databricks-gemini-3-flash"

    # Backward compatibility alias (use QUERY_GENERATION_LLM_ENDPOINT instead)
    LLM_ENDPOINT = QUERY_GENERATION_LLM_ENDPOINT

    QUERY_STYLE = QueryStyle.MIXED
    NUM_SAMPLES = 20
    NUM_QUERIES = 200
    NUM_RESULTS = 10
    MAX_NUM_RESULTS = 200
    RELEVANCE_THRESHOLD = 2
    QUERY_GENERATION_BUFFER_FRACTION = 0.25  # Fraction of extra queries to generate (0.25 = 25%)
    TEXT_TRUNCATION_LIMIT = 1000  # Max chars for text fields in MLflow traces
    STANDARD_K_VALUES = [1, 3, 5, 10, 20, 50, 100]  # Standard k values for metrics


# =============================================================================
# MLflow Tracing Fields
# =============================================================================

class TracingFields:
    """Field names specific to MLflow tracing (not DataFrame columns).

    These are used for trace-level attributes and span outputs that don't
    correspond to DataFrame column names.
    """

    # Trace-level attributes
    NUM_RESULTS_PER_QUERY = "num_results_per_query"
    NUM_QUERIES = "num_queries"

    # Query span outputs
    RECALL_RANK = "recall_rank"  # Rank where original doc found, or None
    AVG_LLM_SCORE = "avg_llm_score"
    RESULTS = "results"
    RANK = "rank"  # Individual result rank (different from RESULT_RANK column)


# =============================================================================
# Plotting Constants
# =============================================================================

class PlotColors:
    """Color constants for plotting."""

    # Color for MRR (standalone metric without k)
    MRR = "#9467bd"  # purple

    # Plotly's default qualitative color palette (10 colors)
    # Hardcoded to avoid importing plotly.express which has numpy/pandas compatibility issues
    PLOTLY_PALETTE = [
        "#636EFA", "#EF553B", "#00CC96", "#AB63FA", "#FFA15A",
        "#19D3F3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"
    ]


class PlotDataKeys:
    """Keys used in plotting data structures."""
    QUERY_TYPES = "query_types"
    VALUES = "values"
    CI_MARGINS = "ci_margins"


class PlotLabels:
    """Display labels for plot axes and legends."""
    QUERY_TYPE = "Query Type"
    K_VALUE = "k Value"


class PlotConfig:
    """Configuration constants for plot styling."""
    DECIMAL_PRECISION = 2  # Number of decimal places for display
    MARKER_OPACITY = 0.7
    MARKER_SIZE = 10
    JITTER_WIDTH = 0.1  # Horizontal spread for overlapping points
