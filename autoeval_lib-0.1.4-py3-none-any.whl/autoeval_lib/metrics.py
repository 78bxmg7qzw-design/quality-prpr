"""Metrics analysis for search evaluation results."""

from __future__ import annotations

import math
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, count, avg, when, sum as spark_sum, lit, log2, min as spark_min
from pyspark.sql.window import Window

from autoeval_lib.constants import Columns, Scoring, MLflowMetrics


def format_with_ci(value: float, ci_margin: float, decimals: int = 2) -> str:
    """Format a value with its confidence interval margin.

    Args:
        value: Point estimate
        ci_margin: Confidence interval margin (± value)
        decimals: Number of decimal places

    Returns:
        Formatted string like "0.35 ± 0.03"
    """
    return f"{round(value, decimals)} ± {round(ci_margin, decimals)}"


class MetricsAnalyzer:
    """Analyzes scored search results to compute evaluation metrics.

    Provides summary statistics, score distributions, and examples
    of high and low relevance results.

    Example:
        analyzer = MetricsAnalyzer(scored_df)
        print(analyzer.summary())
        display(analyzer.score_distribution())
        display(analyzer.high_relevance_examples(10))
    """

    def __init__(self, scored_df: DataFrame):
        """Initialize the analyzer with scored results.

        Args:
            scored_df: DataFrame with 'llm_relevance_score' column
        """
        self.df = scored_df
        self._cache_metrics()

    def _cache_metrics(self) -> None:
        """Pre-compute common metrics for summary statistics.

        Caches total counts, relevance distributions, and average score
        to avoid redundant DataFrame operations in summary().

        Note: For empty DataFrames, sets safe defaults to avoid division by zero.
        """
        self._total = self.df.count()
        self._num_queries = self.df.select(Columns.QUERY).distinct().count()

        # Handle empty DataFrame case
        if self._total == 0:
            self._highly_relevant = 0
            self._relevant = 0
            self._not_relevant = 0
            self._avg_score = 0.0
            return

        self._highly_relevant = self.df.filter(col(Columns.LLM_RELEVANCE_SCORE) == Scoring.HIGHLY_RELEVANT_SCORE).count()
        self._relevant = self.df.filter(col(Columns.LLM_RELEVANCE_SCORE) >= Scoring.RELEVANT_THRESHOLD).count()
        self._not_relevant = self.df.filter(col(Columns.LLM_RELEVANCE_SCORE) <= Scoring.NOT_RELEVANT_THRESHOLD).count()
        avg_result = self.df.agg(avg(Columns.LLM_RELEVANCE_SCORE)).collect()[0][0]
        self._avg_score = avg_result if avg_result is not None else 0.0

    def summary(self) -> str:
        """Return a text summary of overall metrics.

        Returns:
            Formatted string with key metrics
        """
        # Handle empty DataFrame case
        if self._total == 0:
            lines = [
                "=" * 50,
                "AUTOEVAL RESULTS SUMMARY",
                "=" * 50,
                "No results to summarize (empty DataFrame).",
                "=" * 50,
            ]
            return "\n".join(lines)

        lines = [
            "=" * 50,
            "AUTOEVAL RESULTS SUMMARY",
            "=" * 50,
            f"Total query-document pairs: {self._total}",
            f"",
            f"Score Distribution:",
            f"  Highly Relevant (3): {self._highly_relevant} ({self._highly_relevant/self._total*100:.2f}%)",
            f"  Relevant+ (>=2):     {self._relevant} ({self._relevant/self._total*100:.2f}%)",
            f"  Not Relevant (<2):   {self._not_relevant} ({self._not_relevant/self._total*100:.2f}%)",
            f"",
            f"Average Relevance Score: {self._avg_score:.2f}",
            "=" * 50,
        ]
        return "\n".join(lines)

    def score_distribution(self) -> DataFrame:
        """Return score distribution as a DataFrame.

        Returns:
            DataFrame with score counts and percentages
        """
        dist = self.df.groupBy(Columns.LLM_RELEVANCE_SCORE).agg(
            count("*").alias("count")
        ).orderBy(Columns.LLM_RELEVANCE_SCORE)

        return dist

    def avg_by_query(self) -> DataFrame:
        """Return average relevance score per query.

        Returns:
            DataFrame with query, avg_relevance, num_results columns
        """
        return self.df.groupBy(Columns.QUERY).agg(
            avg(Columns.LLM_RELEVANCE_SCORE).alias("avg_relevance"),
            count("*").alias("num_results")
        ).orderBy(col("avg_relevance").desc())

    def top_queries(self, n: int = 10) -> DataFrame:
        """Return top queries by average relevance.

        Args:
            n: Number of queries to return

        Returns:
            DataFrame with highest average relevance queries
        """
        return self.avg_by_query().limit(n)

    def bottom_queries(self, n: int = 10) -> DataFrame:
        """Return bottom queries by average relevance.

        Args:
            n: Number of queries to return

        Returns:
            DataFrame with lowest average relevance queries
        """
        return self.avg_by_query().orderBy("avg_relevance").limit(n)

    def high_relevance_examples(self, n: int = 10) -> DataFrame:
        """Return examples of highly relevant results.

        Args:
            n: Number of examples to return

        Returns:
            DataFrame with score=3 results
        """
        return self.df.filter(
            col(Columns.LLM_RELEVANCE_SCORE) == Scoring.HIGHLY_RELEVANT_SCORE
        ).select(
            Columns.QUERY,
            Columns.ORIGINAL_DOC_ID,
            Columns.RETRIEVED_DOC_ID,
            Columns.LLM_RELEVANCE_SCORE,
            Columns.RETRIEVED_TEXT,
            Columns.SEARCH_SCORE
        ).limit(n)

    def low_relevance_examples(self, n: int = 10) -> DataFrame:
        """Return examples of low relevance results.

        Args:
            n: Number of examples to return

        Returns:
            DataFrame with score=0 or 1 results
        """
        return self.df.filter(
            col(Columns.LLM_RELEVANCE_SCORE) < Scoring.RELEVANT_THRESHOLD
        ).select(
            Columns.QUERY,
            Columns.ORIGINAL_DOC_ID,
            Columns.RETRIEVED_DOC_ID,
            Columns.LLM_RELEVANCE_SCORE,
            Columns.RETRIEVED_TEXT,
            Columns.SEARCH_SCORE
        ).limit(n)

    def _wilson_ci(self, successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
        """Compute Wilson score confidence interval for a proportion.

        The Wilson score interval is more accurate than normal approximation,
        especially for proportions near 0 or 1.

        Args:
            successes: Number of successes
            total: Total number of trials
            z: Z-score for confidence level (1.96 for 95% CI)

        Returns:
            Tuple of (point_estimate, margin) where CI = point_estimate ± margin
        """
        if total == 0:
            return (0.0, 0.0)

        p = successes / total
        z2 = z * z

        # Wilson score interval
        denominator = 1 + z2 / total
        center = (p + z2 / (2 * total)) / denominator
        margin = (z / denominator) * math.sqrt(p * (1 - p) / total + z2 / (4 * total * total))

        return (p, margin)

    def _t_ci(self, values: list, critical_value: float = 1.96) -> tuple[float, float]:
        """Compute confidence interval for a continuous variable using t-distribution approximation.

        Args:
            values: List of sample values
            critical_value: Critical value for confidence level (1.96 for 95% CI).
                Uses z-score as approximation for t-distribution with large samples.

        Returns:
            Tuple of (mean, margin) where CI = mean ± margin
        """
        n = len(values)
        if n == 0:
            return (0.0, 0.0)
        if n == 1:
            return (values[0], 0.0)

        mean = sum(values) / n
        variance = sum((x - mean) ** 2 for x in values) / (n - 1)
        std_error = math.sqrt(variance / n)
        margin = critical_value * std_error

        return (mean, margin)

    def _collect_column_values(self, df: DataFrame, column: str) -> list:
        """Collect a single column from DataFrame as a list, filtering None values.

        Args:
            df: Source DataFrame
            column: Column name to collect

        Returns:
            List of non-None values from the column
        """
        return [row[column] for row in df.select(column).collect() if row[column] is not None]

    def recall_at_k(self, k: int = 10) -> tuple[float, float]:
        """Calculate recall@k with 95% confidence interval.

        Uses Wilson score interval since recall is a binary outcome per query.

        Args:
            k: Number of top results to consider

        Returns:
            Tuple of (recall, ci_margin) where CI = recall ± ci_margin
        """
        queries_with_hit = self.df.filter(
            (col(Columns.RESULT_RANK) <= k) &
            (col(Columns.ORIGINAL_DOC_ID) == col(Columns.RETRIEVED_DOC_ID))
        ).select(Columns.QUERY).distinct().count()

        total_queries = self._num_queries

        if total_queries == 0:
            return (0.0, 0.0)

        return self._wilson_ci(queries_with_hit, total_queries)

    def avg_score(self) -> tuple[float, float]:
        """Calculate average relevance score with 95% confidence interval.

        Uses per-query averages as the statistical unit to account for
        correlation among pairs within the same query.

        Returns:
            Tuple of (avg_score, ci_margin) where CI = avg_score ± ci_margin
        """
        # Get per-query average scores
        query_avgs_df = self.df.groupBy(Columns.QUERY).agg(
            avg(Columns.LLM_RELEVANCE_SCORE).alias("avg_score")
        )
        values = self._collect_column_values(query_avgs_df, "avg_score")
        return self._t_ci(values)

    def precision_at_k(self, k: int = 10, relevance_threshold: int = Scoring.RELEVANT_THRESHOLD) -> tuple[float, float]:
        """Calculate precision@k with 95% confidence interval.

        Uses per-query precision values for CI calculation.

        Args:
            k: Number of top results to consider
            relevance_threshold: Minimum score to count as relevant (default: 2)

        Returns:
            Tuple of (precision, ci_margin) where CI = precision ± ci_margin
        """
        top_k_df = self.df.filter(col(Columns.RESULT_RANK) <= k)

        per_query = top_k_df.groupBy(Columns.QUERY).agg(
            spark_sum(when(col(Columns.LLM_RELEVANCE_SCORE) >= relevance_threshold, 1).otherwise(0)).alias("relevant_count"),
            count("*").alias("total_count")
        )

        precision_df = per_query.withColumn(
            "precision",
            col("relevant_count") / when(col("total_count") < k, col("total_count")).otherwise(lit(k))
        )

        values = self._collect_column_values(precision_df, "precision")
        return self._t_ci(values)

    def mrr(self, relevance_threshold: int = Scoring.RELEVANT_THRESHOLD) -> tuple[float, float]:
        """Calculate MRR with 95% confidence interval.

        Uses per-query reciprocal rank values for CI calculation.

        Args:
            relevance_threshold: Minimum score to count as relevant (default: 2)

        Returns:
            Tuple of (mrr, ci_margin) where CI = mrr ± ci_margin
        """
        relevant_df = self.df.filter(col(Columns.LLM_RELEVANCE_SCORE) >= relevance_threshold)

        first_relevant = relevant_df.groupBy(Columns.QUERY).agg(
            spark_min(Columns.RESULT_RANK).alias("first_relevant_rank")
        )

        all_queries = self.df.select(Columns.QUERY).distinct()
        joined = all_queries.join(first_relevant, on=Columns.QUERY, how="left")

        rr_df = joined.withColumn(
            "reciprocal_rank",
            when(col("first_relevant_rank").isNotNull(), 1.0 / col("first_relevant_rank")).otherwise(0.0)
        )

        values = self._collect_column_values(rr_df, "reciprocal_rank")
        return self._t_ci(values)

    def ndcg_at_k(self, k: int = 10) -> tuple[float, float]:
        """Calculate NDCG@k with 95% confidence interval.

        Uses per-query NDCG values for CI calculation.

        Args:
            k: Number of top results to consider

        Returns:
            Tuple of (ndcg, ci_margin) where CI = ndcg ± ci_margin
        """
        top_k_df = self.df.filter(col(Columns.RESULT_RANK) <= k)

        # Compute DCG per query
        dcg_df = top_k_df.withColumn(
            "dcg_contribution",
            col(Columns.LLM_RELEVANCE_SCORE) / log2(col(Columns.RESULT_RANK) + 1)
        ).groupBy(Columns.QUERY).agg(
            spark_sum("dcg_contribution").alias("dcg")
        )

        # Compute IDCG per query
        ideal_window = Window.partitionBy(Columns.QUERY).orderBy(col(Columns.LLM_RELEVANCE_SCORE).desc())

        idcg_df = top_k_df.withColumn(
            "ideal_rank",
            count("*").over(ideal_window.rowsBetween(Window.unboundedPreceding, Window.currentRow))
        ).withColumn(
            "idcg_contribution",
            col(Columns.LLM_RELEVANCE_SCORE) / log2(col("ideal_rank") + 1)
        ).groupBy(Columns.QUERY).agg(
            spark_sum("idcg_contribution").alias("idcg")
        )

        ndcg_df = dcg_df.join(idcg_df, on=Columns.QUERY, how="inner")
        ndcg_df = ndcg_df.withColumn(
            "ndcg",
            when(col("idcg") > 0, col("dcg") / col("idcg")).otherwise(0.0)
        )

        values = self._collect_column_values(ndcg_df, "ndcg")
        return self._t_ci(values)

    def dcg_at_k(self, k: int = 10) -> tuple[float, float]:
        """Calculate DCG@k with graded relevance (0-3) and 95% confidence interval.

        DCG (Discounted Cumulative Gain) provides an absolute measure of retrieval
        utility using graded relevance scores. Unlike NDCG which normalizes by the
        ideal ranking of retrieved docs, DCG reflects total relevance utility.

        This complements NDCG: a system retrieving [3,2,0,0,0] gets NDCG=1.0 (perfect
        ranking) but only DCG=4.26, while [3,3,3,2,2] gets NDCG=0.91 but DCG=8.02.

        For interpretation, theoretical max DCG values (all docs score 3):
        - DCG_max@1 = 3.0, @3 = 6.39, @4 = 7.69, @10 = 13.63, @20 = 21.12,
          @50 = 37.79, @100 = 57.45

        Args:
            k: Number of top results to consider

        Returns:
            Tuple of (dcg_value, confidence_interval_margin)
        """
        top_k_df = self.df.filter(col(Columns.RESULT_RANK) <= k)

        dcg_df = top_k_df.withColumn(
            "dcg_contribution",
            col(Columns.LLM_RELEVANCE_SCORE) / log2(col(Columns.RESULT_RANK) + 1)
        ).groupBy(Columns.QUERY).agg(
            spark_sum("dcg_contribution").alias("dcg")
        )

        values = self._collect_column_values(dcg_df, "dcg")
        return self._t_ci(values)

    def map_at_k(
        self, k: int = 10, relevance_threshold: int = Scoring.RELEVANT_THRESHOLD
    ) -> tuple[float, float]:
        """Calculate MAP@k with 95% confidence interval.

        Uses per-query AP values for CI calculation.

        Args:
            k: Number of top results to consider
            relevance_threshold: Minimum score to consider relevant (default: 2)

        Returns:
            Tuple of (map, ci_margin) where CI = map ± ci_margin
        """
        top_k_df = self.df.filter(col(Columns.RESULT_RANK) <= k)

        # Mark each result as relevant or not
        top_k_df = top_k_df.withColumn(
            "is_relevant",
            when(col(Columns.LLM_RELEVANCE_SCORE) >= relevance_threshold, 1).otherwise(0)
        )

        # Window to compute cumulative relevant count at each rank
        rank_window = Window.partitionBy(Columns.QUERY).orderBy(Columns.RESULT_RANK)

        # Compute cumulative relevant count at each position
        top_k_df = top_k_df.withColumn(
            "cumulative_relevant",
            spark_sum("is_relevant").over(rank_window)
        )

        # Compute precision@i for each position
        top_k_df = top_k_df.withColumn(
            "precision_at_i",
            col("cumulative_relevant") / col(Columns.RESULT_RANK)
        )

        # For AP: sum precision@i only for relevant docs, divide by total relevant in k
        ap_df = top_k_df.groupBy(Columns.QUERY).agg(
            spark_sum(
                when(col("is_relevant") == 1, col("precision_at_i")).otherwise(0.0)
            ).alias("sum_precision"),
            spark_sum("is_relevant").alias("num_relevant")
        )

        # Compute AP per query
        ap_df = ap_df.withColumn(
            "ap",
            when(col("num_relevant") > 0, col("sum_precision") / col("num_relevant")).otherwise(0.0)
        )

        values = self._collect_column_values(ap_df, "ap")
        return self._t_ci(values)

    def get_metrics(
        self, k_values: list[int] | None = None
    ) -> dict[str, tuple[float, float]]:
        """Get all aggregate metrics with 95% confidence intervals.

        Args:
            k_values: List of k values for @k metrics. If None, only returns
                base metrics (avg_relevance_score, percentages, mrr) without
                @k metrics.

        Returns:
            Dict mapping metric names to (value, ci_margin) tuples.
            For percentages, values are in percentage points (0-100).
            For recall/precision/ndcg, values are fractions (0-1).
        """
        # Relevance percentages (using total pairs as n)
        highly_rel = self._wilson_ci(self._highly_relevant, self._total)
        relevant_plus = self._wilson_ci(self._relevant, self._total)
        not_relevant = self._wilson_ci(self._not_relevant, self._total)

        # Average score (using per-query means)
        avg_score = self.avg_score()

        # MRR
        mrr_metric = self.mrr()

        metrics = {
            MLflowMetrics.AVG_RELEVANCE_SCORE: avg_score,
            MLflowMetrics.HIGHLY_RELEVANT_PCT: (highly_rel[0] * 100, highly_rel[1] * 100),
            MLflowMetrics.RELEVANT_PLUS_PCT: (relevant_plus[0] * 100, relevant_plus[1] * 100),
            MLflowMetrics.NOT_RELEVANT_PCT: (not_relevant[0] * 100, not_relevant[1] * 100),
            MLflowMetrics.MRR: mrr_metric,
        }

        # Dynamically add @k metrics if k_values provided
        if k_values:
            for k in k_values:
                metrics[MLflowMetrics.RECALL_AT_K.format(k=k)] = self.recall_at_k(k=k)
                metrics[MLflowMetrics.PRECISION_AT_K.format(k=k)] = self.precision_at_k(k=k)
                metrics[MLflowMetrics.NDCG_AT_K.format(k=k)] = self.ndcg_at_k(k=k)
                metrics[MLflowMetrics.DCG_AT_K.format(k=k)] = self.dcg_at_k(k=k)
                metrics[MLflowMetrics.MAP_AT_K.format(k=k)] = self.map_at_k(k=k)

        return metrics
