"""Tests for config module."""

import pytest
from unittest.mock import Mock, patch
from autoeval_lib.config import (
    AutoEvalConfig,
    compute_k_values,
    quote_sql_identifier,
    quote_table_name,
)
from autoeval_lib.mlflow_tracker import generate_experiment_path


class TestQuoteSqlIdentifier:
    """Tests for quote_sql_identifier function."""

    def test_simple_identifier_not_quoted(self):
        """Test that simple alphanumeric identifiers are not quoted."""
        assert quote_sql_identifier("my_table") == "my_table"
        assert quote_sql_identifier("MyTable123") == "MyTable123"
        assert quote_sql_identifier("doc_id") == "doc_id"

    def test_identifier_with_dash_is_quoted(self):
        """Test that identifiers with dashes are quoted."""
        assert quote_sql_identifier("vector-search") == "`vector-search`"
        assert quote_sql_identifier("my-schema-name") == "`my-schema-name`"

    def test_identifier_with_space_is_quoted(self):
        """Test that identifiers with spaces are quoted."""
        assert quote_sql_identifier("my table") == "`my table`"

    def test_already_quoted_identifier_unchanged(self):
        """Test that already quoted identifiers are not double-quoted."""
        assert quote_sql_identifier("`already-quoted`") == "`already-quoted`"

    def test_identifier_with_backtick_is_escaped(self):
        """Test that backticks inside identifiers are escaped."""
        assert quote_sql_identifier("weird`name") == "`weird``name`"


class TestQuoteTableName:
    """Tests for quote_table_name function."""

    def test_simple_table_name_not_quoted(self):
        """Test that simple table names are not quoted."""
        assert quote_table_name("catalog.schema.table") == "catalog.schema.table"

    def test_table_name_with_dashes_is_quoted(self):
        """Test that table name components with dashes are quoted."""
        result = quote_table_name("catalog.vector-search-data.table")
        assert result == "catalog.`vector-search-data`.table"

    def test_multiple_components_with_dashes(self):
        """Test that multiple components with dashes are all quoted."""
        result = quote_table_name("my-catalog.my-schema.my-table")
        assert result == "`my-catalog`.`my-schema`.`my-table`"

    def test_empty_table_name_returns_empty(self):
        """Test that empty table name returns empty string."""
        assert quote_table_name("") == ""
        assert quote_table_name(None) is None

    def test_real_world_example(self):
        """Test with a real-world example similar to the reported bug."""
        result = quote_table_name("gurary_catalog.vector-search-brickfood.source_table")
        assert result == "gurary_catalog.`vector-search-brickfood`.source_table"


class TestComputeKValues:
    """Tests for compute_k_values function."""

    def test_compute_k_values_10(self):
        """Test k values for num_results=10."""
        assert compute_k_values(10) == [1, 3, 5, 10]

    def test_compute_k_values_5(self):
        """Test k values for num_results=5."""
        assert compute_k_values(5) == [1, 3, 5]

    def test_compute_k_values_20(self):
        """Test k values for num_results=20."""
        assert compute_k_values(20) == [1, 3, 5, 10, 20]

    def test_compute_k_values_100(self):
        """Test k values for num_results=100."""
        assert compute_k_values(100) == [1, 3, 5, 10, 20, 50, 100]


class TestAutoEvalConfigCreation:
    """Tests for AutoEvalConfig creation (before validation)."""

    def test_minimal_config_creation(self):
        """Test creating config with only required fields."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        assert config.index_name == "catalog.schema.index"
        assert config.query_columns == ["text"]
        assert config.query_cache_table == "catalog.schema.cache"
        assert config.is_validated() is False

    def test_default_values(self):
        """Test that default values are set correctly."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        assert config.query_generation_llm_endpoint == "databricks-gemini-3-flash"
        assert config.embedding_model == ""
        assert config.query_style == "mixed"
        assert config.num_samples == 20
        assert config.num_queries == 200
        assert config.num_results == 10
        assert config.query_types == ["FULL_TEXT", "ANN", "HYBRID"]
        assert config.additional_retrieval_columns == []
        assert config.additional_reranker_columns == []
        assert config.enable_reranker is True
        assert config.random_seed is None
        assert config.enable_mlflow_logging is True
        assert config.few_shot_examples == []

    def test_custom_values_override_defaults(self):
        """Test that custom values override defaults."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text", "title"],
            query_generation_llm_endpoint="custom-endpoint",
            embedding_model="custom-embedding",
            query_style="keyword",
            num_samples=50,
            num_queries=500,
            num_results=20,
            query_types=["ANN", "HYBRID"],
            additional_retrieval_columns=["extra_col"],
            additional_reranker_columns=["rerank_col"],
            enable_reranker=True,
            query_cache_table="cache.table",
            random_seed=123,
            enable_mlflow_logging=False,
        )
        assert config.query_columns == ["text", "title"]
        assert config.query_generation_llm_endpoint == "custom-endpoint"
        assert config.embedding_model == "custom-embedding"
        assert config.query_style == "keyword"
        assert config.num_samples == 50
        assert config.num_queries == 500
        assert config.num_results == 20
        assert config.query_types == ["ANN", "HYBRID"]
        assert config.additional_retrieval_columns == ["extra_col"]
        assert config.additional_reranker_columns == ["rerank_col"]
        assert config.enable_reranker is True
        assert config.query_cache_table == "cache.table"
        assert config.random_seed == 123
        assert config.enable_mlflow_logging is False


class TestAutoEvalConfigValidation:
    """Tests for AutoEvalConfig.validate() method."""

    def _create_mock_index(
        self,
        endpoint_name="test-endpoint",
        primary_key="doc_id",
        source_table="catalog.schema.source",
        embedding_model="databricks-gte-large-en",
        ready=True
    ):
        """Create a mock index with describe() response."""
        mock_index = Mock()
        mock_index.describe.return_value = {
            "endpoint_name": endpoint_name,
            "primary_key": primary_key,
            "status": {"ready": ready, "detailed_state": "ONLINE"},
            "delta_sync_index_spec": {
                "source_table": source_table,
                "embedding_source_columns": [
                    {"embedding_model_endpoint_name": embedding_model}
                ]
            }
        }
        return mock_index

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_success(self, mock_vsc_class, mock_validate_perms):
        """Test successful validation."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        result = config.validate()

        assert result is config  # Returns self
        assert config.is_validated() is True
        assert config.endpoint_name == "test-endpoint"
        assert config.primary_key == "doc_id"
        assert config.corpus_table == "catalog.schema.source"
        assert config.embedding_model == "databricks-gte-large-en"

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_computes_columns_to_retrieve(self, mock_vsc_class, mock_validate_perms):
        """Test that columns_to_retrieve is computed correctly."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text", "title"],
            additional_retrieval_columns=["extra_col"],
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        # [primary_key] + query_columns + additional_retrieval_columns
        assert config.columns_to_retrieve == ["doc_id", "text", "title", "extra_col"]

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_computes_columns_to_rerank(self, mock_vsc_class, mock_validate_perms):
        """Test that columns_to_rerank is computed correctly."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text", "title"],
            additional_reranker_columns=["summary"],
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        # query_columns + additional_reranker_columns
        assert config.columns_to_rerank == ["text", "title", "summary"]

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_deduplicates_columns(self, mock_vsc_class, mock_validate_perms):
        """Test that duplicate columns are removed."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text", "doc_id"],  # doc_id is also primary_key
            additional_retrieval_columns=["text"],  # duplicate
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        # Should deduplicate while preserving order
        assert config.columns_to_retrieve == ["doc_id", "text"]

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_computes_k_values(self, mock_vsc_class, mock_validate_perms):
        """Test that k_values is computed correctly."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            num_results=10,
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        assert config.k_values == [1, 3, 5, 10]

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_normalizes_query_style(self, mock_vsc_class, mock_validate_perms):
        """Test that query_style is normalized to lowercase."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_style="MIXED",
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        assert config.query_style == "mixed"

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_normalizes_query_types(self, mock_vsc_class, mock_validate_perms):
        """Test that query_types are normalized to uppercase."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_types=["ann", "Hybrid", "full_text"],
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        assert config.query_types == ["ANN", "HYBRID", "FULL_TEXT"]

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_uses_provided_embedding_model(self, mock_vsc_class, mock_validate_perms):
        """Test that user-provided embedding_model is used."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            embedding_model="my-custom-embedding",
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        assert config.embedding_model == "my-custom-embedding"

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_quotes_corpus_table_with_dashes(self, mock_vsc_class, mock_validate_perms):
        """Test that corpus_table with dashes is properly quoted for SQL safety."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index(
            source_table="gurary_catalog.vector-search-brickfood.source_table"
        )
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        # Schema with dashes should be backtick-quoted
        assert config.corpus_table == "gurary_catalog.`vector-search-brickfood`.source_table"


class TestAutoEvalConfigValidationErrors:
    """Tests for validation errors."""

    def _create_mock_index(
        self,
        endpoint_name="test-endpoint",
        primary_key="doc_id",
        source_table="catalog.schema.source",
        embedding_model="databricks-gte-large-en",
        ready=True
    ):
        """Create a mock index with describe() response."""
        mock_index = Mock()
        mock_index.describe.return_value = {
            "endpoint_name": endpoint_name,
            "primary_key": primary_key,
            "status": {"ready": ready, "detailed_state": "ONLINE" if ready else "PROVISIONING"},
            "delta_sync_index_spec": {
                "source_table": source_table,
                "embedding_source_columns": [
                    {"embedding_model_endpoint_name": embedding_model}
                ] if embedding_model else []
            }
        }
        return mock_index

    def test_validate_empty_query_generation_llm_endpoint_raises_error(self):
        """Test that empty query_generation_llm_endpoint raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_generation_llm_endpoint="",
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="query_generation_llm_endpoint cannot be empty"):
            config.validate()

    def test_validate_whitespace_query_generation_llm_endpoint_raises_error(self):
        """Test that whitespace-only query_generation_llm_endpoint raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_generation_llm_endpoint="   ",
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="query_generation_llm_endpoint cannot be empty"):
            config.validate()

    def test_validate_empty_relevance_judge_llm_endpoint_raises_error(self):
        """Test that empty relevance_judge_llm_endpoint raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            relevance_judge_llm_endpoint="",
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="relevance_judge_llm_endpoint cannot be empty"):
            config.validate()

    def test_validate_whitespace_relevance_judge_llm_endpoint_raises_error(self):
        """Test that whitespace-only relevance_judge_llm_endpoint raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            relevance_judge_llm_endpoint="   ",
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="relevance_judge_llm_endpoint cannot be empty"):
            config.validate()

    def test_validate_invalid_query_style_raises_error(self):
        """Test that invalid query_style raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_style="invalid",
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="query_style must be one of"):
            config.validate()

    def test_validate_invalid_query_type_raises_error(self):
        """Test that invalid query_type raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_types=["ANN", "INVALID"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="Invalid query_type 'INVALID'"):
            config.validate()

    def test_validate_empty_query_columns_raises_error(self):
        """Test that empty query_columns raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=[],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="query_columns must not be empty"):
            config.validate()

    def test_validate_zero_num_samples_raises_error(self):
        """Test that num_samples=0 raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            num_samples=0,
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="num_samples must be at least 1"):
            config.validate()

    def test_validate_zero_num_queries_raises_error(self):
        """Test that num_queries=0 raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            num_queries=0,
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="num_queries must be at least 1"):
            config.validate()

    def test_validate_zero_num_results_raises_error(self):
        """Test that num_results=0 raises ValueError."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            num_results=0,
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="num_results must be at least 1"):
            config.validate()

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_index_not_ready_raises_error(self, mock_vsc_class, mock_validate_perms):
        """Test that non-ready index raises ValueError."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index(ready=False)
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="is not ready"):
            config.validate()

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_missing_endpoint_name_raises_error(self, mock_vsc_class, mock_validate_perms):
        """Test that missing endpoint_name raises ValueError."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index(endpoint_name=None)
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="Could not derive endpoint_name"):
            config.validate()

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_missing_primary_key_raises_error(self, mock_vsc_class, mock_validate_perms):
        """Test that missing primary_key raises ValueError."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index(primary_key=None)
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="Could not derive primary_key"):
            config.validate()

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_missing_corpus_table_raises_error(self, mock_vsc_class, mock_validate_perms):
        """Test that missing corpus_table raises ValueError."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index(source_table=None)
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="Could not derive corpus_table"):
            config.validate()

    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_missing_embedding_model_raises_error(self, mock_vsc_class, mock_validate_perms):
        """Test that missing embedding_model for self-managed index raises ValueError."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index(embedding_model=None)
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="embedding_model not provided"):
            config.validate()

    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_index_access_failure_raises_error(self, mock_vsc_class):
        """Test that index access failure raises ValueError."""
        mock_vsc = Mock()
        mock_vsc.get_index.side_effect = Exception("Connection failed")
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        with pytest.raises(ValueError, match="Failed to access index"):
            config.validate()


class TestPermissionValidation:
    """Tests for permission validation methods."""

    def _create_mock_index(
        self,
        endpoint_name="test-endpoint",
        primary_key="doc_id",
        source_table="catalog.schema.source",
        embedding_model="databricks-gte-large-en",
        ready=True
    ):
        """Create a mock index with describe() response."""
        mock_index = Mock()
        mock_index.describe.return_value = {
            "endpoint_name": endpoint_name,
            "primary_key": primary_key,
            "status": {"ready": ready, "detailed_state": "ONLINE"},
            "delta_sync_index_spec": {
                "source_table": source_table,
                "embedding_source_columns": [
                    {"embedding_model_endpoint_name": embedding_model}
                ]
            }
        }
        return mock_index

    def test_check_table_read_access_success(self):
        """Test successful table read access check."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        # Set required fields manually for isolated testing
        config.corpus_table = "catalog.schema.table"

        with patch("pyspark.sql.SparkSession") as mock_spark_class:
            mock_spark = Mock()
            mock_spark_class.builder.getOrCreate.return_value = mock_spark

            # Should not raise any error
            config._check_table_read_access("catalog.schema.table")

            # Verify SQL was executed
            mock_spark.sql.assert_called_once()
            call_args = mock_spark.sql.call_args[0][0]
            assert "SELECT 1 FROM catalog.schema.table LIMIT 0" in call_args

    def test_check_table_read_access_permission_denied(self):
        """Test table read access check with permission denied."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        with patch("pyspark.sql.SparkSession") as mock_spark_class:
            mock_spark = Mock()
            mock_spark.sql.side_effect = Exception("User does not have permission to access table")
            mock_spark_class.builder.getOrCreate.return_value = mock_spark

            with pytest.raises(ValueError, match="Missing SELECT permission"):
                config._check_table_read_access("catalog.schema.table")

    def test_check_table_read_access_table_not_found(self):
        """Test table read access check with table not found."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        with patch("pyspark.sql.SparkSession") as mock_spark_class:
            mock_spark = Mock()
            mock_spark.sql.side_effect = Exception("Table not found: catalog.schema.table")
            mock_spark_class.builder.getOrCreate.return_value = mock_spark

            with pytest.raises(ValueError, match="does not exist"):
                config._check_table_read_access("catalog.schema.table")

    @patch("autoeval_lib.config.EndpointStateReady")
    @patch("autoeval_lib.config.WorkspaceClient")
    def test_check_model_endpoint_access_success(self, mock_ws_class, mock_endpoint_state_ready):
        """Test successful model endpoint access check."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        # Set up mock for EndpointStateReady.READY
        ready_value = Mock()
        mock_endpoint_state_ready.READY = ready_value

        mock_ws = Mock()
        mock_endpoint = Mock()
        mock_endpoint.state.ready = ready_value  # Matches EndpointStateReady.READY
        mock_ws.serving_endpoints.get.return_value = mock_endpoint
        mock_ws_class.return_value = mock_ws

        # Should not raise any error
        config._check_model_endpoint_access("test-endpoint", "Embedding model")

    @patch("autoeval_lib.config.EndpointStateReady")
    @patch("autoeval_lib.config.WorkspaceClient")
    def test_check_model_endpoint_access_not_ready(self, mock_ws_class, mock_endpoint_state_ready):
        """Test model endpoint access check with endpoint not ready."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        # Set up mock for EndpointStateReady.READY
        ready_value = Mock()
        mock_endpoint_state_ready.READY = ready_value

        mock_ws = Mock()
        mock_endpoint = Mock()
        # Use a different mock that won't equal EndpointStateReady.READY
        mock_endpoint.state.ready = Mock()
        mock_ws.serving_endpoints.get.return_value = mock_endpoint
        mock_ws_class.return_value = mock_ws

        with pytest.raises(ValueError, match="is not ready"):
            config._check_model_endpoint_access("test-endpoint", "Embedding model")

    @patch("autoeval_lib.config.WorkspaceClient")
    def test_check_model_endpoint_access_not_found(self, mock_ws_class):
        """Test model endpoint access check with endpoint not found."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        mock_ws = Mock()
        mock_ws.serving_endpoints.get.side_effect = Exception("Endpoint not found")
        mock_ws_class.return_value = mock_ws

        with pytest.raises(ValueError, match="does not exist"):
            config._check_model_endpoint_access("test-endpoint", "Embedding model")

    @patch("autoeval_lib.config.WorkspaceClient")
    def test_check_model_endpoint_access_permission_denied(self, mock_ws_class):
        """Test model endpoint access check with permission denied."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        mock_ws = Mock()
        mock_ws.serving_endpoints.get.side_effect = Exception("Permission denied")
        mock_ws_class.return_value = mock_ws

        with pytest.raises(ValueError, match="Missing access"):
            config._check_model_endpoint_access("test-endpoint", "LLM")

    def test_check_mlflow_experiment_access_existing_experiment(self):
        """Test MLflow experiment access check with existing experiment."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        with patch("mlflow.get_experiment_by_name") as mock_get:
            mock_experiment = Mock()
            mock_experiment.lifecycle_stage = "active"
            mock_get.return_value = mock_experiment

            # Should not raise any error
            config._check_mlflow_experiment_access("/Users/test/experiment")

    def test_check_mlflow_experiment_access_deleted_experiment(self):
        """Test MLflow experiment access check with deleted experiment."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        with patch("mlflow.get_experiment_by_name") as mock_get:
            mock_experiment = Mock()
            mock_experiment.lifecycle_stage = "deleted"
            mock_get.return_value = mock_experiment

            with pytest.raises(ValueError, match="has been deleted"):
                config._check_mlflow_experiment_access("/Users/test/experiment")

    def test_check_mlflow_experiment_access_create_and_delete(self):
        """Test MLflow experiment access check creates and deletes test experiment."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        with patch("mlflow.get_experiment_by_name") as mock_get, \
             patch("mlflow.create_experiment") as mock_create, \
             patch("mlflow.delete_experiment") as mock_delete:
            mock_get.return_value = None  # Experiment doesn't exist
            mock_create.return_value = "test-experiment-id"

            # Should not raise any error
            config._check_mlflow_experiment_access("/Users/test/new_experiment")

            # Verify create and delete were called
            mock_create.assert_called_once()
            mock_delete.assert_called_once_with("test-experiment-id")

    def test_check_mlflow_experiment_access_permission_denied(self):
        """Test MLflow experiment access check with permission denied."""
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )

        with patch("mlflow.get_experiment_by_name") as mock_get, \
             patch("mlflow.create_experiment") as mock_create:
            mock_get.return_value = None  # Experiment doesn't exist
            mock_create.side_effect = Exception("Permission denied to create experiment")

            with pytest.raises(ValueError, match="Cannot create MLflow experiment"):
                config._check_mlflow_experiment_access("/Shared/test/experiment")

    @patch("databricks.vector_search.client.VectorSearchClient")
    @patch("autoeval_lib.config.AutoEvalConfig._validate_permissions")
    def test_validate_calls_validate_permissions(self, mock_validate_perms, mock_vsc_class):
        """Test that validate() calls _validate_permissions()."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            query_cache_table="catalog.schema.cache"
        )
        config.validate()

        # Verify _validate_permissions was called
        mock_validate_perms.assert_called_once()

    @patch("autoeval_lib.mlflow_tracker.generate_experiment_path")
    @patch("databricks.vector_search.client.VectorSearchClient")
    def test_validate_permissions_calls_all_checks(self, mock_vsc_class, mock_gen_path):
        """Test that _validate_permissions calls all individual check methods."""
        mock_vsc = Mock()
        mock_vsc.get_index.return_value = self._create_mock_index()
        mock_vsc_class.return_value = mock_vsc
        mock_gen_path.return_value = "/Users/test/experiment"

        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"],
            enable_mlflow_logging=True,
            query_cache_table="catalog.schema.cache"
        )

        # Set up config fields manually (config is already not validated)
        config.endpoint_name = "test-endpoint"
        config.primary_key = "doc_id"
        config.corpus_table = "catalog.schema.source"
        config.embedding_model = "databricks-gte-large-en"
        config.query_generation_llm_endpoint = "databricks-gpt-5-mini"

        # Mock all the check methods
        with patch.object(config, '_check_table_read_access') as mock_table, \
             patch.object(config, '_check_model_endpoint_access') as mock_endpoint, \
             patch.object(config, '_check_mlflow_experiment_access') as mock_mlflow:

            # Call _validate_permissions directly
            config._validate_permissions()

            # Verify all checks were called
            mock_table.assert_called_once_with("catalog.schema.source")
            assert mock_endpoint.call_count == 3  # embedding + query gen LLM + relevance judge LLM
            mock_mlflow.assert_called_once()
