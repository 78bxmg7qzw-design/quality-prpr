"""Tests for prompts module."""

import pytest
from autoeval_lib.prompts import (
    DEFAULT_FEW_SHOT_EXAMPLES,
    QUERY_GENERATION_BASE_PROMPT_NATURAL,
    QUERY_GENERATION_BASE_PROMPT_KEYWORD,
    RELEVANCE_SCORING_PROMPT,
    build_query_generation_prompt,
    build_relevance_scoring_prompt,
    _clean_text,
)


class TestCleanText:
    """Tests for _clean_text helper function."""

    def test_clean_text_removes_quotes(self):
        """Test that quotes are removed."""
        text = 'He said "hello" and \'goodbye\''
        result = _clean_text(text)
        assert '"' not in result
        assert "'" not in result

    def test_clean_text_removes_newlines(self):
        """Test that newlines are replaced with spaces."""
        text = "Line 1\nLine 2\nLine 3"
        result = _clean_text(text)
        assert "\n" not in result
        assert "Line 1 Line 2 Line 3" == result

    def test_clean_text_strips_whitespace(self):
        """Test that leading/trailing whitespace is stripped."""
        text = "  hello world  "
        result = _clean_text(text)
        assert result == "hello world"

    def test_clean_text_handles_empty_string(self):
        """Test that empty string is handled."""
        assert _clean_text("") == ""

    def test_clean_text_handles_none(self):
        """Test that None is handled."""
        assert _clean_text(None) == ""


class TestBuildQueryGenerationPrompt:
    """Tests for build_query_generation_prompt function."""

    def test_natural_style_uses_natural_prompt(self):
        """Test that natural style uses the natural language prompt."""
        prompt = build_query_generation_prompt(
            doc_text="Test document",
            few_shot_examples=[{"document": "Example doc", "query": "example query"}],
            style="natural"
        )
        assert "natural language queries" in prompt

    def test_keyword_style_uses_keyword_prompt(self):
        """Test that keyword style uses the keyword prompt."""
        prompt = build_query_generation_prompt(
            doc_text="Test document",
            few_shot_examples=[{"document": "Example doc", "query": "example query"}],
            style="keyword"
        )
        assert "keyword-style" in prompt

    def test_includes_few_shot_examples(self):
        """Test that few-shot examples are included in prompt."""
        examples = [
            {"document": "Doc about cats", "query": "cat behavior"},
            {"document": "Doc about dogs", "query": "dog training"},
        ]
        prompt = build_query_generation_prompt(
            doc_text="Test document",
            few_shot_examples=examples,
            style="natural"
        )
        assert "cat behavior" in prompt
        assert "dog training" in prompt

    def test_includes_target_document(self):
        """Test that target document is included at the end."""
        prompt = build_query_generation_prompt(
            doc_text="This is my test document about Python",
            few_shot_examples=[{"document": "Example", "query": "query"}],
            style="natural"
        )
        assert "This is my test document about Python" in prompt
        assert prompt.endswith("Query:")

    def test_cleans_document_text(self):
        """Test that document text is cleaned."""
        prompt = build_query_generation_prompt(
            doc_text='Text with "quotes" and\nnewlines',
            few_shot_examples=[{"document": "Example", "query": "query"}],
            style="natural"
        )
        # The document content should have quotes removed and newlines replaced
        # Get the document content between the last Document: and Query:
        last_doc_section = prompt.split("Document:")[-1].split("Query:")[0]
        assert "quotes" in last_doc_section  # word is there
        assert "and newlines" in last_doc_section  # newline was replaced with space

    def test_default_style_is_natural(self):
        """Test that default style is natural."""
        prompt = build_query_generation_prompt(
            doc_text="Test",
            few_shot_examples=[{"document": "Ex", "query": "q"}]
        )
        assert "natural language queries" in prompt


class TestBuildRelevanceScoringPrompt:
    """Tests for build_relevance_scoring_prompt function."""

    def test_includes_query(self):
        """Test that query is included in prompt."""
        prompt = build_relevance_scoring_prompt(
            query="what is machine learning",
            document="Machine learning is a type of AI."
        )
        assert "what is machine learning" in prompt

    def test_includes_document(self):
        """Test that document is included in prompt."""
        prompt = build_relevance_scoring_prompt(
            query="test query",
            document="This is the document content about testing."
        )
        assert "This is the document content about testing" in prompt

    def test_includes_scoring_scale(self):
        """Test that scoring scale is included."""
        prompt = build_relevance_scoring_prompt(
            query="test",
            document="doc"
        )
        assert "3 - Highly Relevant" in prompt
        assert "2 - Relevant" in prompt
        assert "1 - Partially Relevant" in prompt
        assert "0 - Not Relevant" in prompt

    def test_cleans_query_and_document(self):
        """Test that query and document are cleaned."""
        prompt = build_relevance_scoring_prompt(
            query='query with "quotes"',
            document='document with\nnewlines'
        )
        # The cleaned text should not have quotes or newlines
        assert '"\n' not in prompt


class TestDefaultFewShotExamples:
    """Tests for DEFAULT_FEW_SHOT_EXAMPLES."""

    def test_default_examples_not_empty(self):
        """Test that default examples exist."""
        assert len(DEFAULT_FEW_SHOT_EXAMPLES) > 0

    def test_default_examples_have_required_keys(self):
        """Test that all default examples have document and query keys."""
        for example in DEFAULT_FEW_SHOT_EXAMPLES:
            assert "document" in example
            assert "query" in example

    def test_default_examples_have_content(self):
        """Test that default examples have non-empty content."""
        for example in DEFAULT_FEW_SHOT_EXAMPLES:
            assert len(example["document"]) > 0
            assert len(example["query"]) > 0


class TestPromptConstants:
    """Tests for prompt constant strings."""

    def test_natural_prompt_exists(self):
        """Test that natural prompt constant exists and is non-empty."""
        assert len(QUERY_GENERATION_BASE_PROMPT_NATURAL) > 0

    def test_keyword_prompt_exists(self):
        """Test that keyword prompt constant exists and is non-empty."""
        assert len(QUERY_GENERATION_BASE_PROMPT_KEYWORD) > 0

    def test_relevance_prompt_exists(self):
        """Test that relevance prompt constant exists and is non-empty."""
        assert len(RELEVANCE_SCORING_PROMPT) > 0

    def test_relevance_prompt_has_placeholders(self):
        """Test that relevance prompt has query and document placeholders."""
        assert "{query}" in RELEVANCE_SCORING_PROMPT
        assert "{document}" in RELEVANCE_SCORING_PROMPT
