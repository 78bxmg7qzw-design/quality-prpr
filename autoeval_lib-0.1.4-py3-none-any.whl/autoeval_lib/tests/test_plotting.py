"""Tests for plotting module."""

import pytest
import sys
from unittest.mock import MagicMock, patch

from autoeval_lib.constants import MetricType


def create_mock_analyzer():
    """Helper to create a mock MetricsAnalyzer for plotting tests."""
    mock_analyzer = MagicMock()
    mock_analyzer.recall_at_k.return_value = (0.75, 0.04)
    mock_analyzer.precision_at_k.return_value = (0.50, 0.03)
    mock_analyzer.ndcg_at_k.return_value = (0.65, 0.03)
    mock_analyzer.map_at_k.return_value = (0.60, 0.03)
    mock_analyzer.mrr.return_value = (0.55, 0.04)
    return mock_analyzer


def create_mock_eval_result(query_type: str):
    """Helper to create a mock EvalResult."""
    mock_result = MagicMock()
    mock_result.query_type = query_type
    mock_result.analyzer = create_mock_analyzer()
    return mock_result


class TestGetKColors:
    """Tests for _get_k_colors helper function."""

    def test_get_k_colors_returns_dict(self):
        """Test that _get_k_colors returns a dict mapping k values to colors."""
        from autoeval_lib.plotting import _get_k_colors

        k_values = [1, 3, 5, 10]
        colors = _get_k_colors(k_values)

        assert isinstance(colors, dict)
        assert len(colors) == 4
        assert all(k in colors for k in k_values)

    def test_get_k_colors_returns_strings(self):
        """Test that colors are hex strings."""
        from autoeval_lib.plotting import _get_k_colors

        colors = _get_k_colors([1, 5])

        for k, color in colors.items():
            assert isinstance(color, str)
            assert color.startswith("#") or color in colors.values()

    def test_get_k_colors_handles_many_values(self):
        """Test that colors cycle for more than 10 k values."""
        from autoeval_lib.plotting import _get_k_colors

        k_values = list(range(1, 15))
        colors = _get_k_colors(k_values)

        assert len(colors) == 14
        # All k values should have colors assigned
        assert all(k in colors for k in k_values)


class TestPlotMetricsAtK:
    """Tests for plot_metrics_at_k function."""

    def test_plot_metrics_at_k_recall(self):
        """Test that plot_metrics_at_k works for recall."""
        from autoeval_lib.plotting import plot_metrics_at_k

        # Get the mock plotly module from sys.modules
        mock_go = sys.modules["plotly.graph_objects"]
        mock_fig = MagicMock()
        mock_go.Figure.return_value = mock_fig
        mock_go.Scatter.return_value = MagicMock()

        results = {
            "FULL_TEXT": create_mock_eval_result("FULL_TEXT"),
            "ANN": create_mock_eval_result("ANN"),
        }

        fig = plot_metrics_at_k(results, MetricType.RECALL, k_values=[1, 5])

        assert fig is not None
        # Should add traces for each k value
        assert mock_fig.add_trace.call_count == 2

    def test_plot_metrics_at_k_precision(self):
        """Test that plot_metrics_at_k works for precision."""
        from autoeval_lib.plotting import plot_metrics_at_k

        mock_go = sys.modules["plotly.graph_objects"]
        mock_fig = MagicMock()
        mock_go.Figure.return_value = mock_fig
        mock_go.Scatter.return_value = MagicMock()

        results = {"HYBRID": create_mock_eval_result("HYBRID")}

        fig = plot_metrics_at_k(results, MetricType.PRECISION, k_values=[1, 3, 5, 10])

        assert fig is not None
        assert mock_fig.add_trace.call_count == 4

    def test_plot_metrics_at_k_ndcg(self):
        """Test that plot_metrics_at_k works for ndcg."""
        from autoeval_lib.plotting import plot_metrics_at_k

        mock_go = sys.modules["plotly.graph_objects"]
        mock_fig = MagicMock()
        mock_go.Figure.return_value = mock_fig
        mock_go.Scatter.return_value = MagicMock()

        results = {"ANN": create_mock_eval_result("ANN")}

        fig = plot_metrics_at_k(results, MetricType.NDCG, k_values=[1, 10])

        assert fig is not None
        assert mock_fig.add_trace.call_count == 2

    def test_plot_metrics_at_k_empty_results(self):
        """Test that plot_metrics_at_k returns None for empty results."""
        from autoeval_lib.plotting import plot_metrics_at_k

        fig = plot_metrics_at_k({}, MetricType.RECALL, k_values=[1, 5])

        assert fig is None

    def test_plot_metrics_at_k_invalid_metric_type(self):
        """Test that plot_metrics_at_k handles invalid metric type gracefully."""
        from autoeval_lib.plotting import plot_metrics_at_k

        results = {"FULL_TEXT": create_mock_eval_result("FULL_TEXT")}

        # Should return None and print error
        fig = plot_metrics_at_k(results, "invalid_metric", k_values=[1])

        assert fig is None

    def test_plot_metrics_at_k_with_dynamic_k_values(self):
        """Test that plot_metrics_at_k works with dynamically computed k_values."""
        from autoeval_lib.plotting import plot_metrics_at_k

        mock_go = sys.modules["plotly.graph_objects"]
        mock_fig = MagicMock()
        mock_go.Figure.return_value = mock_fig
        mock_go.Scatter.return_value = MagicMock()

        results = {"FULL_TEXT": create_mock_eval_result("FULL_TEXT")}

        # Test with k_values from num_results=25 (as computed by compute_k_values)
        k_values = [1, 3, 5, 10, 20, 25]
        fig = plot_metrics_at_k(results, MetricType.RECALL, k_values=k_values)

        assert fig is not None
        # Should add one trace per k value
        assert mock_fig.add_trace.call_count == len(k_values)


class TestPlotMRR:
    """Tests for plot_mrr function."""

    def test_plot_mrr_returns_figure(self):
        """Test that plot_mrr returns a figure."""
        from autoeval_lib.plotting import plot_mrr

        mock_go = sys.modules["plotly.graph_objects"]
        mock_fig = MagicMock()
        mock_go.Figure.return_value = mock_fig
        mock_go.Scatter.return_value = MagicMock()

        results = {
            "FULL_TEXT": create_mock_eval_result("FULL_TEXT"),
            "ANN": create_mock_eval_result("ANN"),
        }

        fig = plot_mrr(results)

        assert fig is not None
        # Should add one trace for MRR
        assert mock_fig.add_trace.call_count == 1

    def test_plot_mrr_empty_results(self):
        """Test that plot_mrr returns None for empty results."""
        from autoeval_lib.plotting import plot_mrr

        fig = plot_mrr({})

        assert fig is None

    def test_plot_mrr_custom_title(self):
        """Test that plot_mrr accepts custom title."""
        from autoeval_lib.plotting import plot_mrr

        mock_go = sys.modules["plotly.graph_objects"]
        mock_fig = MagicMock()
        mock_go.Figure.return_value = mock_fig
        mock_go.Scatter.return_value = MagicMock()

        results = {"FULL_TEXT": create_mock_eval_result("FULL_TEXT")}

        fig = plot_mrr(results, title="Custom MRR Title")

        assert fig is not None
        # Verify update_layout was called (which sets title)
        mock_fig.update_layout.assert_called_once()


class TestPlotlyImportError:
    """Tests for handling plotly import errors."""

    def test_plot_metrics_at_k_without_plotly(self):
        """Test that plot_metrics_at_k handles missing plotly gracefully."""
        # This test is a placeholder since plotly is already mocked in conftest.py
        # The actual behavior when plotly is missing is tested by the code itself
        # which prints an error message and returns None
        pass
