"""Tests for search_client module."""

import pytest
from unittest.mock import MagicMock, patch


class TestSearchClientInit:
    """Tests for SearchClient initialization."""

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_init_creates_vector_search_client(self, mock_spark_session, mock_vsc_class):
        """Test that init creates VectorSearchClient."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_vsc = MagicMock()
        mock_vsc_class.return_value = mock_vsc

        client = SearchClient("my_endpoint", "catalog.schema.index", "doc_id")

        mock_vsc_class.assert_called_once_with(disable_notice=True)
        mock_vsc.get_index.assert_called_once_with(
            endpoint_name="my_endpoint",
            index_name="catalog.schema.index"
        )

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_init_stores_endpoint_and_index_names(self, mock_spark_session, mock_vsc_class):
        """Test that init stores endpoint and index names."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_vsc_class.return_value = MagicMock()

        client = SearchClient("test_endpoint", "test_catalog.test_schema.test_index", "doc_id")

        assert client.endpoint_name == "test_endpoint"
        assert client.index_name == "test_catalog.test_schema.test_index"
        assert client.primary_key == "doc_id"


class TestSearchBatch:
    """Tests for search_batch method."""

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_search_batch_invalid_query_type_raises_error(self, mock_spark_session, mock_vsc_class):
        """Test that invalid query_type raises ValueError."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_vsc_class.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")
        mock_queries_df = MagicMock()

        with pytest.raises(ValueError, match="query_type must be"):
            client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type="INVALID")

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_search_batch_valid_query_types(self, mock_spark_session, mock_vsc_class):
        """Test that valid query types are accepted."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Mock empty results
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = []
        mock_queries_df.count.return_value = 0
        mock_spark.createDataFrame.return_value = MagicMock()

        # Mock embeddings DataFrame for ANN/HYBRID
        mock_embeddings_df = MagicMock()
        mock_embeddings_df.collect.return_value = []

        client = SearchClient("ep", "idx", "doc_id")

        # Patch embedding methods for ANN/HYBRID tests
        with patch.object(client, '_resolve_embedding_model', return_value="test-model"), \
             patch.object(client, '_get_query_embeddings', return_value=mock_embeddings_df):
            for query_type in ["FULL_TEXT", "ANN", "HYBRID"]:
                # Should not raise
                client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type=query_type)

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_search_batch_adds_primary_key_to_custom_columns(self, mock_spark_session, mock_vsc_class):
        """Test that primary key is added to custom columns if not present."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "my_pk": "doc1",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]
        mock_spark.createDataFrame.return_value = MagicMock()

        client = SearchClient("ep", "idx", "my_pk")
        client.search_batch(mock_queries_df, columns=["title", "text"])

        # Verify primary key was added to front of columns
        call_args = mock_index.similarity_search.call_args
        assert call_args[1]["columns"] == ["my_pk", "title", "text"]

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    @patch("autoeval_lib.search_client.Row")
    def test_search_batch_parses_results_correctly(self, mock_row_class, mock_spark_session, mock_vsc_class):
        """Test that search results are parsed correctly."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}

        # Mock search results
        mock_index.similarity_search.return_value = {
            "result": {
                "data_array": [
                    ["retrieved_doc_1", "Title 1", "Text 1", 0.95],
                    ["retrieved_doc_2", "Title 2", "Text 2", 0.85],
                ]
            }
        }
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "doc_id": "original_doc",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]

        # Capture the data passed to createDataFrame
        created_rows = []

        def capture_row(**kwargs):
            created_rows.append(kwargs)
            return MagicMock()

        mock_row_class.side_effect = capture_row
        mock_spark.createDataFrame.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")
        client.search_batch(mock_queries_df, columns=["doc_id", "title", "text"])

        # Verify two results were created
        assert len(created_rows) == 2

        # Check first result structure
        first_result = created_rows[0]
        assert first_result["original_doc_id"] == "original_doc"
        assert first_result["query"] == "test query"
        assert first_result["result_rank"] == 1
        assert first_result["retrieved_doc_id"] == "retrieved_doc_1"
        # retrieved_text is all non-primary-key columns joined
        assert first_result["retrieved_text"] == "Title 1 Text 1"
        assert first_result["search_score"] == 0.95

        # Check second result has rank 2
        second_result = created_rows[1]
        assert second_result["result_rank"] == 2
        assert second_result["retrieved_doc_id"] == "retrieved_doc_2"

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_search_batch_handles_errors_gracefully(self, mock_spark_session, mock_vsc_class):
        """Test that search errors are handled gracefully."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}

        # Make search raise an exception
        mock_index.similarity_search.side_effect = RuntimeError("Search failed")
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "doc_id": "doc1",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]
        mock_spark.createDataFrame.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")

        # Should not raise - errors are printed and skipped
        client.search_batch(mock_queries_df, columns=["doc_id", "text"])

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_search_batch_passes_disable_notice_full_text(self, mock_spark_session, mock_vsc_class):
        """Test that disable_notice=True is passed to similarity_search for FULL_TEXT."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "doc_id": "doc1",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]
        mock_spark.createDataFrame.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")
        client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type="FULL_TEXT")

        call_args = mock_index.similarity_search.call_args
        assert call_args[1]["disable_notice"] is True

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    @patch("autoeval_lib.search_client.Row")
    def test_search_batch_passes_disable_notice_ann(self, mock_row_class, mock_spark_session, mock_vsc_class):
        """Test that disable_notice=True is passed to similarity_search for ANN."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "doc_id": "doc1",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]
        mock_spark.createDataFrame.return_value = MagicMock()

        # Mock embeddings
        mock_embeddings_row = MagicMock()
        mock_embeddings_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]
        mock_embeddings_df = MagicMock()
        mock_embeddings_df.collect.return_value = [mock_embeddings_row]

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_resolve_embedding_model', return_value="model"), \
             patch.object(client, '_get_query_embeddings', return_value=mock_embeddings_df):

            client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type="ANN")

            call_args = mock_index.similarity_search.call_args
            assert call_args[1]["disable_notice"] is True


class TestResolveEmbeddingModel:
    """Tests for _resolve_embedding_model method."""

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_returns_provided_model(self, mock_spark_session, mock_vsc_class):
        """Test that provided embedding_model is returned directly."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_vsc_class.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")
        result = client._resolve_embedding_model("my-embedding-model")

        assert result == "my-embedding-model"

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_gets_model_from_index_status(self, mock_spark_session, mock_vsc_class):
        """Test that model is retrieved from index status when not provided."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {
            "delta_sync_index_spec": {
                "embedding_source_columns": [
                    {"embedding_model_endpoint_name": "databricks-gte-large-en"}
                ]
            }
        }
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        client = SearchClient("ep", "idx", "doc_id")
        result = client._resolve_embedding_model(None)

        assert result == "databricks-gte-large-en"

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_raises_error_for_self_managed_index(self, mock_spark_session, mock_vsc_class):
        """Test that ValueError is raised for self-managed index without model."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        # Self-managed index has no embedding_source_columns
        mock_index.describe.return_value = {
            "delta_sync_index_spec": {}
        }
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        client = SearchClient("ep", "idx", "doc_id")

        with pytest.raises(ValueError, match="self-managed"):
            client._resolve_embedding_model(None)

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_raises_error_when_describe_fails(self, mock_spark_session, mock_vsc_class):
        """Test that ValueError is raised when index.describe() fails."""
        from autoeval_lib.search_client import SearchClient

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.side_effect = RuntimeError("API error")
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        client = SearchClient("ep", "idx", "doc_id")

        with pytest.raises(ValueError, match="self-managed"):
            client._resolve_embedding_model(None)


class TestGenerateEmbeddings:
    """Tests for _generate_embeddings method."""

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_generates_embeddings_with_ai_query(self, mock_spark_session, mock_vsc_class):
        """Test that embeddings are generated using ai_query."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_result_df = MagicMock()
        mock_result_df.collect.return_value = []  # For materialization
        mock_spark.sql.return_value = mock_result_df
        mock_spark.createDataFrame.return_value = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_vsc_class.return_value = MagicMock()

        mock_queries_df = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")
        client._generate_embeddings(mock_queries_df, "my-embedding-model", "doc_id")

        # Verify temp view was created
        mock_queries_df.createOrReplaceTempView.assert_called_once()

        # Verify SQL was executed with ai_query
        sql_call = mock_spark.sql.call_args[0][0]
        assert "ai_query" in sql_call
        assert "my-embedding-model" in sql_call

        # Verify temp view was dropped
        mock_spark.catalog.dropTempView.assert_called_once()

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_cleans_up_temp_view_on_error(self, mock_spark_session, mock_vsc_class):
        """Test that temp view is dropped even when SQL fails."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark.sql.side_effect = Exception("SQL error")
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_vsc_class.return_value = MagicMock()

        mock_queries_df = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")

        with pytest.raises(Exception, match="SQL error"):
            client._generate_embeddings(mock_queries_df, "model", "doc_id")

        # Verify temp view was still dropped
        mock_spark.catalog.dropTempView.assert_called_once()

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_materializes_data_before_returning(self, mock_spark_session, mock_vsc_class):
        """Test that data is materialized (collected) before dropping temp view."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_result_df = MagicMock()
        mock_collected_data = [MagicMock()]
        mock_result_df.collect.return_value = mock_collected_data
        mock_spark.sql.return_value = mock_result_df
        mock_spark.createDataFrame.return_value = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_vsc_class.return_value = MagicMock()

        mock_queries_df = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")
        client._generate_embeddings(mock_queries_df, "model", "doc_id")

        # Verify data was collected (materialized)
        mock_result_df.collect.assert_called_once()

        # Verify createDataFrame was called with the collected data
        mock_spark.createDataFrame.assert_called_once_with(mock_collected_data)


class TestGetQueryEmbeddings:
    """Tests for _get_query_embeddings method."""

    @patch("autoeval_lib.search_client.QueryCache")
    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_generates_all_embeddings_when_cache_empty(self, mock_spark_session, mock_vsc_class, mock_cache_class):
        """Test that all embeddings are generated when cache has no hits."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_vsc_class.return_value = MagicMock()

        mock_queries_df = MagicMock()
        mock_cached_df = MagicMock()
        mock_cached_df.count.return_value = 0  # No cache hits
        mock_uncached_df = MagicMock()
        mock_uncached_df.count.return_value = 10  # All queries need embeddings
        mock_union_df = MagicMock()
        mock_cached_df.union.return_value = mock_union_df

        mock_cache = MagicMock()
        mock_cache.get_cached_embeddings.return_value = (mock_cached_df, mock_uncached_df)
        mock_cache_class.return_value = mock_cache

        mock_result_df = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_generate_embeddings', return_value=mock_result_df) as mock_gen:
            result = client._get_query_embeddings(mock_queries_df, "model", "cache_table", "doc_id")

            mock_gen.assert_called_once_with(mock_uncached_df, "model", "doc_id")
            # Result is union of cached (empty) and new embeddings
            mock_cached_df.union.assert_called_once_with(mock_result_df)
            assert result == mock_union_df

    @patch("autoeval_lib.search_client.QueryCache")
    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_uses_cache_when_all_queries_cached(self, mock_spark_session, mock_vsc_class, mock_cache_class):
        """Test that only cached embeddings are returned when all queries are cached."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_vsc_class.return_value = MagicMock()

        mock_queries_df = MagicMock()
        mock_cached_df = MagicMock()
        mock_cached_df.count.return_value = 10
        mock_uncached_df = MagicMock()
        mock_uncached_df.count.return_value = 0

        mock_cache = MagicMock()
        mock_cache.get_cached_embeddings.return_value = (mock_cached_df, mock_uncached_df)
        mock_cache_class.return_value = mock_cache

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_generate_embeddings') as mock_gen:
            result = client._get_query_embeddings(mock_queries_df, "model", "cache_table", "doc_id")

            # Should not generate new embeddings
            mock_gen.assert_not_called()
            assert result == mock_cached_df

    @patch("autoeval_lib.search_client.QueryCache")
    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_generates_and_caches_uncached_queries(self, mock_spark_session, mock_vsc_class, mock_cache_class):
        """Test that uncached queries are generated and cached."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_vsc_class.return_value = MagicMock()

        mock_queries_df = MagicMock()
        mock_cached_df = MagicMock()
        mock_cached_df.count.return_value = 5
        mock_uncached_df = MagicMock()
        mock_uncached_df.count.return_value = 5
        mock_new_embeddings_df = MagicMock()
        mock_union_df = MagicMock()
        mock_cached_df.union.return_value = mock_union_df

        mock_cache = MagicMock()
        mock_cache.get_cached_embeddings.return_value = (mock_cached_df, mock_uncached_df)
        mock_cache_class.return_value = mock_cache

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_generate_embeddings', return_value=mock_new_embeddings_df) as mock_gen:
            result = client._get_query_embeddings(mock_queries_df, "model", "cache_table", "doc_id")

            # Should generate embeddings for uncached
            mock_gen.assert_called_once_with(mock_uncached_df, "model", "doc_id")

            # Should cache new embeddings using batch method
            mock_cache.store_embeddings_batch.assert_called_once_with(mock_new_embeddings_df)
            # Old store_embeddings should NOT be called
            mock_cache.store_embeddings.assert_not_called()

            # Should return union
            mock_cached_df.union.assert_called_once_with(mock_new_embeddings_df)
            assert result == mock_union_df


class TestSearchBatchWithEmbeddings:
    """Tests for search_batch with ANN/HYBRID and embeddings."""

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    @patch("autoeval_lib.search_client.Row")
    def test_ann_search_uses_query_vector(self, mock_row_class, mock_spark_session, mock_vsc_class):
        """Test that ANN search uses query_vector instead of query_text."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "doc_id": "doc1",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]
        mock_spark.createDataFrame.return_value = MagicMock()

        # Mock embeddings
        mock_embeddings_row = MagicMock()
        mock_embeddings_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]
        mock_embeddings_df = MagicMock()
        mock_embeddings_df.collect.return_value = [mock_embeddings_row]

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_resolve_embedding_model', return_value="model"), \
             patch.object(client, '_get_query_embeddings', return_value=mock_embeddings_df):

            client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type="ANN")

            # Verify similarity_search was called with query_vector
            call_args = mock_index.similarity_search.call_args
            assert "query_vector" in call_args[1]
            assert call_args[1]["query_vector"] == [0.1, 0.2, 0.3]
            assert call_args[1]["query_text"] is None

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    @patch("autoeval_lib.search_client.Row")
    def test_hybrid_search_uses_both_vector_and_text(self, mock_row_class, mock_spark_session, mock_vsc_class):
        """Test that HYBRID search uses both query_vector and query_text."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        # Create mock query row with keys matching the index primary key
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "doc_id": "doc1",
            "generated_query": "test query"
        }[key]

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = [mock_row]
        mock_spark.createDataFrame.return_value = MagicMock()

        # Mock embeddings
        mock_embeddings_row = MagicMock()
        mock_embeddings_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]
        mock_embeddings_df = MagicMock()
        mock_embeddings_df.collect.return_value = [mock_embeddings_row]

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_resolve_embedding_model', return_value="model"), \
             patch.object(client, '_get_query_embeddings', return_value=mock_embeddings_df):

            client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type="HYBRID")

            # Verify similarity_search was called with both
            call_args = mock_index.similarity_search.call_args
            assert call_args[1]["query_vector"] == [0.1, 0.2, 0.3]
            assert call_args[1]["query_text"] == "test query"

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_full_text_search_does_not_use_embeddings(self, mock_spark_session, mock_vsc_class):
        """Test that FULL_TEXT search doesn't call embedding methods."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = []
        mock_spark.createDataFrame.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_resolve_embedding_model') as mock_resolve, \
             patch.object(client, '_get_query_embeddings') as mock_get_emb:

            client.search_batch(mock_queries_df, columns=["doc_id", "text"], query_type="FULL_TEXT")

            # Should not call embedding methods
            mock_resolve.assert_not_called()
            mock_get_emb.assert_not_called()

    @patch("autoeval_lib.search_client.VectorSearchClient")
    @patch("autoeval_lib.search_client.SparkSession")
    def test_passes_embedding_model_and_cache_table(self, mock_spark_session, mock_vsc_class):
        """Test that embedding_model and cache_table are passed through."""
        from autoeval_lib.search_client import SearchClient

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_vsc = MagicMock()
        mock_index = MagicMock()
        mock_index.describe.return_value = {"primary_key": "doc_id"}
        mock_index.similarity_search.return_value = {"result": {"data_array": []}}
        mock_vsc.get_index.return_value = mock_index
        mock_vsc_class.return_value = mock_vsc

        mock_queries_df = MagicMock()
        mock_queries_df.collect.return_value = []

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.collect.return_value = []

        mock_spark.createDataFrame.return_value = MagicMock()

        client = SearchClient("ep", "idx", "doc_id")

        with patch.object(client, '_resolve_embedding_model', return_value="resolved-model") as mock_resolve, \
             patch.object(client, '_get_query_embeddings', return_value=mock_embeddings_df) as mock_get_emb:

            client.search_batch(
                mock_queries_df,
                columns=["doc_id", "text"],
                query_type="ANN",
                embedding_model="custom-model",
                query_cache_table="catalog.schema.cache"
            )

            # Verify resolve was called with the provided model
            mock_resolve.assert_called_once_with("custom-model")

            # Verify get_query_embeddings was called with cache table and primary key
            mock_get_emb.assert_called_once_with(
                mock_queries_df,
                "resolved-model",
                "catalog.schema.cache",
                "doc_id"
            )
