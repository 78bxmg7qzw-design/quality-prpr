"""Shared test fixtures for autoeval_lib tests."""

import sys
from unittest.mock import MagicMock

# Mock mlflow before any imports that might use it
# This allows tests to run without mlflow installed
# Note: pyspark mocking is handled by root conftest.py
sys.modules['mlflow'] = MagicMock()

import pytest


@pytest.fixture
def mock_spark_session():
    """Create a mock SparkSession."""
    mock_spark = MagicMock()

    # Mock sql() to return a mock DataFrame
    mock_df = MagicMock()
    mock_spark.sql.return_value = mock_df

    # Mock createDataFrame
    mock_spark.createDataFrame.return_value = mock_df

    return mock_spark


@pytest.fixture
def mock_spark_row():
    """Create a mock Spark Row."""
    def _create_row(**kwargs):
        row = MagicMock()
        row.__getitem__ = lambda self, key: kwargs.get(key)
        row.asDict.return_value = kwargs
        return row
    return _create_row


@pytest.fixture
def mock_vector_search_client():
    """Create a mock VectorSearchClient."""
    mock_vsc = MagicMock()
    mock_index = MagicMock()
    mock_vsc.get_index.return_value = mock_index
    return mock_vsc, mock_index


@pytest.fixture
def sample_documents():
    """Sample document data for testing."""
    return [
        {
            "doc_id": "doc1",
            "text": "Antibiotics fight bacterial infections by killing bacteria.",
            "title": "Antibiotics Overview"
        },
        {
            "doc_id": "doc2",
            "text": "Machine learning algorithms can be supervised or unsupervised.",
            "title": "ML Basics"
        },
        {
            "doc_id": "doc3",
            "text": "The Python programming language was created by Guido van Rossum.",
            "title": "Python History"
        },
    ]


@pytest.fixture
def sample_queries():
    """Sample query data for testing."""
    return [
        {
            "doc_id": "doc1",
            "doc_text": "Antibiotics fight bacterial infections.",
            "generated_query": "what do antibiotics do"
        },
        {
            "doc_id": "doc2",
            "doc_text": "Machine learning algorithms can be supervised.",
            "generated_query": "types of machine learning"
        },
    ]


@pytest.fixture
def sample_search_results():
    """Sample search results for testing."""
    return [
        {
            "original_doc_id": "doc1",
            "query": "what do antibiotics do",
            "result_rank": 1,
            "retrieved_doc_id": "doc1",
            "retrieved_title": "Antibiotics Overview",
            "retrieved_text": "Antibiotics fight bacterial infections.",
            "search_score": 0.95
        },
        {
            "original_doc_id": "doc1",
            "query": "what do antibiotics do",
            "result_rank": 2,
            "retrieved_doc_id": "doc5",
            "retrieved_title": "Bacteria",
            "retrieved_text": "Bacteria are single-celled organisms.",
            "search_score": 0.72
        },
    ]


@pytest.fixture
def sample_scored_results():
    """Sample scored results for testing."""
    return [
        {
            "original_doc_id": "doc1",
            "query": "what do antibiotics do",
            "result_rank": 1,
            "retrieved_doc_id": "doc1",
            "retrieved_text": "Antibiotics fight bacterial infections.",
            "search_score": 0.95,
            "llm_relevance_score": 3
        },
        {
            "original_doc_id": "doc1",
            "query": "what do antibiotics do",
            "result_rank": 2,
            "retrieved_doc_id": "doc5",
            "retrieved_text": "Bacteria are single-celled organisms.",
            "search_score": 0.72,
            "llm_relevance_score": 1
        },
        {
            "original_doc_id": "doc2",
            "query": "machine learning types",
            "result_rank": 1,
            "retrieved_doc_id": "doc2",
            "retrieved_text": "Machine learning can be supervised or unsupervised.",
            "search_score": 0.88,
            "llm_relevance_score": 3
        },
        {
            "original_doc_id": "doc2",
            "query": "machine learning types",
            "result_rank": 2,
            "retrieved_doc_id": "doc10",
            "retrieved_text": "Deep learning is a subset of machine learning.",
            "search_score": 0.65,
            "llm_relevance_score": 2
        },
    ]
