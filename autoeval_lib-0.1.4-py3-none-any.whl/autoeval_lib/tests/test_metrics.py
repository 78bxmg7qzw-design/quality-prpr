"""Tests for metrics module."""

import pytest
from unittest.mock import MagicMock, patch


def create_mock_df(total=100, highly_relevant=25, relevant=50, not_relevant=10, avg_score=2.5):
    """Helper to create a properly configured mock DataFrame."""
    mock_df = MagicMock()
    mock_df.count.return_value = total

    # For _cache_metrics, we need filter to return different counts
    # based on what's being filtered. Use side_effect to handle this.
    filter_results = MagicMock()
    filter_results.count.return_value = highly_relevant  # default for filter().count()

    mock_df.filter.return_value = filter_results
    mock_df.agg.return_value.collect.return_value = [[avg_score]]

    # For recall_at_k
    filter_results.select.return_value.distinct.return_value.count.return_value = 80
    mock_df.select.return_value.distinct.return_value.count.return_value = 100

    return mock_df


class TestMetricsAnalyzerInit:
    """Tests for MetricsAnalyzer initialization."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_init_stores_dataframe(self, mock_avg, mock_col):
        """Test that init stores the DataFrame."""
        from autoeval_lib.metrics import MetricsAnalyzer

        # Make col() return something that supports comparison
        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        assert analyzer.df == mock_df

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_init_caches_total(self, mock_avg, mock_col):
        """Test that init caches total count."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df(total=100)
        analyzer = MetricsAnalyzer(mock_df)

        assert analyzer._total == 100


class TestSummary:
    """Tests for summary method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_summary_returns_string(self, mock_avg, mock_col):
        """Test that summary returns a formatted string."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)
        summary = analyzer.summary()

        assert isinstance(summary, str)
        assert "AUTOEVAL RESULTS SUMMARY" in summary

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_summary_includes_total(self, mock_avg, mock_col):
        """Test that summary includes total count."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df(total=100)
        analyzer = MetricsAnalyzer(mock_df)
        summary = analyzer.summary()

        assert "100" in summary


class TestScoreDistribution:
    """Tests for score_distribution method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.count")
    def test_score_distribution_groups_by_score(self, mock_count, mock_avg, mock_col):
        """Test that score_distribution groups by llm_relevance_score."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_grouped = MagicMock()
        mock_df.groupBy.return_value = mock_grouped

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.score_distribution()

        mock_df.groupBy.assert_called_with("llm_relevance_score")


class TestAvgByQuery:
    """Tests for avg_by_query method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.count")
    def test_avg_by_query_groups_by_query(self, mock_count, mock_avg, mock_col):
        """Test that avg_by_query groups by query."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.desc.return_value = MagicMock()

        mock_df = create_mock_df()
        mock_grouped = MagicMock()
        mock_df.groupBy.return_value = mock_grouped

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.avg_by_query()

        mock_df.groupBy.assert_called_with("query")


class TestTopAndBottomQueries:
    """Tests for top_queries and bottom_queries methods."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.count")
    def test_top_queries_calls_limit(self, mock_count, mock_avg, mock_col):
        """Test that top_queries limits results."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.desc.return_value = MagicMock()

        mock_df = create_mock_df()
        mock_grouped = MagicMock()
        mock_agg = MagicMock()
        mock_ordered = MagicMock()

        mock_df.groupBy.return_value = mock_grouped
        mock_grouped.agg.return_value = mock_agg
        mock_agg.orderBy.return_value = mock_ordered

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.top_queries(n=5)

        mock_ordered.limit.assert_called_with(5)

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.count")
    def test_bottom_queries_calls_limit(self, mock_count, mock_avg, mock_col):
        """Test that bottom_queries limits results."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.desc.return_value = MagicMock()

        mock_df = create_mock_df()
        mock_grouped = MagicMock()
        mock_agg = MagicMock()
        mock_ordered = MagicMock()
        mock_reordered = MagicMock()

        mock_df.groupBy.return_value = mock_grouped
        mock_grouped.agg.return_value = mock_agg
        mock_agg.orderBy.return_value = mock_ordered
        mock_ordered.orderBy.return_value = mock_reordered

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.bottom_queries(n=3)

        mock_reordered.limit.assert_called_with(3)


class TestRelevanceExamples:
    """Tests for high_relevance_examples and low_relevance_examples methods."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_high_relevance_examples_calls_filter(self, mock_avg, mock_col):
        """Test that high_relevance_examples filters the DataFrame."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)
        analyzer.high_relevance_examples(n=10)

        # Verify filter was called
        assert mock_df.filter.called

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_low_relevance_examples_calls_filter(self, mock_avg, mock_col):
        """Test that low_relevance_examples filters the DataFrame."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)
        analyzer.low_relevance_examples(n=5)

        # Verify filter was called
        assert mock_df.filter.called


class TestRecallAtK:
    """Tests for recall_at_k method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_at_k_returns_tuple(self, mock_avg, mock_col):
        """Test that recall_at_k returns a (recall, ci_margin) tuple."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)
        result = analyzer.recall_at_k()

        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], float)
        assert isinstance(result[1], float)

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_at_k_handles_zero_queries(self, mock_avg, mock_col):
        """Test that recall_at_k handles zero total queries."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = MagicMock()
        mock_df.count.return_value = 0
        mock_df.filter.return_value.count.return_value = 0
        mock_df.agg.return_value.collect.return_value = [[None]]
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 0
        mock_df.select.return_value.distinct.return_value.count.return_value = 0

        analyzer = MetricsAnalyzer(mock_df)
        recall, ci_margin = analyzer.recall_at_k()

        assert recall == 0.0
        assert ci_margin == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_at_k_calculates_ratio(self, mock_avg, mock_col):
        """Test that recall_at_k calculates hits/total."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        # Override for this specific test
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 80
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        analyzer = MetricsAnalyzer(mock_df)
        recall, _ = analyzer.recall_at_k()

        assert recall == 0.8

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_at_k_with_k_equals_1(self, mock_avg, mock_col):
        """Test that recall_at_k works with k=1."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 50
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        analyzer = MetricsAnalyzer(mock_df)
        recall, ci_margin = analyzer.recall_at_k(k=1)

        assert isinstance(recall, float)
        assert recall == 0.5
        assert ci_margin > 0


class TestWilsonCI:
    """Tests for Wilson score confidence interval."""

    def test_wilson_ci_basic(self):
        """Test Wilson CI computation with typical values."""
        from autoeval_lib.metrics import MetricsAnalyzer

        # Create a minimal mock just to instantiate the class
        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # Test with 50 successes out of 100
            p, margin = analyzer._wilson_ci(50, 100)

            assert p == 0.5
            assert 0.09 < margin < 0.11  # Should be around 0.098

    def test_wilson_ci_zero_total(self):
        """Test Wilson CI handles zero total."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            p, margin = analyzer._wilson_ci(0, 0)

            assert p == 0.0
            assert margin == 0.0

    def test_wilson_ci_extreme_proportion(self):
        """Test Wilson CI with extreme proportions (near 0 or 1)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # Test with 95 successes out of 100
            p, margin = analyzer._wilson_ci(95, 100)

            assert p == 0.95
            assert margin > 0  # Should have some margin


class TestTCI:
    """Tests for t-distribution confidence interval."""

    def test_t_ci_basic(self):
        """Test t-CI computation with typical values."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # Test with known values
            values = [1.0, 2.0, 3.0, 4.0, 5.0]
            mean, margin = analyzer._t_ci(values)

            assert mean == 3.0
            assert margin > 0

    def test_t_ci_empty_list(self):
        """Test t-CI handles empty list."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            mean, margin = analyzer._t_ci([])

            assert mean == 0.0
            assert margin == 0.0

    def test_t_ci_single_value(self):
        """Test t-CI with single value."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            mean, margin = analyzer._t_ci([5.0])

            assert mean == 5.0
            assert margin == 0.0  # No variance with single value


class TestGetMetrics:
    """Tests for get_metrics method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_get_metrics_returns_base_metrics(self, mock_avg, mock_col):
        """Test that get_metrics returns dict with base metrics when no k_values."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 80
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        # Mock groupBy for avg_score
        mock_grouped = MagicMock()
        mock_agg_result = MagicMock()
        mock_df.groupBy.return_value = mock_grouped
        mock_grouped.agg.return_value = mock_agg_result
        mock_agg_result.select.return_value.collect.return_value = [
            MagicMock(avg_score=2.0),
            MagicMock(avg_score=2.5),
            MagicMock(avg_score=3.0),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        # Call without k_values - should only return base metrics
        metrics = analyzer.get_metrics()

        assert isinstance(metrics, dict)

        # Only base metrics should be present
        expected_keys = [
            "avg_relevance_score",
            "highly_relevant_pct",
            "relevant_plus_pct",
            "not_relevant_pct",
            "mrr",
        ]

        for key in expected_keys:
            assert key in metrics
            assert isinstance(metrics[key], tuple)
            assert len(metrics[key]) == 2

        # @k metrics should NOT be present
        assert "recall_at_1" not in metrics
        assert "precision_at_1" not in metrics
        assert "ndcg_at_1" not in metrics

    @patch("autoeval_lib.metrics.log2")
    @patch("autoeval_lib.metrics.count")
    @patch("autoeval_lib.metrics.lit")
    @patch("autoeval_lib.metrics.when")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_get_metrics_with_k_values(
        self, mock_avg, mock_col, mock_sum, mock_when, mock_lit, mock_count, mock_log2
    ):
        """Test that get_metrics includes @k metrics when k_values provided."""
        from autoeval_lib.metrics import MetricsAnalyzer

        # Set up mock col with all comparison operators
        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__truediv__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__add__ = MagicMock(return_value=MagicMock())

        # Set up other pyspark function mocks
        mock_when.return_value = MagicMock()
        mock_when.return_value.otherwise = MagicMock(return_value=MagicMock())
        mock_lit.return_value = MagicMock()
        mock_sum.return_value = MagicMock()
        mock_count.return_value = MagicMock()
        mock_log2.return_value = MagicMock()

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_filtered.filter.return_value = mock_filtered  # Allow chained filters
        mock_filtered.select.return_value.distinct.return_value.count.return_value = 80
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        # Mock groupBy for all metrics - set up default chain
        mock_grouped = MagicMock()
        mock_agg_result = MagicMock()
        mock_df.groupBy.return_value = mock_grouped
        mock_filtered.groupBy.return_value = mock_grouped
        mock_grouped.agg.return_value = mock_agg_result

        # Mock withColumn for NDCG calculations
        mock_with_col = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col
        mock_with_col.withColumn.return_value = mock_with_col
        mock_with_col.groupBy.return_value = mock_grouped

        # Set up collect returns for different methods
        mock_agg_result.select.return_value.collect.return_value = [
            MagicMock(avg_score=2.0),
            MagicMock(avg_score=2.5),
            MagicMock(avg_score=3.0),
        ]
        mock_agg_result.withColumn.return_value = mock_agg_result

        # Mock join results for NDCG
        mock_joined = MagicMock()
        mock_agg_result.join.return_value = mock_joined
        mock_joined.withColumn.return_value = mock_joined
        mock_joined.select.return_value.collect.return_value = [
            MagicMock(ndcg=0.8),
            MagicMock(ndcg=0.75),
            MagicMock(ndcg=0.9),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        # Call with k_values - should include @k metrics
        k_values = [1, 3, 5, 10]
        metrics = analyzer.get_metrics(k_values=k_values)

        assert isinstance(metrics, dict)

        # Base metrics should be present
        expected_base_keys = [
            "avg_relevance_score",
            "highly_relevant_pct",
            "relevant_plus_pct",
            "not_relevant_pct",
            "mrr",
        ]

        for key in expected_base_keys:
            assert key in metrics

        # @k metrics should be present for each k in k_values
        for k in k_values:
            assert f"recall_at_{k}" in metrics
            assert f"precision_at_{k}" in metrics
            assert f"ndcg_at_{k}" in metrics
            assert f"dcg_at_{k}" in metrics
            assert f"map_at_{k}" in metrics


class TestPrecisionAtK:
    """Tests for precision_at_k method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.when")
    @patch("autoeval_lib.metrics.lit")
    @patch("autoeval_lib.metrics.count")
    def test_precision_at_k_returns_tuple(
        self, mock_count, mock_lit, mock_when, mock_sum, mock_avg, mock_col
    ):
        """Test that precision_at_k returns (precision, margin) tuple."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_grouped = MagicMock()
        mock_filtered.groupBy.return_value = mock_grouped
        mock_agg_result = MagicMock()
        mock_grouped.agg.return_value = mock_agg_result
        mock_with_col = MagicMock()
        mock_agg_result.withColumn.return_value = mock_with_col
        mock_with_col.select.return_value.collect.return_value = [
            MagicMock(precision=0.6),
            MagicMock(precision=0.7),
            MagicMock(precision=0.8),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        result = analyzer.precision_at_k(k=10)

        assert isinstance(result, tuple)
        assert len(result) == 2


class TestMRR:
    """Tests for mrr method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_min")
    @patch("autoeval_lib.metrics.when")
    def test_mrr_returns_tuple(self, mock_when, mock_min, mock_avg, mock_col):
        """Test that mrr returns (mrr, margin) tuple."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.isNotNull.return_value = MagicMock()

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_grouped = MagicMock()
        mock_filtered.groupBy.return_value = mock_grouped
        mock_agg_result = MagicMock()
        mock_grouped.agg.return_value = mock_agg_result

        mock_distinct = MagicMock()
        mock_df.select.return_value.distinct.return_value = mock_distinct
        mock_joined = MagicMock()
        mock_distinct.join.return_value = mock_joined
        mock_with_col = MagicMock()
        mock_joined.withColumn.return_value = mock_with_col
        mock_with_col.select.return_value.collect.return_value = [
            MagicMock(reciprocal_rank=1.0),
            MagicMock(reciprocal_rank=0.5),
            MagicMock(reciprocal_rank=0.0),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        result = analyzer.mrr()

        assert isinstance(result, tuple)
        assert len(result) == 2


class TestNDCGAtK:
    """Tests for ndcg_at_k method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.log2")
    @patch("autoeval_lib.metrics.when")
    @patch("autoeval_lib.metrics.count")
    @patch("autoeval_lib.metrics.Window")
    def test_ndcg_at_k_returns_tuple(
        self, mock_window, mock_count, mock_when, mock_log2, mock_sum, mock_avg, mock_col
    ):
        """Test that ndcg_at_k returns (ndcg, margin) tuple."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.desc.return_value = MagicMock()

        mock_window_spec = MagicMock()
        mock_window.partitionBy.return_value.orderBy.return_value = mock_window_spec
        mock_window_spec.rowsBetween.return_value = mock_window_spec

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_with_col1 = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col1
        mock_grouped1 = MagicMock()
        mock_with_col1.groupBy.return_value = mock_grouped1
        mock_dcg_df = MagicMock()
        mock_grouped1.agg.return_value = mock_dcg_df

        mock_with_col2 = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col2
        mock_with_col3 = MagicMock()
        mock_with_col2.withColumn.return_value = mock_with_col3
        mock_grouped2 = MagicMock()
        mock_with_col3.groupBy.return_value = mock_grouped2
        mock_idcg_df = MagicMock()
        mock_grouped2.agg.return_value = mock_idcg_df

        mock_joined = MagicMock()
        mock_dcg_df.join.return_value = mock_joined
        mock_ndcg_df = MagicMock()
        mock_joined.withColumn.return_value = mock_ndcg_df
        mock_ndcg_df.select.return_value.collect.return_value = [
            MagicMock(ndcg=0.9),
            MagicMock(ndcg=0.85),
            MagicMock(ndcg=0.8),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        result = analyzer.ndcg_at_k(k=10)

        assert isinstance(result, tuple)
        assert len(result) == 2


class TestMapAtK:
    """Tests for map_at_k method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.when")
    @patch("autoeval_lib.metrics.Window")
    def test_map_at_k_returns_tuple(
        self, mock_window, mock_when, mock_sum, mock_avg, mock_col
    ):
        """Test that map_at_k returns (map, margin) tuple."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__truediv__ = MagicMock(return_value=MagicMock())

        mock_window_spec = MagicMock()
        mock_window.partitionBy.return_value.orderBy.return_value = mock_window_spec

        mock_sum.return_value = MagicMock()
        mock_sum.return_value.over.return_value = MagicMock()

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered

        mock_with_col1 = MagicMock()
        mock_with_col2 = MagicMock()
        mock_with_col3 = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col1
        mock_with_col1.withColumn.return_value = mock_with_col2
        mock_with_col2.withColumn.return_value = mock_with_col3

        mock_grouped = MagicMock()
        mock_with_col3.groupBy.return_value = mock_grouped
        mock_ap_df = MagicMock()
        mock_grouped.agg.return_value = mock_ap_df
        mock_ap_with_col = MagicMock()
        mock_ap_df.withColumn.return_value = mock_ap_with_col
        mock_ap_with_col.select.return_value.collect.return_value = [
            MagicMock(ap=0.9),
            MagicMock(ap=0.75),
            MagicMock(ap=0.8),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        result = analyzer.map_at_k(k=10)

        assert isinstance(result, tuple)
        assert len(result) == 2


class TestDCGAtK:
    """Tests for dcg_at_k method."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.log2")
    def test_dcg_at_k_returns_tuple(self, mock_log2, mock_sum, mock_avg, mock_col):
        """Test that dcg_at_k returns (dcg, margin) tuple."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__truediv__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__add__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_with_col = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col
        mock_grouped = MagicMock()
        mock_with_col.groupBy.return_value = mock_grouped
        mock_dcg_df = MagicMock()
        mock_grouped.agg.return_value = mock_dcg_df
        mock_dcg_df.select.return_value.collect.return_value = [
            MagicMock(dcg=6.39),
            MagicMock(dcg=4.26),
            MagicMock(dcg=8.02),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        result = analyzer.dcg_at_k(k=10)

        assert isinstance(result, tuple)
        assert len(result) == 2

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.log2")
    def test_dcg_at_k_filters_by_k(self, mock_log2, mock_sum, mock_avg, mock_col):
        """Test that dcg_at_k filters to top k results."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__truediv__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__add__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_with_col = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col
        mock_grouped = MagicMock()
        mock_with_col.groupBy.return_value = mock_grouped
        mock_dcg_df = MagicMock()
        mock_grouped.agg.return_value = mock_dcg_df
        mock_dcg_df.select.return_value.collect.return_value = [
            MagicMock(dcg=3.0),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.dcg_at_k(k=5)

        # Verify filter was called (for result_rank <= k)
        assert mock_df.filter.called

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.log2")
    def test_dcg_at_k_groups_by_query(self, mock_log2, mock_sum, mock_avg, mock_col):
        """Test that dcg_at_k computes DCG per query."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__truediv__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__add__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_with_col = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col
        mock_grouped = MagicMock()
        mock_with_col.groupBy.return_value = mock_grouped
        mock_dcg_df = MagicMock()
        mock_grouped.agg.return_value = mock_dcg_df
        mock_dcg_df.select.return_value.collect.return_value = [
            MagicMock(dcg=6.39),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.dcg_at_k(k=10)

        # Verify groupBy was called with query column
        mock_with_col.groupBy.assert_called_with("query")

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    @patch("autoeval_lib.metrics.spark_sum")
    @patch("autoeval_lib.metrics.log2")
    def test_dcg_at_k_uses_graded_relevance(self, mock_log2, mock_sum, mock_avg, mock_col):
        """Test that dcg_at_k uses graded relevance scores (0-3), not binary."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__truediv__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__add__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        mock_filtered = MagicMock()
        mock_df.filter.return_value = mock_filtered
        mock_with_col = MagicMock()
        mock_filtered.withColumn.return_value = mock_with_col
        mock_grouped = MagicMock()
        mock_with_col.groupBy.return_value = mock_grouped
        mock_dcg_df = MagicMock()
        mock_grouped.agg.return_value = mock_dcg_df
        mock_dcg_df.select.return_value.collect.return_value = [
            MagicMock(dcg=6.39),
        ]

        analyzer = MetricsAnalyzer(mock_df)
        analyzer.dcg_at_k(k=3)

        # Verify col was called with llm_relevance_score (graded score column)
        mock_col.assert_any_call("llm_relevance_score")


# =============================================================================
# CI Edge Case Tests
# =============================================================================

class TestWilsonCIEdgeCases:
    """Additional edge case tests for Wilson score confidence interval."""

    def test_wilson_ci_all_successes(self):
        """Test Wilson CI with 100% success rate (n out of n)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # 100 out of 100 successes
            p, margin = analyzer._wilson_ci(100, 100)

            assert p == 1.0
            assert margin > 0  # Should have some margin even at 100%
            assert margin < 0.05  # But margin should be small

    def test_wilson_ci_no_successes(self):
        """Test Wilson CI with 0% success rate (0 out of n)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # 0 out of 100 successes
            p, margin = analyzer._wilson_ci(0, 100)

            assert p == 0.0
            assert margin > 0  # Should have some margin
            assert margin < 0.05  # But margin should be small

    def test_wilson_ci_small_n_1(self):
        """Test Wilson CI with n=1."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # 1 out of 1 success
            p, margin = analyzer._wilson_ci(1, 1)

            assert p == 1.0
            assert margin > 0  # Large margin due to small n

            # 0 out of 1 success
            p, margin = analyzer._wilson_ci(0, 1)

            assert p == 0.0
            assert margin > 0

    def test_wilson_ci_small_n_2(self):
        """Test Wilson CI with n=2."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # 1 out of 2 successes (50%)
            p, margin = analyzer._wilson_ci(1, 2)

            assert p == 0.5
            assert margin > 0.2  # Large margin due to small n


class TestTCIEdgeCases:
    """Additional edge case tests for t-distribution confidence interval."""

    def test_t_ci_two_values(self):
        """Test t-CI with minimum values (n=2) for variance calculation."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # Two values: [1.0, 3.0] -> mean = 2.0
            mean, margin = analyzer._t_ci([1.0, 3.0])

            assert mean == 2.0
            assert margin > 0  # Should have margin with variance

    def test_t_ci_identical_values(self):
        """Test t-CI with identical values (zero variance)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # All identical values: [5.0, 5.0, 5.0]
            mean, margin = analyzer._t_ci([5.0, 5.0, 5.0])

            assert mean == 5.0
            assert margin == 0.0  # Zero variance means zero margin

    def test_t_ci_high_variance(self):
        """Test t-CI with high variance produces larger margin."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # Low variance: [4.9, 5.0, 5.1]
            _, low_margin = analyzer._t_ci([4.9, 5.0, 5.1])

            # High variance: [0.0, 5.0, 10.0]
            _, high_margin = analyzer._t_ci([0.0, 5.0, 10.0])

            # High variance should give larger margin
            assert high_margin > low_margin

    def test_t_ci_large_n(self):
        """Test t-CI with large sample size."""
        from autoeval_lib.metrics import MetricsAnalyzer

        with patch("autoeval_lib.metrics.col") as mock_col, \
             patch("autoeval_lib.metrics.avg"):
            mock_col.return_value = MagicMock()
            mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
            mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

            mock_df = create_mock_df()
            analyzer = MetricsAnalyzer(mock_df)

            # 100 values around 0.5 with some variance
            import random
            random.seed(42)
            values = [0.5 + random.uniform(-0.1, 0.1) for _ in range(100)]

            mean, margin = analyzer._t_ci(values)

            # Mean should be close to 0.5
            assert 0.45 < mean < 0.55
            # Margin should be small with large n
            assert margin < 0.05


# =============================================================================
# Mathematical Correctness Tests for Metrics
# These tests mock _collect_column_values to inject known values and verify
# that the final calculation is correct.
# =============================================================================

class TestRecallAtKMathematical:
    """Tests verifying recall_at_k mathematical correctness."""

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_perfect(self, mock_avg, mock_col):
        """Test recall when all queries find their doc at rank 1."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        # 100 out of 100 queries find their doc
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 100
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        analyzer = MetricsAnalyzer(mock_df)
        recall, _ = analyzer.recall_at_k(k=10)

        assert recall == 1.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_zero(self, mock_avg, mock_col):
        """Test recall when no queries find their doc."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        # 0 out of 100 queries find their doc
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 0
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        analyzer = MetricsAnalyzer(mock_df)
        recall, _ = analyzer.recall_at_k(k=10)

        assert recall == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_partial(self, mock_avg, mock_col):
        """Test recall with known ratio (70/100 = 0.7)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        # 70 out of 100 queries find their doc
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 70
        mock_df.select.return_value.distinct.return_value.count.return_value = 100

        analyzer = MetricsAnalyzer(mock_df)
        recall, ci_margin = analyzer.recall_at_k(k=10)

        assert recall == 0.7
        assert ci_margin > 0  # Should have confidence interval

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_recall_single_query(self, mock_avg, mock_col):
        """Test recall with single query (n=1)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__and__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df(total=10)  # 1 query, 10 results
        mock_df.filter.return_value.select.return_value.distinct.return_value.count.return_value = 1
        mock_df.select.return_value.distinct.return_value.count.return_value = 1

        analyzer = MetricsAnalyzer(mock_df)
        recall, _ = analyzer.recall_at_k(k=10)

        assert recall == 1.0


class TestPrecisionAtKMathematical:
    """Tests verifying precision_at_k mathematical correctness.

    These tests mock _collect_column_values to inject known per-query precision
    values and verify that _t_ci computes the correct mean and CI.
    """

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_precision_all_relevant(self, mock_avg, mock_col):
        """Test precision when all k docs are relevant = 1.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known precision values
        analyzer._collect_column_values = MagicMock(return_value=[1.0, 1.0, 1.0])

        precision, _ = analyzer.precision_at_k(k=5)

        assert precision == 1.0
        analyzer._collect_column_values.assert_called_once()

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_precision_none_relevant(self, mock_avg, mock_col):
        """Test precision when no docs are relevant = 0.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known precision values
        analyzer._collect_column_values = MagicMock(return_value=[0.0, 0.0, 0.0])

        precision, _ = analyzer.precision_at_k(k=5)

        assert precision == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_precision_known_ratio(self, mock_avg, mock_col):
        """Test precision with known values: mean([0.4, 0.6, 0.8]) = 0.6."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values with varied precision values
        analyzer._collect_column_values = MagicMock(return_value=[0.4, 0.6, 0.8])

        precision, margin = analyzer.precision_at_k(k=5)

        assert precision == 0.6
        assert margin > 0  # Multiple values should have confidence interval

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_precision_single_query(self, mock_avg, mock_col):
        """Test precision with single query (n=1, margin=0)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__lt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values with single value
        analyzer._collect_column_values = MagicMock(return_value=[0.8])

        precision, margin = analyzer.precision_at_k(k=5)

        assert precision == 0.8
        assert margin == 0.0  # Single value means no margin


class TestMRRMathematical:
    """Tests verifying mrr mathematical correctness.

    These tests mock _collect_column_values to inject known per-query RR
    values and verify that _t_ci computes the correct mean and CI.
    """

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_mrr_perfect(self, mock_avg, mock_col):
        """Test MRR when all first results are relevant = 1.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known RR values
        analyzer._collect_column_values = MagicMock(return_value=[1.0, 1.0, 1.0])

        mrr, _ = analyzer.mrr()

        assert mrr == 1.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_mrr_second_position(self, mock_avg, mock_col):
        """Test MRR when all relevant docs are at rank 2 = 0.5."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known RR values
        analyzer._collect_column_values = MagicMock(return_value=[0.5, 0.5, 0.5])

        mrr, _ = analyzer.mrr()

        assert mrr == 0.5

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_mrr_mixed(self, mock_avg, mock_col):
        """Test MRR with mixed positions: (1.0 + 0.5 + 0.25) / 3 = 0.583."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Query 1: rank 1 -> RR=1.0
        # Query 2: rank 2 -> RR=0.5
        # Query 3: rank 4 -> RR=0.25
        analyzer._collect_column_values = MagicMock(return_value=[1.0, 0.5, 0.25])

        mrr, margin = analyzer.mrr()

        # Mean = (1.0 + 0.5 + 0.25) / 3 = 0.5833...
        assert abs(mrr - 0.5833) < 0.01
        assert margin > 0  # Multiple values should have confidence interval

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_mrr_no_relevant(self, mock_avg, mock_col):
        """Test MRR when no queries have relevant docs = 0.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # No relevant docs found -> RR=0.0 for all queries
        analyzer._collect_column_values = MagicMock(return_value=[0.0, 0.0, 0.0])

        mrr, _ = analyzer.mrr()

        assert mrr == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_mrr_single_query(self, mock_avg, mock_col):
        """Test MRR with single query (n=1, margin=0)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Single query with RR=0.333 (rank 3)
        analyzer._collect_column_values = MagicMock(return_value=[0.333])

        mrr, margin = analyzer.mrr()

        assert abs(mrr - 0.333) < 0.01
        assert margin == 0.0  # Single value means no margin


class TestNDCGAtKMathematical:
    """Tests verifying ndcg_at_k mathematical correctness.

    These tests mock _collect_column_values to inject known per-query NDCG
    values and verify that _t_ci computes the correct mean and CI.
    """

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_ndcg_perfect_ranking(self, mock_avg, mock_col):
        """Test NDCG when ranking is already ideal = 1.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known NDCG values
        analyzer._collect_column_values = MagicMock(return_value=[1.0, 1.0, 1.0])

        ndcg, _ = analyzer.ndcg_at_k(k=5)

        assert ndcg == 1.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_ndcg_imperfect_ranking(self, mock_avg, mock_col):
        """Test NDCG when ranking is not ideal < 1.0: mean([0.8, 0.9, 0.7]) = 0.8."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Suboptimal ranking results in NDCG < 1.0
        analyzer._collect_column_values = MagicMock(return_value=[0.8, 0.9, 0.7])

        ndcg, margin = analyzer.ndcg_at_k(k=5)

        assert abs(ndcg - 0.8) < 0.001  # mean of [0.8, 0.9, 0.7]
        assert margin > 0  # Multiple values should have CI

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_ndcg_all_zeros(self, mock_avg, mock_col):
        """Test NDCG when all scores are 0 (no relevant docs)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # All zero scores -> NDCG=0.0
        analyzer._collect_column_values = MagicMock(return_value=[0.0, 0.0])

        ndcg, _ = analyzer.ndcg_at_k(k=5)

        assert ndcg == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_ndcg_single_query(self, mock_avg, mock_col):
        """Test NDCG with single query (n=1, margin=0)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Single query
        analyzer._collect_column_values = MagicMock(return_value=[0.85])

        ndcg, margin = analyzer.ndcg_at_k(k=5)

        assert ndcg == 0.85
        assert margin == 0.0  # Single value means no margin


class TestDCGAtKMathematical:
    """Tests verifying dcg_at_k mathematical correctness.

    These tests mock _collect_column_values to inject known per-query DCG
    values and verify that _t_ci computes the correct mean and CI.
    """

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_dcg_known_values(self, mock_avg, mock_col):
        """Test DCG with known calculated values.

        DCG = Σ(relevance / log2(rank + 1))
        For scores [3, 3, 3] at ranks 1, 2, 3:
        DCG = 3/log2(2) + 3/log2(3) + 3/log2(4)
            = 3/1.0 + 3/1.585 + 3/2.0
            ≈ 3.0 + 1.893 + 1.5 = 6.393
        """
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known DCG value
        analyzer._collect_column_values = MagicMock(return_value=[6.393])

        dcg, margin = analyzer.dcg_at_k(k=3)

        assert abs(dcg - 6.393) < 0.01
        assert margin == 0.0  # Single query

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_dcg_graded_scores(self, mock_avg, mock_col):
        """Test DCG with graded scores.

        DCG = 3/log2(2) + 2/log2(3) + 1/log2(4) + 0/log2(5)
            ≈ 3.0 + 1.262 + 0.5 = 4.762
        """
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Mock _collect_column_values to return known DCG value
        analyzer._collect_column_values = MagicMock(return_value=[4.762])

        dcg, _ = analyzer.dcg_at_k(k=4)

        assert abs(dcg - 4.762) < 0.01

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_dcg_all_zeros(self, mock_avg, mock_col):
        """Test DCG when all scores are 0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # All zero scores
        analyzer._collect_column_values = MagicMock(return_value=[0.0, 0.0])

        dcg, _ = analyzer.dcg_at_k(k=5)

        assert dcg == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_dcg_multiple_queries(self, mock_avg, mock_col):
        """Test DCG averaged across multiple queries: mean([4.0, 6.0, 5.0]) = 5.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Multiple queries
        analyzer._collect_column_values = MagicMock(return_value=[4.0, 6.0, 5.0])

        dcg, margin = analyzer.dcg_at_k(k=5)

        assert dcg == 5.0
        assert margin > 0  # Multiple values should have CI

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_dcg_k_equals_1(self, mock_avg, mock_col):
        """Test DCG with k=1 (simplest case): DCG@1 = relevance / log2(2) = relevance."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # k=1, score=3 -> DCG=3.0
        analyzer._collect_column_values = MagicMock(return_value=[3.0])

        dcg, _ = analyzer.dcg_at_k(k=1)

        assert dcg == 3.0


class TestMAPAtKMathematical:
    """Tests verifying map_at_k mathematical correctness.

    These tests mock _collect_column_values to inject known per-query AP
    values and verify that _t_ci computes the correct mean and CI.
    """

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_map_perfect_ranking(self, mock_avg, mock_col):
        """Test MAP when all relevant docs are at the top = 1.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # All queries have AP=1.0 (perfect ranking)
        analyzer._collect_column_values = MagicMock(return_value=[1.0, 1.0, 1.0])

        map_score, _ = analyzer.map_at_k(k=5)

        assert map_score == 1.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_map_no_relevant(self, mock_avg, mock_col):
        """Test MAP when no relevant docs = 0.0."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # No relevant docs -> AP=0.0
        analyzer._collect_column_values = MagicMock(return_value=[0.0, 0.0])

        map_score, _ = analyzer.map_at_k(k=5)

        assert map_score == 0.0

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_map_known_calculation(self, mock_avg, mock_col):
        """Test MAP with known AP calculation.

        For docs: [rel, not-rel, rel] with 2 relevant total
        P@1 = 1/1 = 1.0 (relevant)
        P@3 = 2/3 = 0.667 (relevant)
        AP = (1.0 + 0.667) / 2 = 0.833
        """
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Return pre-calculated AP
        analyzer._collect_column_values = MagicMock(return_value=[0.833])

        map_score, _ = analyzer.map_at_k(k=3)

        assert abs(map_score - 0.833) < 0.01

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_map_single_relevant(self, mock_avg, mock_col):
        """Test MAP with single relevant doc at position 3: AP = 1/3 = 0.333."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        analyzer._collect_column_values = MagicMock(return_value=[0.333])

        map_score, _ = analyzer.map_at_k(k=3)

        assert abs(map_score - 0.333) < 0.01

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_map_single_query(self, mock_avg, mock_col):
        """Test MAP with single query (n=1, margin=0)."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Single query
        analyzer._collect_column_values = MagicMock(return_value=[0.75])

        map_score, margin = analyzer.map_at_k(k=5)

        assert map_score == 0.75
        assert margin == 0.0  # Single value means no margin

    @patch("autoeval_lib.metrics.col")
    @patch("autoeval_lib.metrics.avg")
    def test_map_multiple_queries(self, mock_avg, mock_col):
        """Test MAP averaged across multiple queries: mean([1.0, 0.5, 0.75]) = 0.75."""
        from autoeval_lib.metrics import MetricsAnalyzer

        mock_col.return_value = MagicMock()
        mock_col.return_value.__eq__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__ge__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__le__ = MagicMock(return_value=MagicMock())
        mock_col.return_value.__gt__ = MagicMock(return_value=MagicMock())

        mock_df = create_mock_df()
        analyzer = MetricsAnalyzer(mock_df)

        # Multiple queries: AP=[1.0, 0.5, 0.75] -> Mean=0.75
        analyzer._collect_column_values = MagicMock(return_value=[1.0, 0.5, 0.75])

        map_score, margin = analyzer.map_at_k(k=5)

        assert map_score == 0.75
        assert margin > 0  # Multiple values should have CI
