"""Tests for MultiQueryEvaluator module."""

import pytest
from unittest.mock import MagicMock, patch


def create_mock_analyzer():
    """Helper to create a mock MetricsAnalyzer."""
    mock_analyzer = MagicMock()
    mock_analyzer._total = 100
    mock_analyzer._highly_relevant = 40
    mock_analyzer._relevant = 70
    mock_analyzer._not_relevant = 10
    mock_analyzer._avg_score = 2.3
    mock_analyzer._num_queries = 10

    # Build metrics dict (base metrics only, @k metrics are optional)
    metrics = {
        "avg_relevance_score": (2.3, 0.15),
        "highly_relevant_pct": (40.0, 3.1),
        "relevant_plus_pct": (70.0, 2.9),
        "not_relevant_pct": (10.0, 1.9),
        "mrr": (0.55, 0.04),
    }

    mock_analyzer.get_metrics.return_value = metrics

    # Mock recall_at_k() to return (value, ci_margin) tuple
    mock_analyzer.recall_at_k.return_value = (0.75, 0.04)

    # Mock precision_at_k() to return (value, ci_margin) tuple
    mock_analyzer.precision_at_k.return_value = (0.50, 0.03)

    # Mock ndcg_at_k() to return (value, ci_margin) tuple
    mock_analyzer.ndcg_at_k.return_value = (0.65, 0.03)

    # Mock map_at_k() to return (value, ci_margin) tuple
    mock_analyzer.map_at_k.return_value = (0.60, 0.03)

    # Mock mrr() for plotting tests
    mock_analyzer.mrr.return_value = (0.55, 0.04)

    return mock_analyzer


def create_mock_config(**overrides):
    """Helper to create a mock validated AutoEvalConfig."""
    # Extract _validated from overrides, default to True
    is_validated_value = overrides.pop("_validated", True)

    defaults = {
        "endpoint_name": "test-endpoint",
        "index_name": "catalog.schema.index",
        "corpus_table": "catalog.schema.source",
        "primary_key": "doc_id",
        "query_columns": ["text"],
        "columns_to_retrieve": ["doc_id", "text"],
        "columns_to_rerank": ["text"],
        "query_types": ["FULL_TEXT", "ANN", "HYBRID"],
        "num_results": 10,
        "k_values": [1, 3, 5, 10],
        "query_generation_llm_endpoint": "databricks-gpt-5-mini",
        "relevance_judge_llm_endpoint": "databricks-meta-llama-3-1-70b-instruct",
        "embedding_model": "databricks-gte-large-en",
        "query_cache_table": "test.schema.cache",
        "enable_reranker": False,
        "enable_mlflow_logging": False,
        "query_style": "mixed",
        "few_shot_examples": [],
    }
    defaults.update(overrides)

    mock_config = MagicMock()
    for key, value in defaults.items():
        setattr(mock_config, key, value)

    # Configure is_validated() method
    mock_config.is_validated.return_value = is_validated_value

    return mock_config


class TestMultiQueryEvaluatorInit:
    """Tests for MultiQueryEvaluator initialization."""

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_init_creates_components(self, mock_spark_session, mock_search_client, mock_judge):
        """Test that init creates SearchClient and LLMJudge."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config(
            query_generation_llm_endpoint="my-llm-model",
            relevance_judge_llm_endpoint="my-judge-model",
            embedding_model="my-embedding",
            query_cache_table="my-cache",
            columns_to_retrieve=["doc_id", "title", "text"]
        )

        evaluator = MultiQueryEvaluator(config=mock_config)

        mock_search_client.assert_called_once_with("test-endpoint", "catalog.schema.index", "doc_id")
        mock_judge.assert_called_once_with(
            model_endpoint="my-judge-model",
            index_name="catalog.schema.index",
            query_cache_table="my-cache"
        )
        assert evaluator.config.query_generation_llm_endpoint == "my-llm-model"
        assert evaluator.config.embedding_model == "my-embedding"
        assert evaluator.config.query_cache_table == "my-cache"
        assert evaluator.config.columns_to_retrieve == ["doc_id", "title", "text"]
        assert evaluator.results == {}

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_init_with_config_values(self, mock_spark_session, mock_search_client, mock_judge):
        """Test that init uses config values correctly."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()

        evaluator = MultiQueryEvaluator(config=mock_config)

        assert evaluator.config.query_generation_llm_endpoint == "databricks-gpt-5-mini"
        assert evaluator.config.embedding_model == "databricks-gte-large-en"
        assert evaluator.config.query_cache_table == "test.schema.cache"
        assert evaluator.config.query_types == ["FULL_TEXT", "ANN", "HYBRID"]
        assert evaluator.config.num_results == 10
        assert evaluator.config.k_values == [1, 3, 5, 10]

    def test_init_raises_for_unvalidated_config(self):
        """Test that init raises ValueError for unvalidated config."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_config = create_mock_config(_validated=False)

        with pytest.raises(ValueError, match="Config must be validated"):
            MultiQueryEvaluator(config=mock_config)


class TestEvaluate:
    """Tests for evaluate method."""

    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_evaluate_runs_all_query_types(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer
    ):
        """Test that evaluate runs for all specified query types."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer_instance = create_mock_analyzer()
        mock_analyzer.return_value = mock_analyzer_instance

        mock_queries_df = MagicMock()

        mock_config = create_mock_config(query_types=["FULL_TEXT", "ANN", "HYBRID"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        results = evaluator.evaluate(queries_df=mock_queries_df)

        # Should call search_batch 3 times
        assert mock_search.search_batch.call_count == 3

        # Should call score_batch 3 times
        assert mock_judge_instance.score_batch.call_count == 3

        # Should return results for all 3 query types
        assert len(results) == 3
        assert "FULL_TEXT" in results
        assert "ANN" in results
        assert "HYBRID" in results

    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_evaluate_passes_embedding_params(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer
    ):
        """Test that embedding params are passed to search_batch."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer.return_value = create_mock_analyzer()

        mock_queries_df = MagicMock()

        mock_config = create_mock_config(
            query_types=["ANN"],
            num_results=5,
            embedding_model="my-model",
            query_cache_table="my-cache"
        )
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=mock_queries_df)

        # Verify embedding params were passed to search_batch
        call_args = mock_search.search_batch.call_args
        assert call_args[1]["embedding_model"] == "my-model"
        assert call_args[1]["query_cache_table"] == "my-cache"
        assert call_args[1]["num_results"] == 5

        # Verify score_batch is called with primary_key_column
        judge_call_args = mock_judge_instance.score_batch.call_args
        assert judge_call_args[1]["primary_key_column"] == "retrieved_doc_id"


class TestCompareMetrics:
    """Tests for compare_metrics method."""

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_metrics_raises_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that compare_metrics raises if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        with pytest.raises(ValueError, match="No results to compare"):
            evaluator.compare_metrics()

    @patch("autoeval_lib.evaluator.Row")
    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_metrics_returns_dataframe(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer, mock_row
    ):
        """Test that compare_metrics returns a DataFrame with expected columns."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer.return_value = create_mock_analyzer()

        # Capture rows passed to createDataFrame
        created_rows = []

        def capture_row(**kwargs):
            created_rows.append(kwargs)
            return MagicMock()

        mock_row.side_effect = capture_row
        mock_spark.createDataFrame.return_value = MagicMock()

        mock_config = create_mock_config(query_types=["FULL_TEXT", "ANN"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        evaluator.compare_metrics()

        # Should create 2 rows (one per query type)
        assert len(created_rows) == 2

        # Check row structure (pretty column names)
        row = created_rows[0]
        assert "Query Type" in row
        assert "Avg Relevance Score" in row
        assert "Highly Relevant (score=3) %" in row
        assert "Relevant+ (score>=2) %" in row
        assert "Not Relevant (score<=1) %" in row
        assert "MRR" in row

        # Check values include CI format "value ± margin"
        assert "±" in row["Avg Relevance Score"]
        assert "±" in row["Highly Relevant (score=3) %"]
        assert "±" in row["MRR"]


class TestCompareRecall:
    """Tests for compare_recall method."""

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_recall_raises_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that compare_recall raises if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        with pytest.raises(ValueError, match="No results to compare"):
            evaluator.compare_recall()

    @patch("autoeval_lib.evaluator.Row")
    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_recall_custom_k_values(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer, mock_row
    ):
        """Test that compare_recall accepts custom k values."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer_instance = create_mock_analyzer()
        mock_analyzer.return_value = mock_analyzer_instance

        created_rows = []

        def capture_row(**kwargs):
            created_rows.append(kwargs)
            return MagicMock()

        mock_row.side_effect = capture_row
        mock_spark.createDataFrame.return_value = MagicMock()

        mock_config = create_mock_config(query_types=["FULL_TEXT"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        evaluator.compare_recall(k_values=[1, 5, 20])

        # Check that custom k values were used (pretty column names)
        row = created_rows[0]
        assert "Query Type" in row
        assert "Recall@1" in row
        assert "Recall@5" in row
        assert "Recall@20" in row

        # Check values include CI format "value ± margin"
        assert "±" in row["Recall@1"]
        assert "±" in row["Recall@5"]
        assert "±" in row["Recall@20"]


class TestComparePrecision:
    """Tests for compare_precision method."""

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_precision_raises_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that compare_precision raises if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        with pytest.raises(ValueError, match="No results to compare"):
            evaluator.compare_precision()

    @patch("autoeval_lib.evaluator.Row")
    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_precision_custom_k_values(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer, mock_row
    ):
        """Test that compare_precision accepts custom k values."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer_instance = create_mock_analyzer()
        mock_analyzer.return_value = mock_analyzer_instance

        created_rows = []

        def capture_row(**kwargs):
            created_rows.append(kwargs)
            return MagicMock()

        mock_row.side_effect = capture_row
        mock_spark.createDataFrame.return_value = MagicMock()

        mock_config = create_mock_config(query_types=["FULL_TEXT"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        evaluator.compare_precision(k_values=[1, 5, 20])

        # Check that custom k values were used (pretty column names)
        row = created_rows[0]
        assert "Query Type" in row
        assert "Precision@1" in row
        assert "Precision@5" in row
        assert "Precision@20" in row

        # Check values include CI format "value ± margin"
        assert "±" in row["Precision@1"]
        assert "±" in row["Precision@5"]
        assert "±" in row["Precision@20"]


class TestCompareNDCG:
    """Tests for compare_ndcg method."""

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_ndcg_raises_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that compare_ndcg raises if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        with pytest.raises(ValueError, match="No results to compare"):
            evaluator.compare_ndcg()

    @patch("autoeval_lib.evaluator.Row")
    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_compare_ndcg_custom_k_values(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer, mock_row
    ):
        """Test that compare_ndcg accepts custom k values."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer_instance = create_mock_analyzer()
        mock_analyzer.return_value = mock_analyzer_instance

        created_rows = []

        def capture_row(**kwargs):
            created_rows.append(kwargs)
            return MagicMock()

        mock_row.side_effect = capture_row
        mock_spark.createDataFrame.return_value = MagicMock()

        mock_config = create_mock_config(query_types=["FULL_TEXT"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        evaluator.compare_ndcg(k_values=[1, 5, 20])

        # Check that custom k values were used (pretty column names)
        row = created_rows[0]
        assert "Query Type" in row
        assert "NDCG@1" in row
        assert "NDCG@5" in row
        assert "NDCG@20" in row

        # Check values include CI format "value ± margin"
        assert "±" in row["NDCG@1"]
        assert "±" in row["NDCG@5"]
        assert "±" in row["NDCG@20"]


class TestGetResult:
    """Tests for get_result method."""

    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_get_result_returns_eval_result(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer
    ):
        """Test that get_result returns correct EvalResult."""
        from autoeval_lib.evaluator import MultiQueryEvaluator, EvalResult

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer.return_value = create_mock_analyzer()

        mock_config = create_mock_config(query_types=["FULL_TEXT"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        result = evaluator.get_result("FULL_TEXT")

        assert isinstance(result, EvalResult)
        assert result.query_type == "FULL_TEXT"

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_get_result_raises_for_missing_type(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that get_result raises KeyError for non-evaluated type."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        with pytest.raises(KeyError, match="No results for query_type"):
            evaluator.get_result("FULL_TEXT")


class TestEvalResult:
    """Tests for EvalResult dataclass."""

    def test_eval_result_creation(self):
        """Test that EvalResult can be created."""
        from autoeval_lib.evaluator import EvalResult

        mock_df = MagicMock()
        mock_analyzer = MagicMock()

        result = EvalResult(
            query_type="ANN",
            scored_df=mock_df,
            analyzer=mock_analyzer
        )

        assert result.query_type == "ANN"
        assert result.scored_df == mock_df
        assert result.analyzer == mock_analyzer


class TestPlotMethods:
    """Tests for plotting methods."""

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_plot_recall_returns_none_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that plot_recall returns None if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        result = evaluator.plot_recall()
        assert result is None

    @patch("autoeval_lib.plotting.plot_metrics_at_k")
    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_plot_recall_calls_plotting_function(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer, mock_plot
    ):
        """Test that plot_recall calls the plotting function with correct args."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer.return_value = create_mock_analyzer()

        mock_fig = MagicMock()
        mock_plot.return_value = mock_fig

        mock_config = create_mock_config(query_types=["FULL_TEXT"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        result = evaluator.plot_recall()

        mock_plot.assert_called_once()
        assert result == mock_fig

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_plot_mrr_returns_none_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that plot_mrr returns None if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        result = evaluator.plot_mrr()
        assert result is None

    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_plot_all_metrics_returns_empty_list_without_results(
        self, mock_spark_session, mock_search_client, mock_judge
    ):
        """Test that plot_all_metrics returns empty list if evaluate not called."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()
        mock_search_client.return_value = MagicMock()
        mock_judge.return_value = MagicMock()

        mock_config = create_mock_config()
        evaluator = MultiQueryEvaluator(config=mock_config)

        result = evaluator.plot_all_metrics()
        assert result == []

    @patch("autoeval_lib.plotting.plot_mrr")
    @patch("autoeval_lib.plotting.plot_metrics_at_k")
    @patch("autoeval_lib.evaluator.MetricsAnalyzer")
    @patch("autoeval_lib.evaluator.LLMJudge")
    @patch("autoeval_lib.evaluator.SearchClient")
    @patch("autoeval_lib.evaluator.SparkSession")
    def test_plot_all_metrics_returns_list_of_tuples(
        self, mock_spark_session, mock_search_client, mock_judge, mock_analyzer,
        mock_plot_metrics, mock_plot_mrr
    ):
        """Test that plot_all_metrics returns list of (name, figure) tuples."""
        from autoeval_lib.evaluator import MultiQueryEvaluator

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_search = MagicMock()
        mock_search.search_batch.return_value = MagicMock()
        mock_search_client.return_value = mock_search

        mock_judge_instance = MagicMock()
        mock_judge_instance.score_batch.return_value = MagicMock()
        mock_judge.return_value = mock_judge_instance

        mock_analyzer.return_value = create_mock_analyzer()

        mock_fig = MagicMock()
        mock_plot_metrics.return_value = mock_fig
        mock_plot_mrr.return_value = mock_fig

        mock_config = create_mock_config(query_types=["FULL_TEXT"])
        evaluator = MultiQueryEvaluator(config=mock_config)
        evaluator.evaluate(queries_df=MagicMock())

        result = evaluator.plot_all_metrics()

        # Should return list of 6 tuples
        assert isinstance(result, list)
        assert len(result) == 6

        # Check names (order: DCG, NDCG, MAP, MRR, Precision, Recall)
        names = [name for name, fig in result]
        assert names == ["DCG@k", "NDCG@k", "MAP@k", "MRR", "Precision@k", "Recall@k"]

        # Check all figures are returned
        for name, fig in result:
            assert fig == mock_fig
