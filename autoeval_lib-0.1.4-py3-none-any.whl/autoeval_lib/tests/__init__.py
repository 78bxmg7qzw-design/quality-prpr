"""Tests for autoeval_lib."""
