"""Tests for query_generator module."""

import pytest
from unittest.mock import MagicMock, patch

from autoeval_lib.query_generator import QueryGenerator
from autoeval_lib.prompts import DEFAULT_FEW_SHOT_EXAMPLES


def create_mock_config(
    corpus_table="catalog.schema.source",
    query_columns=None,
    query_generation_llm_endpoint="databricks-gpt-5-mini",
    query_style="mixed",
    random_seed=42,
    num_samples=20,
    num_queries=200,
    few_shot_examples=None,
    primary_key="doc_id",
):
    """Create a mock validated config for testing."""
    mock_config = MagicMock()
    mock_config.is_validated.return_value = True
    mock_config.corpus_table = corpus_table
    mock_config.query_columns = query_columns or ["text"]
    mock_config.query_generation_llm_endpoint = query_generation_llm_endpoint
    mock_config.query_style = query_style
    mock_config.random_seed = random_seed
    mock_config.num_samples = num_samples
    mock_config.num_queries = num_queries
    mock_config.few_shot_examples = few_shot_examples or []
    mock_config.primary_key = primary_key
    return mock_config


class TestQueryGeneratorInit:
    """Tests for QueryGenerator initialization."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_init_gets_spark_session(self, mock_spark_session):
        """Test that init gets SparkSession."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        mock_spark_session.builder.getOrCreate.assert_called_once()
        assert generator.spark == mock_spark

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_init_sets_default_few_shot_examples_when_config_empty(self, mock_spark_session):
        """Test that init sets default few-shot examples when config has none."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config(few_shot_examples=[])
        generator = QueryGenerator(config=mock_config)

        assert generator.config.few_shot_examples == DEFAULT_FEW_SHOT_EXAMPLES

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_init_uses_config_few_shot_examples_when_provided(self, mock_spark_session):
        """Test that init uses config's few-shot examples when provided."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        custom_examples = [
            {"document": "Custom doc", "query": "custom query"}
        ]
        mock_config = create_mock_config(few_shot_examples=custom_examples)
        generator = QueryGenerator(config=mock_config)

        assert generator.config.few_shot_examples == custom_examples

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_init_uses_random_seed_from_config(self, mock_spark_session):
        """Test that random_seed is taken from config."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config(random_seed=42)
        generator = QueryGenerator(config=mock_config)

        assert generator.config.random_seed == 42

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_init_uses_query_style_from_config(self, mock_spark_session):
        """Test that query_style is taken from config."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config(query_style="keyword")
        generator = QueryGenerator(config=mock_config)

        assert generator.config.query_style == "keyword"

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_init_raises_for_unvalidated_config(self, mock_spark_session):
        """Test that init raises ValueError for unvalidated config."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = MagicMock()
        mock_config.is_validated.return_value = False

        with pytest.raises(ValueError, match="Config must be validated"):
            QueryGenerator(config=mock_config)


class TestSetQueryStyle:
    """Tests for set_query_style method."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_query_style_updates_generator_and_config(self, mock_spark_session):
        """Test that set_query_style updates both generator and config."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config(query_style="mixed")
        generator = QueryGenerator(config=mock_config)

        generator.set_query_style("keyword")

        assert generator.config.query_style == "keyword"

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_query_style_normalizes_to_lowercase(self, mock_spark_session):
        """Test that set_query_style normalizes to lowercase."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        generator.set_query_style("NATURAL")

        assert generator.config.query_style == "natural"

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_query_style_invalid_raises_error(self, mock_spark_session):
        """Test that invalid query_style raises ValueError."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        with pytest.raises(ValueError, match="query_style must be one of"):
            generator.set_query_style("invalid")


class TestSetFewShotExamples:
    """Tests for set_few_shot_examples method."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_few_shot_examples_updates_examples(self, mock_spark_session):
        """Test that set_few_shot_examples updates the examples."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        new_examples = [
            {"document": "New doc 1", "query": "new query 1"},
            {"document": "New doc 2", "query": "new query 2"},
        ]
        generator.set_few_shot_examples(new_examples)

        assert generator.config.few_shot_examples == new_examples

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_few_shot_examples_empty_raises_error(self, mock_spark_session):
        """Test that empty examples raises ValueError."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        with pytest.raises(ValueError, match="examples must not be empty"):
            generator.set_few_shot_examples([])

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_few_shot_examples_missing_document_raises_error(self, mock_spark_session):
        """Test that examples without document key raises ValueError."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        with pytest.raises(ValueError, match="must have 'document' and 'query' keys"):
            generator.set_few_shot_examples([{"query": "only query"}])

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_set_few_shot_examples_missing_query_raises_error(self, mock_spark_session):
        """Test that examples without query key raises ValueError."""
        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        with pytest.raises(ValueError, match="must have 'document' and 'query' keys"):
            generator.set_few_shot_examples([{"document": "only document"}])


class TestGenerateQueries:
    """Tests for generate_queries method."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_generate_queries_valid_styles(self, mock_spark_session):
        """Test that valid styles are accepted via config."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock the DataFrame chain for _sample_documents
        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_df.collect.return_value = []
        mock_spark.read.table.return_value = mock_df

        # Mock createDataFrame for empty results
        mock_result_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_result_df

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        for style in ["natural", "keyword", "mixed"]:
            # Set style via config and verify it works
            generator.config.query_style = style
            generator.generate_queries()

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_generate_queries_uses_config_defaults(self, mock_spark_session):
        """Test that generate_queries uses defaults from config."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock the DataFrame chain
        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_df.collect.return_value = []
        mock_spark.read.table.return_value = mock_df

        mock_result_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_result_df

        mock_config = create_mock_config(
            corpus_table="my.test.table",
            query_columns=["content"],
            num_queries=100
        )
        generator = QueryGenerator(config=mock_config)

        # Call without arguments to use defaults
        generator.generate_queries()

        # Should read from config's corpus_table
        mock_spark.read.table.assert_called_with("my.test.table")

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_generate_queries_uses_deterministic_ordering_with_seed(self, mock_spark_session):
        """Test that random_seed produces deterministic ordering via hash."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock the DataFrame chain
        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_df.collect.return_value = []
        mock_spark.read.table.return_value = mock_df

        mock_result_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_result_df

        mock_config = create_mock_config(random_seed=42, query_style="natural")
        generator = QueryGenerator(config=mock_config)
        generator.generate_queries()

        # Verify orderBy was called (deterministic ordering via hash)
        mock_df.orderBy.assert_called()


class TestSampleAndGenerateExamples:
    """Tests for sample_and_generate_examples method."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_sample_uses_deterministic_ordering_with_seed(self, mock_spark_session):
        """Test that random_seed produces deterministic ordering via hash."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock the DataFrame chain
        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_df.collect.return_value = []
        mock_spark.read.table.return_value = mock_df

        mock_result_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_result_df

        mock_config = create_mock_config(random_seed=123)
        generator = QueryGenerator(config=mock_config)
        generator.sample_and_generate_examples()

        # Verify orderBy was called (deterministic ordering via hash)
        mock_df.orderBy.assert_called()

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_sample_uses_random_ordering_without_seed(self, mock_spark_session):
        """Test that random ordering is used when no seed provided."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock the DataFrame chain
        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_df.collect.return_value = []
        mock_spark.read.table.return_value = mock_df

        mock_result_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_result_df

        mock_config = create_mock_config(random_seed=None)
        generator = QueryGenerator(config=mock_config)
        generator.sample_and_generate_examples()

        # Verify orderBy was called (random ordering via rand())
        mock_df.orderBy.assert_called()

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_materializes_sample_df_before_generating_queries(self, mock_spark_session):
        """Test that sample_df is materialized to ensure same docs for both query styles.

        Without materialization, lazy evaluation would produce different results
        each time the DataFrame is accessed, causing the final join to lose rows.
        """
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock the DataFrame chain for sampling
        mock_sample_df = MagicMock()
        mock_sample_df.withColumn.return_value = mock_sample_df
        mock_sample_df.select.return_value = mock_sample_df
        mock_sample_df.orderBy.return_value = mock_sample_df
        mock_sample_df.limit.return_value = mock_sample_df

        # Return specific rows when collected
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {"doc_id": "doc1", "doc_text": "text1"}[key]
        mock_sample_df.collect.return_value = [mock_row]

        mock_spark.read.table.return_value = mock_sample_df

        # Mock materialized DataFrame
        mock_materialized_df = MagicMock()
        mock_materialized_df.collect.return_value = [mock_row]

        # Track createDataFrame calls
        create_df_calls = []
        def track_create_df(data, *args, **kwargs):
            create_df_calls.append(data)
            return mock_materialized_df
        mock_spark.createDataFrame.side_effect = track_create_df

        # Mock SQL result
        mock_sql_result = MagicMock()
        mock_sql_result.collect.return_value = [mock_row]
        mock_spark.sql.return_value = mock_sql_result

        # Mock join result
        mock_natural_df = MagicMock()
        mock_natural_df.withColumnRenamed.return_value = mock_natural_df
        mock_natural_df.select.return_value = mock_natural_df
        mock_natural_df.join.return_value = mock_natural_df

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        with patch.object(generator, '_batch_generate_queries', return_value=mock_natural_df):
            generator.sample_and_generate_examples()

        # Verify sample_df.collect() was called (for materialization)
        mock_sample_df.collect.assert_called()

        # Verify createDataFrame was called with the collected rows (materialization step)
        assert len(create_df_calls) >= 1, "sample_df should be materialized via createDataFrame"


class TestBatchGenerateQueries:
    """Tests for _batch_generate_queries method."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_batch_generate_queries_uses_temp_view(self, mock_spark_session):
        """Test that batch generation uses temp view pattern."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock sample DataFrame with one row
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {"doc_id": "doc1", "doc_text": "sample text"}[key]

        mock_sample_df = MagicMock()
        mock_sample_df.collect.return_value = [mock_row]

        # Mock batch SQL result
        mock_batch_row = MagicMock()
        mock_batch_row.asDict.return_value = {
            "doc_id": "doc1", "doc_text": "sample text", "generated_query": "test query"
        }
        mock_batch_df = MagicMock()
        mock_batch_df.collect.return_value = [mock_batch_row]
        mock_spark.sql.return_value = mock_batch_df

        # Mock createDataFrame
        mock_prompt_df = MagicMock()
        mock_result_df = MagicMock()
        mock_spark.createDataFrame.side_effect = [mock_prompt_df, mock_result_df]
        mock_spark.catalog = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)
        generator._batch_generate_queries(mock_sample_df, style="natural")

        # Should create temp view
        mock_prompt_df.createOrReplaceTempView.assert_called_once()
        # Should drop temp view
        mock_spark.catalog.dropTempView.assert_called_once()

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_batch_generate_queries_makes_single_sql_call(self, mock_spark_session):
        """Test that batch generation makes one SQL call for multiple documents."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock sample DataFrame with multiple rows
        mock_row1 = MagicMock()
        mock_row1.__getitem__ = lambda self, key: {"doc_id": "doc1", "doc_text": "text 1"}[key]
        mock_row2 = MagicMock()
        mock_row2.__getitem__ = lambda self, key: {"doc_id": "doc2", "doc_text": "text 2"}[key]

        mock_sample_df = MagicMock()
        mock_sample_df.collect.return_value = [mock_row1, mock_row2]

        # Mock batch SQL result
        mock_batch_row1 = MagicMock()
        mock_batch_row1.asDict.return_value = {"doc_id": "doc1", "doc_text": "text 1", "generated_query": "query 1"}
        mock_batch_row2 = MagicMock()
        mock_batch_row2.asDict.return_value = {"doc_id": "doc2", "doc_text": "text 2", "generated_query": "query 2"}
        mock_batch_df = MagicMock()
        mock_batch_df.collect.return_value = [mock_batch_row1, mock_batch_row2]
        mock_spark.sql.return_value = mock_batch_df

        mock_prompt_df = MagicMock()
        mock_result_df = MagicMock()
        mock_spark.createDataFrame.side_effect = [mock_prompt_df, mock_result_df]
        mock_spark.catalog = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)
        generator._batch_generate_queries(mock_sample_df, style="natural")

        # Should make only one SQL call (batch), not N individual calls
        assert mock_spark.sql.call_count == 1

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_batch_generate_queries_cleans_up_on_error(self, mock_spark_session):
        """Test that temp view is cleaned up even on error."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {"doc_id": "doc1", "doc_text": "text"}[key]

        mock_sample_df = MagicMock()
        mock_sample_df.collect.return_value = [mock_row]

        # Mock SQL to raise error
        mock_spark.sql.side_effect = Exception("SQL failed")

        mock_prompt_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_prompt_df
        mock_spark.catalog = MagicMock()

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)

        with pytest.raises(Exception, match="SQL failed"):
            generator._batch_generate_queries(mock_sample_df, style="natural")

        # Should still drop temp view (in finally block)
        mock_spark.catalog.dropTempView.assert_called_once()


class TestSampleDocuments:
    """Tests for _sample_documents helper method."""

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_reads_table(self, mock_spark_session):
        """Test that _sample_documents reads the table."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_spark.read.table.return_value = mock_df

        mock_config = create_mock_config()
        generator = QueryGenerator(config=mock_config)
        generator._sample_documents("test_table", ["text"], 10)

        mock_spark.read.table.assert_called_with("test_table")

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_uses_deterministic_hash_ordering_with_seed(self, mock_spark_session):
        """Test that hash-based ordering is used when seed is provided."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_spark.read.table.return_value = mock_df

        mock_config = create_mock_config(random_seed=42)
        generator = QueryGenerator(config=mock_config)
        generator._sample_documents("test_table", ["text"], 50)

        # Verify orderBy was called (deterministic hash-based ordering)
        mock_df.orderBy.assert_called()

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_uses_random_ordering_without_seed(self, mock_spark_session):
        """Test that random ordering is used when no seed provided."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_spark.read.table.return_value = mock_df

        mock_config = create_mock_config(random_seed=None)
        generator = QueryGenerator(config=mock_config)
        generator._sample_documents("test_table", ["text"], 50)

        # Verify orderBy was called (random ordering via rand())
        mock_df.orderBy.assert_called()

    @patch("autoeval_lib.query_generator.SparkSession")
    def test_limits_to_num_samples(self, mock_spark_session):
        """Test that result is limited to num_samples."""
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_df = MagicMock()
        mock_df.withColumn.return_value = mock_df
        mock_df.select.return_value = mock_df
        mock_df.orderBy.return_value = mock_df
        mock_df.limit.return_value = mock_df
        mock_spark.read.table.return_value = mock_df

        mock_config = create_mock_config(random_seed=42)
        generator = QueryGenerator(config=mock_config)
        generator._sample_documents("test_table", ["text"], 50)

        # Verify limit was called with num_samples
        mock_df.limit.assert_called_with(50)
