"""Tests for MLflow tracing functions in mlflow_tracker module."""

import pytest
from unittest.mock import MagicMock, patch

from autoeval_lib.constants import Columns, TracingFields, Defaults


class TestToMlflowDocument:
    """Tests for _to_mlflow_document helper function."""

    def test_creates_document_with_correct_page_content(self):
        """Test that document page_content is set from text_preview."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: "Test Title",
            Columns.TEXT_PREVIEW: "This is the document text",
            TracingFields.RANK: 1,
            Columns.SEARCH_SCORE: 0.95,
            Columns.LLM_RELEVANCE_SCORE: 3,
        }

        doc = _to_mlflow_document(result, "original_doc")

        # Works with both Document object and dict fallback
        if hasattr(doc, 'page_content'):
            assert doc.page_content == "This is the document text"
        else:
            assert doc["page_content"] == "This is the document text"

    def test_creates_document_with_correct_metadata(self):
        """Test that document metadata contains all expected fields."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: "Test Title",
            Columns.TEXT_PREVIEW: "Document text",
            TracingFields.RANK: 2,
            Columns.SEARCH_SCORE: 0.85,
            Columns.LLM_RELEVANCE_SCORE: 2,
        }

        doc = _to_mlflow_document(result, "original_doc")

        # Works with both Document object and dict fallback
        metadata = doc.metadata if hasattr(doc, 'metadata') else doc["metadata"]

        assert metadata["doc_id"] == "doc123"
        assert metadata["title"] == "Test Title"
        assert metadata["rank"] == 2
        assert metadata["search_score"] == 0.85
        assert metadata["llm_relevance_score"] == 2
        assert metadata["original_doc_id"] == "original_doc"
        assert metadata["is_recall_hit"] is False

    def test_is_recall_hit_true_when_doc_matches(self):
        """Test that is_recall_hit is True when retrieved_doc_id matches original."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: "Test Title",
            Columns.TEXT_PREVIEW: "Document text",
            TracingFields.RANK: 1,
            Columns.SEARCH_SCORE: 0.95,
            Columns.LLM_RELEVANCE_SCORE: 3,
        }

        doc = _to_mlflow_document(result, "doc123")  # Same as retrieved_doc_id

        metadata = doc.metadata if hasattr(doc, 'metadata') else doc["metadata"]
        assert metadata["is_recall_hit"] is True

    def test_truncates_text_to_limit(self):
        """Test that text_preview is truncated to TEXT_TRUNCATION_LIMIT characters."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        long_text = "X" * 1500

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: "Test Title",
            Columns.TEXT_PREVIEW: long_text,
            TracingFields.RANK: 1,
            Columns.SEARCH_SCORE: 0.95,
            Columns.LLM_RELEVANCE_SCORE: 3,
        }

        doc = _to_mlflow_document(result, "original_doc")

        page_content = doc.page_content if hasattr(doc, 'page_content') else doc["page_content"]
        assert len(page_content) == Defaults.TEXT_TRUNCATION_LIMIT

    def test_truncates_title_to_limit(self):
        """Test that title is truncated to TEXT_TRUNCATION_LIMIT characters."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        long_title = "T" * 1500

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: long_title,
            Columns.TEXT_PREVIEW: "Document text",
            TracingFields.RANK: 1,
            Columns.SEARCH_SCORE: 0.95,
            Columns.LLM_RELEVANCE_SCORE: 3,
        }

        doc = _to_mlflow_document(result, "original_doc")

        metadata = doc.metadata if hasattr(doc, 'metadata') else doc["metadata"]
        assert len(metadata["title"]) == Defaults.TEXT_TRUNCATION_LIMIT

    def test_handles_none_text_preview(self):
        """Test that None text_preview is handled gracefully."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: "Test Title",
            Columns.TEXT_PREVIEW: None,
            TracingFields.RANK: 1,
            Columns.SEARCH_SCORE: 0.95,
            Columns.LLM_RELEVANCE_SCORE: 3,
        }

        doc = _to_mlflow_document(result, "original_doc")

        page_content = doc.page_content if hasattr(doc, 'page_content') else doc["page_content"]
        assert page_content == ""

    def test_handles_none_title(self):
        """Test that None title is handled gracefully."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: None,
            Columns.TEXT_PREVIEW: "Document text",
            TracingFields.RANK: 1,
            Columns.SEARCH_SCORE: 0.95,
            Columns.LLM_RELEVANCE_SCORE: 3,
        }

        doc = _to_mlflow_document(result, "original_doc")

        metadata = doc.metadata if hasattr(doc, 'metadata') else doc["metadata"]
        assert metadata["title"] == ""

    def test_uses_default_search_score_when_missing(self):
        """Test that missing search_score defaults to 0."""
        from autoeval_lib.mlflow_tracker import _to_mlflow_document

        result = {
            Columns.RETRIEVED_DOC_ID: "doc123",
            Columns.TITLE: "Test Title",
            Columns.TEXT_PREVIEW: "Document text",
            TracingFields.RANK: 1,
            Columns.LLM_RELEVANCE_SCORE: 3,
            # No SEARCH_SCORE key
        }

        doc = _to_mlflow_document(result, "original_doc")

        metadata = doc.metadata if hasattr(doc, 'metadata') else doc["metadata"]
        assert metadata["search_score"] == 0


class TestTraceSingleQuery:
    """Tests for _trace_single_query function."""

    def test_returns_list_of_documents(self):
        """Test that function returns a list of document objects."""
        from autoeval_lib.mlflow_tracker import _trace_single_query

        results = [
            {
                Columns.RETRIEVED_DOC_ID: "doc1",
                Columns.TITLE: "Title 1",
                Columns.TEXT_PREVIEW: "Text 1",
                TracingFields.RANK: 1,
                Columns.SEARCH_SCORE: 0.95,
                Columns.LLM_RELEVANCE_SCORE: 3,
            },
            {
                Columns.RETRIEVED_DOC_ID: "doc2",
                Columns.TITLE: "Title 2",
                Columns.TEXT_PREVIEW: "Text 2",
                TracingFields.RANK: 2,
                Columns.SEARCH_SCORE: 0.85,
                Columns.LLM_RELEVANCE_SCORE: 2,
            },
        ]

        docs = _trace_single_query(
            query_text="test query",
            original_doc_id="doc1",
            query_type="FULL_TEXT",
            results=results
        )

        assert len(docs) == 2
        # Works with both Document object and dict fallback
        page_content_0 = docs[0].page_content if hasattr(docs[0], 'page_content') else docs[0]["page_content"]
        page_content_1 = docs[1].page_content if hasattr(docs[1], 'page_content') else docs[1]["page_content"]
        assert page_content_0 == "Text 1"
        assert page_content_1 == "Text 2"


class TestLogPerQueryTraces:
    """Tests for MLFlowTracker._log_per_query_traces method."""

    def create_mock_row(
        self,
        query: str,
        original_doc_id: str,
        retrieved_doc_id: str,
        result_rank: int,
        llm_score: int,
        title: str = "Test Title",
        text: str = "Test text content",
        search_score: float = 0.95
    ) -> MagicMock:
        """Helper to create a mock row from scored DataFrame."""
        data = {
            "query": query,
            "original_doc_id": original_doc_id,
            "retrieved_doc_id": retrieved_doc_id,
            "result_rank": result_rank,
            "llm_relevance_score": llm_score,
            "retrieved_title": title,
            "retrieved_text": text,
            "search_score": search_score,
        }
        mock_row = MagicMock()
        mock_row.asDict.return_value = data
        return mock_row

    def create_tracker(self, scored_df: MagicMock, query_type: str = "FULL_TEXT") -> "MLFlowTracker":
        """Helper to create a MLFlowTracker with mock config."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_analyzer = MagicMock()
        mock_config = MagicMock()
        mock_config.is_validated.return_value = True
        mock_config.mlflow_experiment_path = "/test/path"
        mock_config.index_name = "test.index"

        tracker = MLFlowTracker(
            scored_df=scored_df,
            analyzer=mock_analyzer,
            config=mock_config,
            query_type=query_type,
            eval_queryset_size=100
        )
        return tracker

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_returns_list_of_trace_ids(self, mock_mlflow, mock_trace_fn):
        """Test that method returns a list of trace IDs."""
        mock_df = MagicMock()
        mock_df.collect.return_value = [
            self.create_mock_row("query1", "doc1", "doc1", 1, 3),
            self.create_mock_row("query2", "doc2", "doc2", 1, 3),
        ]

        mock_mlflow.get_last_active_trace_id.return_value = "trace-123"

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        trace_ids = tracker._log_per_query_traces()

        assert len(trace_ids) == 2
        assert all(tid == "trace-123" for tid in trace_ids)

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_calls_trace_function_per_query(self, mock_mlflow, mock_trace_fn):
        """Test that traced function is called once per unique query."""
        mock_df = MagicMock()
        mock_df.collect.return_value = [
            self.create_mock_row("query1", "doc1", "doc1", 1, 3),
            self.create_mock_row("query1", "doc1", "doc2", 2, 2),  # Same query
            self.create_mock_row("query2", "doc3", "doc3", 1, 3),  # Different query
        ]

        mock_mlflow.get_last_active_trace_id.return_value = "trace-123"

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        tracker._log_per_query_traces()

        # Should be called twice: once for query1, once for query2
        assert mock_trace_fn.call_count == 2

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_passes_correct_arguments_to_trace_function(self, mock_mlflow, mock_trace_fn):
        """Test that traced function receives correct arguments."""
        mock_df = MagicMock()
        mock_df.collect.return_value = [
            self.create_mock_row("test query", "original_doc", "doc1", 1, 3),
        ]

        mock_mlflow.get_last_active_trace_id.return_value = "trace-123"

        tracker = self.create_tracker(mock_df, query_type="ANN")
        tracker._log_per_query_traces()

        call_args = mock_trace_fn.call_args
        assert call_args[0][0] == "test query"  # query_text
        assert call_args[0][1] == "original_doc"  # original_doc_id
        assert call_args[0][2] == "ANN"  # query_type

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_results_sorted_by_rank(self, mock_mlflow, mock_trace_fn):
        """Test that results are sorted by rank before passing to trace function."""
        mock_df = MagicMock()
        # Results returned out of order
        mock_df.collect.return_value = [
            self.create_mock_row("test query", "doc1", "doc_rank3", 3, 1),
            self.create_mock_row("test query", "doc1", "doc_rank1", 1, 3),
            self.create_mock_row("test query", "doc1", "doc_rank2", 2, 2),
        ]

        mock_mlflow.get_last_active_trace_id.return_value = "trace-123"

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        tracker._log_per_query_traces()

        call_args = mock_trace_fn.call_args
        results = call_args[0][3]  # results argument

        # Should be sorted by rank
        assert results[0][TracingFields.RANK] == 1
        assert results[1][TracingFields.RANK] == 2
        assert results[2][TracingFields.RANK] == 3

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_handles_empty_dataframe(self, mock_mlflow, mock_trace_fn):
        """Test that method handles empty DataFrame gracefully."""
        mock_df = MagicMock()
        mock_df.collect.return_value = []

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        trace_ids = tracker._log_per_query_traces()

        assert trace_ids == []
        assert mock_trace_fn.call_count == 0

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_handles_none_trace_id(self, mock_mlflow, mock_trace_fn):
        """Test that method handles None trace ID gracefully."""
        mock_df = MagicMock()
        mock_df.collect.return_value = [
            self.create_mock_row("query1", "doc1", "doc1", 1, 3),
        ]

        mock_mlflow.get_last_active_trace_id.return_value = None

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        trace_ids = tracker._log_per_query_traces()

        # Should return empty list when trace_id is None
        assert trace_ids == []

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_handles_attribute_error_for_old_mlflow(self, mock_mlflow, mock_trace_fn):
        """Test that method handles AttributeError for older MLflow versions."""
        mock_df = MagicMock()
        mock_df.collect.return_value = [
            self.create_mock_row("query1", "doc1", "doc1", 1, 3),
        ]

        # Simulate older MLflow without get_last_active_trace_id
        mock_mlflow.get_last_active_trace_id.side_effect = AttributeError("no such method")

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        trace_ids = tracker._log_per_query_traces()

        # Should return empty list when get_last_active_trace_id fails
        assert trace_ids == []

    @patch("autoeval_lib.mlflow_tracker._trace_single_query")
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_handles_none_optional_fields(self, mock_mlflow, mock_trace_fn):
        """Test that method handles None optional fields gracefully."""
        data = {
            "query": "test query",
            "original_doc_id": "doc1",
            "retrieved_doc_id": "doc1",
            "result_rank": 1,
            "llm_relevance_score": 3,
            "retrieved_title": None,
            "retrieved_text": None,
            "search_score": None,
        }
        mock_row = MagicMock()
        mock_row.asDict.return_value = data

        mock_df = MagicMock()
        mock_df.collect.return_value = [mock_row]

        mock_mlflow.get_last_active_trace_id.return_value = "trace-123"

        tracker = self.create_tracker(mock_df, query_type="FULL_TEXT")
        # Should not raise exception
        tracker._log_per_query_traces()

        assert mock_trace_fn.call_count == 1
