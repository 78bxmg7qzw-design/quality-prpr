"""Tests for MLFlow tracker module."""

import pytest
import sys
from unittest.mock import MagicMock, patch, call

# Mock mlflow before importing our module
sys.modules['mlflow'] = MagicMock()

# Mock pyspark.sql.functions for generate_experiment_name tests
mock_F = MagicMock()
sys.modules['pyspark.sql.functions'] = mock_F


def create_mock_config():
    """Helper to create a mock AutoEvalConfig object."""
    mock_config = MagicMock()
    mock_config.is_validated.return_value = True
    mock_config.endpoint_name = "test-endpoint"
    mock_config.index_name = "test.index"
    mock_config.corpus_table = "test.corpus"
    mock_config.num_results = 10
    mock_config.query_style = "keyword"
    mock_config.query_columns = ["text", "title"]
    mock_config.few_shot_examples = [
        {"document": "doc1", "query": "query1"},
        {"document": "doc2", "query": "query2"}
    ]
    mock_config.random_seed = None
    mock_config.columns_to_rerank = []
    mock_config.mlflow_experiment_path = None
    mock_config.k_values = [1, 3, 5, 10]  # Standard k values for num_results=10
    return mock_config


def create_mock_analyzer():
    """Helper to create a mock MetricsAnalyzer."""
    mock_analyzer = MagicMock()
    mock_analyzer._total = 100
    mock_analyzer._highly_relevant = 40
    mock_analyzer._relevant = 70
    mock_analyzer._not_relevant = 10
    mock_analyzer._avg_score = 2.3
    mock_analyzer._num_queries = 10
    # Mock get_metrics() to return (value, ci_margin) tuples
    # Includes base metrics + @k metrics at all standard k values (1, 3, 5, 10)
    mock_analyzer.get_metrics.return_value = {
        # Base metrics
        "avg_relevance_score": (2.3, 0.15),
        "highly_relevant_pct": (40.0, 3.1),
        "relevant_plus_pct": (70.0, 2.9),
        "not_relevant_pct": (10.0, 1.9),
        "mrr": (0.55, 0.04),
        # @k metrics at k=1
        "recall_at_1": (0.35, 0.03),
        "precision_at_1": (0.35, 0.03),
        "ndcg_at_1": (0.35, 0.03),
        "map_at_1": (0.35, 0.03),
        # @k metrics at k=3
        "recall_at_3": (0.55, 0.04),
        "precision_at_3": (0.40, 0.03),
        "ndcg_at_3": (0.50, 0.03),
        "map_at_3": (0.45, 0.03),
        # @k metrics at k=5
        "recall_at_5": (0.65, 0.04),
        "precision_at_5": (0.45, 0.03),
        "ndcg_at_5": (0.55, 0.03),
        "map_at_5": (0.50, 0.03),
        # @k metrics at k=10
        "recall_at_10": (0.75, 0.04),
        "precision_at_10": (0.50, 0.03),
        "ndcg_at_10": (0.65, 0.03),
        "map_at_10": (0.60, 0.03),
    }

    # Mock methods that return DataFrames
    mock_df = MagicMock()
    mock_pandas_df = MagicMock()
    mock_df.toPandas.return_value = mock_pandas_df

    mock_analyzer.score_distribution.return_value = mock_df
    mock_analyzer.top_queries.return_value = mock_df
    mock_analyzer.bottom_queries.return_value = mock_df
    mock_analyzer.high_relevance_examples.return_value = mock_df
    mock_analyzer.low_relevance_examples.return_value = mock_df

    return mock_analyzer


class TestMLFlowTrackerInit:
    """Tests for MLFlowTracker initialization."""

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_init_stores_components(self, mock_mlflow):
        """Test that init stores the components correctly."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()
        config.mlflow_experiment_path = "/Users/test/my_experiment"

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )

        assert tracker.scored_df == mock_df
        assert tracker.analyzer == mock_analyzer
        assert tracker.config == config
        assert tracker.query_type == "ANN"
        assert tracker.eval_queryset_size == 100
        assert tracker.experiment_path == "/Users/test/my_experiment"

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_init_validates_config(self, mock_mlflow):
        """Test that init raises ValueError for unvalidated config."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()
        config.is_validated.return_value = False  # Not validated

        with pytest.raises(ValueError) as exc_info:
            MLFlowTracker(
                mock_df, mock_analyzer, config,
                query_type="ANN",
                eval_queryset_size=100
            )

        assert "must be validated" in str(exc_info.value)

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_init_uses_config_experiment_path(self, mock_mlflow):
        """Test that init uses config.mlflow_experiment_path if set."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()
        config.mlflow_experiment_path = "/Users/config@databricks.com/config_path"

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )

        assert tracker.experiment_path == "/Users/config@databricks.com/config_path"

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_init_experiment_path_param_takes_precedence(self, mock_mlflow):
        """Test that explicit experiment_path parameter takes precedence over config."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()
        config.mlflow_experiment_path = "/Users/config@databricks.com/config_path"

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100,
            experiment_path="/Users/shared@databricks.com/shared_path"
        )

        # Explicit experiment_path should override config.mlflow_experiment_path
        assert tracker.experiment_path == "/Users/shared@databricks.com/shared_path"

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_init_experiment_path_param_avoids_generate_call(self, mock_mlflow):
        """Test that providing experiment_path parameter avoids calling generate_experiment_path."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()
        config.mlflow_experiment_path = None  # No config path set

        with patch("autoeval_lib.mlflow_tracker.generate_experiment_path") as mock_generate:
            tracker = MLFlowTracker(
                mock_df, mock_analyzer, config,
                query_type="ANN",
                eval_queryset_size=100,
                experiment_path="/Users/provided@databricks.com/provided_path"
            )

            # generate_experiment_path should NOT be called when experiment_path is provided
            mock_generate.assert_not_called()
            assert tracker.experiment_path == "/Users/provided@databricks.com/provided_path"


class TestExperimentCreation:
    """Tests for experiment creation."""

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_experiment_creation_new(self, mock_mlflow):
        """Test experiment creation when experiment doesn't exist."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        # Mock experiment doesn't exist
        mock_mlflow.get_experiment_by_name.return_value = None
        mock_mlflow.create_experiment.return_value = "exp123"

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )
        exp_id = tracker._get_or_create_experiment("test_exp")

        mock_mlflow.create_experiment.assert_called_once_with(
            name="test_exp",
            tags={"product": "vector_search", "type": "autoeval"}
        )
        assert exp_id == "exp123"

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_experiment_creation_existing(self, mock_mlflow):
        """Test experiment retrieval when experiment exists."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        # Mock experiment exists
        mock_experiment = MagicMock()
        mock_experiment.experiment_id = "exp456"
        mock_mlflow.get_experiment_by_name.return_value = mock_experiment

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )
        exp_id = tracker._get_or_create_experiment("test_exp")

        mock_mlflow.create_experiment.assert_not_called()
        assert exp_id == "exp456"


class TestLogging:
    """Tests for logging parameters, metrics, and artifacts."""

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_log_parameters(self, mock_mlflow):
        """Test that required parameters are logged correctly."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )
        tracker._log_parameters()

        # Verify required parameters were logged (10 base params)
        assert mock_mlflow.log_param.call_count >= 10
        expected_calls = [
            call("endpoint_name", "test-endpoint"),
            call("index_name", "test.index"),
            call("corpus_table", "test.corpus"),
            call("eval_queryset_size", 100),
            call("num_results", 10),
            call("query_style", "keyword"),
            call("query_columns", "text,title"),
            call("num_few_shot_examples", 2),
            call("query_type", "ANN"),
            call("reranker_enabled", False),
        ]
        mock_mlflow.log_param.assert_has_calls(expected_calls, any_order=True)

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_log_parameters_with_reranker(self, mock_mlflow):
        """Test that reranker params are logged when enabled."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()
        config.columns_to_rerank = ["text", "title"]

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN_reranker",
            eval_queryset_size=100,
            reranker_enabled=True
        )
        tracker._log_parameters()

        # Verify reranker params are logged
        mock_mlflow.log_param.assert_any_call("reranker_enabled", True)
        mock_mlflow.log_param.assert_any_call("columns_to_rerank", "text,title")

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_log_metrics(self, mock_mlflow):
        """Test that metrics with CI margins are logged correctly."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )
        tracker._log_metrics()

        # Verify 42 metrics were logged:
        # 21 metrics (5 base + 16 @k at k=1,3,5,10) × 2 (value + CI margin)
        assert mock_mlflow.log_metric.call_count == 42

        # Check a sample of expected calls (base metrics + some @k metrics)
        expected_calls = [
            # Base metrics
            call("avg_relevance_score", 2.3),
            call("avg_relevance_score_ci", 0.15),
            call("mrr", 0.55),
            call("mrr_ci", 0.04),
            # @k metrics at k=1
            call("recall_at_1", 0.35),
            call("recall_at_1_ci", 0.03),
            # @k metrics at k=5
            call("recall_at_5", 0.65),
            call("precision_at_5", 0.45),
            # @k metrics at k=10
            call("recall_at_10", 0.75),
            call("recall_at_10_ci", 0.04),
            call("precision_at_10", 0.50),
            call("ndcg_at_10", 0.65),
            call("map_at_10", 0.60),
        ]
        mock_mlflow.log_metric.assert_has_calls(expected_calls, any_order=True)

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_log_summary_artifacts(self, mock_mlflow):
        """Test that default artifacts (6 tables) are logged."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )
        tracker._log_artifacts()

        # Verify log_dict called once for few-shot examples
        mock_mlflow.log_dict.assert_called_once()

        # Verify log_table called 6 times (5 summaries + full results)
        assert mock_mlflow.log_table.call_count == 6

        # Verify the artifacts logged
        table_calls = [call[0][1] for call in mock_mlflow.log_table.call_args_list]
        expected_artifacts = [
            "score_distribution.json",
            "top_queries.json",
            "bottom_queries.json",
            "high_relevance_examples.json",
            "low_relevance_examples.json",
            "full_results.json",
        ]
        assert set(table_calls) == set(expected_artifacts)


class TestLogToMLFlow:
    """Tests for the main log_to_mlflow method."""

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_returns_run_id_experiment_id_and_trace_ids(self, mock_mlflow):
        """Test that log_to_mlflow returns tuple of (run_id, experiment_id, trace_ids)."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        # Setup mocks
        mock_mlflow.get_experiment_by_name.return_value = None
        mock_mlflow.create_experiment.return_value = "exp789"

        mock_run = MagicMock()
        mock_run.info.run_id = "run123"
        mock_run.info.experiment_id = "exp789"
        mock_mlflow.start_run.return_value.__enter__.return_value = mock_run

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )

        with patch.object(tracker, '_log_per_query_traces', return_value=["trace1", "trace2"]) as mock_log_traces:
            run_id, experiment_id, trace_ids = tracker.log_to_mlflow()

            assert run_id == "run123"
            assert experiment_id == "exp789"
            assert trace_ids == ["trace1", "trace2"]
            mock_log_traces.assert_called_once()

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_run_name_parameter(self, mock_mlflow):
        """Test that run_name is passed to mlflow.start_run."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        # Setup mocks
        mock_mlflow.get_experiment_by_name.return_value = None
        mock_mlflow.create_experiment.return_value = "exp789"

        mock_run = MagicMock()
        mock_run.info.run_id = "run123"
        mock_run.info.experiment_id = "exp789"
        mock_mlflow.start_run.return_value.__enter__.return_value = mock_run

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )

        with patch.object(tracker, '_log_per_query_traces', return_value=[]):
            tracker.log_to_mlflow(run_name="custom_run_name")

        mock_mlflow.start_run.assert_called_once_with(run_name="custom_run_name")

    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_log_to_mlflow_calls_all_helpers(self, mock_mlflow):
        """Test that log_to_mlflow calls all helper methods."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        # Setup mocks
        mock_mlflow.get_experiment_by_name.return_value = None
        mock_mlflow.create_experiment.return_value = "exp789"

        mock_run = MagicMock()
        mock_run.info.run_id = "run123"
        mock_run.info.experiment_id = "exp789"
        mock_mlflow.start_run.return_value.__enter__.return_value = mock_run

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )

        # Patch the helper methods to verify they're called
        with patch.object(tracker, '_log_per_query_traces', return_value=[]) as mock_log_traces, \
             patch.object(tracker, '_log_parameters') as mock_log_params, \
             patch.object(tracker, '_log_metrics') as mock_log_metrics, \
             patch.object(tracker, '_log_artifacts') as mock_log_artifacts:

            tracker.log_to_mlflow()

            mock_log_traces.assert_called_once()
            mock_log_params.assert_called_once()
            mock_log_metrics.assert_called_once()
            mock_log_artifacts.assert_called_once()

    @patch("autoeval_lib.mlflow_tracker.MLFLOW_TRACING_AVAILABLE", False)
    @patch("autoeval_lib.mlflow_tracker.mlflow")
    def test_skips_tracing_when_unavailable(self, mock_mlflow):
        """Test that _log_per_query_traces is NOT called when MLFLOW_TRACING_AVAILABLE=False."""
        from autoeval_lib.mlflow_tracker import MLFlowTracker

        mock_df = MagicMock()
        mock_analyzer = create_mock_analyzer()
        config = create_mock_config()

        # Setup mocks
        mock_mlflow.get_experiment_by_name.return_value = None
        mock_mlflow.create_experiment.return_value = "exp789"

        mock_run = MagicMock()
        mock_run.info.run_id = "run123"
        mock_run.info.experiment_id = "exp789"
        mock_mlflow.start_run.return_value.__enter__.return_value = mock_run

        tracker = MLFlowTracker(
            mock_df, mock_analyzer, config,
            query_type="ANN",
            eval_queryset_size=100
        )

        with patch.object(tracker, '_log_per_query_traces') as mock_log_traces:
            run_id, experiment_id, trace_ids = tracker.log_to_mlflow()

            # _log_per_query_traces should NOT be called
            mock_log_traces.assert_not_called()
            # trace_ids should be empty
            assert trace_ids == []
            # Other logging should still happen
            assert run_id == "run123"
            assert experiment_id == "exp789"


class TestGenerateExperimentPath:
    """Tests for generate_experiment_path helper function."""

    @patch("autoeval_lib.mlflow_tracker.SparkSession")
    @patch("autoeval_lib.mlflow_tracker.time")
    @patch("autoeval_lib.mlflow_tracker.F")
    def test_generates_valid_path_format(self, mock_F, mock_time, mock_spark_session):
        """Test that experiment path follows /Users/$username/vs_autoeval_$hash format."""
        from autoeval_lib.mlflow_tracker import generate_experiment_path

        # Mock time for consistent hash
        mock_time.time.return_value = 1234567890

        # Mock Spark session and DataFrame operations
        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: "john.doe@databricks.com"

        mock_spark.range.return_value.select.return_value.collect.return_value = [mock_row]

        result = generate_experiment_path("test.index")

        # Verify format - username is used as-is (with @ and .)
        assert result.startswith("/Users/john.doe@databricks.com/vs_autoeval_")
        assert len(result.split("_")[-1]) == 8  # Hash is 8 chars

    @patch("autoeval_lib.mlflow_tracker.SparkSession")
    @patch("autoeval_lib.mlflow_tracker.time")
    @patch("autoeval_lib.mlflow_tracker.F")
    def test_different_inputs_produce_different_hashes(self, mock_F, mock_time, mock_spark_session):
        """Test that different index names produce different experiment paths."""
        from autoeval_lib.mlflow_tracker import generate_experiment_path

        mock_time.time.return_value = 1234567890

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: "john.doe@databricks.com"
        mock_spark.range.return_value.select.return_value.collect.return_value = [mock_row]

        result1 = generate_experiment_path("index1")
        result2 = generate_experiment_path("index2")

        # Extract hashes
        hash1 = result1.split("_")[-1]
        hash2 = result2.split("_")[-1]

        assert hash1 != hash2

    @patch("autoeval_lib.mlflow_tracker.SparkSession")
    @patch("autoeval_lib.mlflow_tracker.time")
    @patch("autoeval_lib.mlflow_tracker.F")
    def test_gets_spark_session_internally(self, mock_F, mock_time, mock_spark_session):
        """Test that function gets spark session via getOrCreate()."""
        from autoeval_lib.mlflow_tracker import generate_experiment_path

        mock_time.time.return_value = 1234567890

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: "test.user@databricks.com"
        mock_spark.range.return_value.select.return_value.collect.return_value = [mock_row]

        generate_experiment_path("test.index")

        # Verify SparkSession.builder.getOrCreate() was called
        mock_spark_session.builder.getOrCreate.assert_called_once()
        # Verify spark.range(1) was called
        mock_spark.range.assert_called_once_with(1)
        # Verify session_user was called
        mock_F.session_user.assert_called()
