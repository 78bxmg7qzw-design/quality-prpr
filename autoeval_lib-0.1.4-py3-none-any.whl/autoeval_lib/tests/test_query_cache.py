"""Tests for query_cache module."""

import pytest
from unittest.mock import MagicMock, patch


class TestQueryCacheInit:
    """Tests for QueryCache initialization."""

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_init_gets_spark_session(self, mock_spark_session):
        """Test that init gets SparkSession."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")

        mock_spark_session.builder.getOrCreate.assert_called_once()
        assert cache.spark == mock_spark
        assert cache.index_name == "catalog.schema.index"
        assert cache.cache_table == "catalog.schema.cache"


class TestComputeQueryHash:
    """Tests for compute_query_hash method."""

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_returns_consistent_hash(self, mock_spark_session):
        """Test that same query produces same hash."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")

        hash1 = cache.compute_query_hash("test query")
        hash2 = cache.compute_query_hash("test query")

        assert hash1 == hash2
        assert len(hash1) == 64  # SHA-256 produces 64 hex characters

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_different_queries_produce_different_hashes(self, mock_spark_session):
        """Test that different queries produce different hashes."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")

        hash1 = cache.compute_query_hash("query one")
        hash2 = cache.compute_query_hash("query two")

        assert hash1 != hash2

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_different_indexes_produce_different_hashes(self, mock_spark_session):
        """Test that same query on different indexes produces different hashes."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark_session.builder.getOrCreate.return_value = MagicMock()

        cache1 = QueryCache("catalog.schema.index1", "catalog.schema.cache")
        cache2 = QueryCache("catalog.schema.index2", "catalog.schema.cache")

        hash1 = cache1.compute_query_hash("same query")
        hash2 = cache2.compute_query_hash("same query")

        assert hash1 != hash2


class TestEnsureTableExists:
    """Tests for ensure_table_exists method."""

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_creates_table_with_correct_schema(self, mock_spark_session):
        """Test that CREATE TABLE IF NOT EXISTS is used with correct schema."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache_table")
        cache.ensure_table_exists()

        mock_spark.sql.assert_called_once()
        sql_call = mock_spark.sql.call_args[0][0]
        assert "CREATE TABLE IF NOT EXISTS catalog.schema.cache_table" in sql_call
        assert "query_text STRING" in sql_call
        assert "query_hash STRING" in sql_call
        assert "query_embedding ARRAY<FLOAT>" in sql_call
        assert "rated_documents ARRAY<STRUCT" in sql_call

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_caches_table_exists_result(self, mock_spark_session):
        """Test that table existence is cached after first call."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")

        # First call
        cache.ensure_table_exists()
        assert mock_spark.sql.call_count == 1

        # Second call should be cached
        cache.ensure_table_exists()
        assert mock_spark.sql.call_count == 1  # Still 1

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_raises_error_on_permission_failure(self, mock_spark_session):
        """Test that ValueError is raised when table creation fails due to permissions."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark.sql.side_effect = Exception("Permission denied")
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")

        # Should raise ValueError
        with pytest.raises(ValueError) as exc_info:
            cache.ensure_table_exists()

        assert "Cannot create cache table" in str(exc_info.value)
        assert "CREATE TABLE permission" in str(exc_info.value)

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_raises_error_on_generic_failure(self, mock_spark_session):
        """Test that ValueError is raised when table creation fails for other reasons."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark.sql.side_effect = Exception("Some other error")
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")

        # Should raise ValueError
        with pytest.raises(ValueError) as exc_info:
            cache.ensure_table_exists()

        assert "Failed to create cache table" in str(exc_info.value)


class TestGetCachedEmbeddings:
    """Tests for get_cached_embeddings method."""

    @patch("autoeval_lib.query_cache.SparkSession")
    @patch("autoeval_lib.query_cache.F")
    def test_returns_cached_and_uncached_split(self, mock_F, mock_spark_session):
        """Test that cached and uncached queries are correctly split."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Setup mock DataFrames
        mock_queries_df = MagicMock()
        mock_cache_df = MagicMock()
        mock_joined_df = MagicMock()
        mock_cached_df = MagicMock()
        mock_uncached_df = MagicMock()

        mock_spark.table.return_value.select.return_value = mock_cache_df
        mock_queries_df.join.return_value.select.return_value = mock_joined_df
        mock_joined_df.filter.side_effect = [mock_cached_df, mock_uncached_df]
        mock_uncached_df.select.return_value = mock_uncached_df

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cached, uncached = cache.get_cached_embeddings(mock_queries_df, "doc_id")

        # Verify table was read
        mock_spark.table.assert_called_with("catalog.schema.cache")

        # Verify join was performed
        mock_queries_df.join.assert_called_once()

        assert cached == mock_cached_df
        assert uncached == mock_uncached_df


class TestStoreEmbeddingsBatch:
    """Tests for store_embeddings_batch method."""

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_stores_all_embeddings_in_single_merge(self, mock_spark_session):
        """Test that all embeddings are stored in a single MERGE operation."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock embeddings DataFrame
        mock_row1 = MagicMock()
        mock_row1.__getitem__ = lambda self, key: {
            "generated_query": "query one",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]
        mock_row2 = MagicMock()
        mock_row2.__getitem__ = lambda self, key: {
            "generated_query": "query two",
            "query_embedding": [0.4, 0.5, 0.6]
        }[key]

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.select.return_value.collect.return_value = [mock_row1, mock_row2]

        # Mock createDataFrame to return a mock DataFrame
        mock_updates_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_updates_df

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        cache.store_embeddings_batch(mock_embeddings_df)

        # Verify temp view was created
        mock_updates_df.createOrReplaceTempView.assert_called_once()

        # Verify MERGE was executed exactly once (not N times)
        mock_spark.sql.assert_called_once()
        sql_call = mock_spark.sql.call_args[0][0]
        assert "MERGE INTO catalog.schema.cache" in sql_call

        # Verify temp view was cleaned up
        mock_spark.catalog.dropTempView.assert_called_once()

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_merge_uses_unconditional_set(self, mock_spark_session):
        """Test that MERGE overwrites embeddings unconditionally.

        This ensures that if the embedding model changes, the cache stores
        the latest embeddings rather than keeping stale ones.
        """
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.select.return_value.collect.return_value = [mock_row]

        mock_updates_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_updates_df

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        cache.store_embeddings_batch(mock_embeddings_df)

        # Verify MERGE uses unconditional SET (no IS NULL check)
        sql_call = mock_spark.sql.call_args[0][0]
        assert "WHEN MATCHED THEN" in sql_call
        assert "IS NULL" not in sql_call, "MERGE should use unconditional SET, not check IS NULL"

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_uses_explicit_schema(self, mock_spark_session):
        """Test that explicit schema is passed to createDataFrame."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.select.return_value.collect.return_value = [mock_row]

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        cache.store_embeddings_batch(mock_embeddings_df)

        # Verify createDataFrame was called with rows and schema (2 arguments)
        mock_spark.createDataFrame.assert_called_once()
        call_args = mock_spark.createDataFrame.call_args
        assert len(call_args[0]) == 2, "createDataFrame should be called with explicit schema"

        rows, schema = call_args[0]
        assert isinstance(rows, list)
        assert len(rows) == 1
        assert rows[0]["query_text"] == "test query"
        assert "query_hash" in rows[0]
        assert "query_embedding" in rows[0]

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_skips_empty_dataframe(self, mock_spark_session):
        """Test that empty DataFrame is handled gracefully."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.select.return_value.collect.return_value = []

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True
        cache.store_embeddings_batch(mock_embeddings_df)

        mock_spark.sql.assert_not_called()
        mock_spark.createDataFrame.assert_not_called()

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_handles_errors_gracefully(self, mock_spark_session):
        """Test that errors are handled without raising."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_spark.createDataFrame.side_effect = Exception("DataFrame creation failed")

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.select.return_value.collect.return_value = [mock_row]

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        # Should not raise
        cache.store_embeddings_batch(mock_embeddings_df)

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_cleans_up_temp_view_on_error(self, mock_spark_session):
        """Test that temp view is cleaned up even if MERGE fails."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_updates_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_updates_df

        # Make the MERGE fail
        mock_spark.sql.side_effect = Exception("MERGE failed")

        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {
            "generated_query": "test query",
            "query_embedding": [0.1, 0.2, 0.3]
        }[key]

        mock_embeddings_df = MagicMock()
        mock_embeddings_df.select.return_value.collect.return_value = [mock_row]

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        # Should not raise
        cache.store_embeddings_batch(mock_embeddings_df)

        # Verify temp view cleanup was still called
        mock_spark.catalog.dropTempView.assert_called_once()


class TestGetCachedScoresBatch:
    """Tests for get_cached_scores_batch method."""

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_returns_cached_scores_for_multiple_queries(self, mock_spark_session):
        """Test that cached scores are returned for multiple queries in one call."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock cached results for two queries
        mock_row1 = MagicMock()
        mock_row1.query_hash = "hash1"
        mock_row1.rated_documents = [
            MagicMock(doc_id="doc1", rating=3.0),
            MagicMock(doc_id="doc2", rating=2.0),
        ]
        mock_row2 = MagicMock()
        mock_row2.query_hash = "hash2"
        mock_row2.rated_documents = [
            MagicMock(doc_id="doc3", rating=1.0),
        ]
        mock_spark.sql.return_value.collect.return_value = [mock_row1, mock_row2]

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        # Mock compute_query_hash to return predictable hashes
        cache.compute_query_hash = MagicMock(side_effect=lambda q: "hash1" if q == "query one" else "hash2")

        result = cache.get_cached_scores_batch(["query one", "query two"])

        # Verify single SQL call with IN clause
        mock_spark.sql.assert_called_once()
        sql_call = mock_spark.sql.call_args[0][0]
        assert "WHERE query_hash IN" in sql_call

        # Verify results
        assert "query one" in result
        assert result["query one"] == {"doc1": 3.0, "doc2": 2.0}
        assert "query two" in result
        assert result["query two"] == {"doc3": 1.0}

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_returns_empty_dict_for_empty_input(self, mock_spark_session):
        """Test that empty dict is returned for empty input."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        result = cache.get_cached_scores_batch([])

        assert result == {}
        mock_spark.sql.assert_not_called()

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_returns_partial_results_on_cache_miss(self, mock_spark_session):
        """Test that only cached queries are returned."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Only one query has cached results
        mock_row = MagicMock()
        mock_row.query_hash = "hash1"
        mock_row.rated_documents = [MagicMock(doc_id="doc1", rating=3.0)]
        mock_spark.sql.return_value.collect.return_value = [mock_row]

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True
        cache.compute_query_hash = MagicMock(side_effect=lambda q: f"hash{q[-1]}")

        result = cache.get_cached_scores_batch(["query1", "query2"])

        # Only query1 should be in results
        assert "query1" in result
        assert "query2" not in result

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_handles_errors_gracefully(self, mock_spark_session):
        """Test that errors return empty dict."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_spark.sql.side_effect = Exception("SQL failed")

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        result = cache.get_cached_scores_batch(["query"])

        assert result == {}


class TestStoreScoresBatch:
    """Tests for store_scores_batch method."""

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_stores_all_scores_in_single_merge(self, mock_spark_session):
        """Test that all scores are stored in a single MERGE operation."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Mock createDataFrame to return a mock DataFrame
        mock_updates_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_updates_df

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        scores_by_query = {
            "query one": {"doc1": 3.0, "doc2": 2.0},
            "query two": {"doc3": 1.0}
        }
        cache.store_scores_batch(scores_by_query)

        # Verify temp view was created
        mock_updates_df.createOrReplaceTempView.assert_called_once()

        # Verify MERGE was executed exactly once (not N times)
        mock_spark.sql.assert_called_once()
        sql_call = mock_spark.sql.call_args[0][0]
        assert "MERGE INTO catalog.schema.cache" in sql_call

        # Verify temp view was cleaned up
        mock_spark.catalog.dropTempView.assert_called_once()

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_uses_explicit_schema_to_avoid_type_inference(self, mock_spark_session):
        """Test that explicit schema is passed to createDataFrame.

        Passing an explicit schema prevents Spark from inferring types,
        which avoids type mismatch errors (e.g., DoubleType vs LongType).
        """
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        cache.store_scores_batch({"query": {"doc1": 3.0}})

        # Verify createDataFrame was called with rows and schema (2 arguments)
        mock_spark.createDataFrame.assert_called_once()
        call_args = mock_spark.createDataFrame.call_args
        # Should have 2 positional arguments: rows list and schema
        # This is the key assertion - if schema wasn't passed, there would be only 1 arg
        assert len(call_args[0]) == 2, "createDataFrame should be called with explicit schema"

        rows, schema = call_args[0]
        # Rows should be a list with the correct structure
        assert isinstance(rows, list)
        assert len(rows) == 1  # One query
        assert rows[0]["query_text"] == "query"
        assert "query_hash" in rows[0]
        assert "rated_documents" in rows[0]

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_skips_empty_scores_dict(self, mock_spark_session):
        """Test that empty scores dict is handled gracefully."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True
        cache.store_scores_batch({})

        mock_spark.sql.assert_not_called()
        mock_spark.createDataFrame.assert_not_called()

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_skips_queries_with_empty_scores(self, mock_spark_session):
        """Test that queries with empty doc_scores are skipped."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        # All queries have empty scores
        cache.store_scores_batch({"query1": {}, "query2": {}})

        mock_spark.sql.assert_not_called()

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_handles_errors_gracefully(self, mock_spark_session):
        """Test that errors are handled without raising."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_spark.createDataFrame.side_effect = Exception("DataFrame creation failed")

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        # Should not raise
        cache.store_scores_batch({"query": {"doc1": 3.0}})

    @patch("autoeval_lib.query_cache.SparkSession")
    def test_cleans_up_temp_view_on_error(self, mock_spark_session):
        """Test that temp view is cleaned up even if MERGE fails."""
        from autoeval_lib.query_cache import QueryCache

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        mock_updates_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_updates_df

        # Make the MERGE fail
        mock_spark.sql.side_effect = Exception("MERGE failed")

        cache = QueryCache("catalog.schema.index", "catalog.schema.cache")
        cache._table_available = True

        # Should not raise
        cache.store_scores_batch({"query": {"doc1": 3.0}})

        # Verify temp view cleanup was still called
        mock_spark.catalog.dropTempView.assert_called_once()
