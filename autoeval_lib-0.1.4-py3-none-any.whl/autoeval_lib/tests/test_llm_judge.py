"""Tests for llm_judge module."""

import pytest
from unittest.mock import MagicMock, patch

# Test constant for model_endpoint (required parameter)
TEST_MODEL_ENDPOINT = "test-model-endpoint"


class TestLLMJudgeInit:
    """Tests for LLMJudge initialization."""

    @patch("autoeval_lib.llm_judge.QueryCache")
    @patch("autoeval_lib.llm_judge.SparkSession")
    def test_init_gets_spark_session(self, mock_spark_session, mock_cache_class):
        """Test that init gets SparkSession."""
        from autoeval_lib.llm_judge import LLMJudge

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_cache = MagicMock()
        mock_cache_class.return_value = mock_cache

        judge = LLMJudge(
            model_endpoint=TEST_MODEL_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.cache"
        )

        mock_spark_session.builder.getOrCreate.assert_called_once()
        assert judge.spark == mock_spark
        assert judge.model_endpoint == TEST_MODEL_ENDPOINT
        assert judge.query_cache_table == "catalog.schema.cache"
        assert judge._cache == mock_cache

    @patch("autoeval_lib.llm_judge.QueryCache")
    @patch("autoeval_lib.llm_judge.SparkSession")
    def test_init_creates_cache_when_both_params_provided(self, mock_spark_session, mock_cache_class):
        """Test that cache is created when both index_name and cache_table are provided."""
        from autoeval_lib.llm_judge import LLMJudge

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark
        mock_cache = MagicMock()
        mock_cache_class.return_value = mock_cache

        judge = LLMJudge(
            model_endpoint=TEST_MODEL_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.cache"
        )

        assert judge.query_cache_table == "catalog.schema.cache"
        mock_cache_class.assert_called_once_with("catalog.schema.index", "catalog.schema.cache")
        assert judge._cache == mock_cache


class TestScoreBatch:
    """Tests for score_batch method."""

    @patch("autoeval_lib.llm_judge.QueryCache")
    @patch("autoeval_lib.llm_judge.SparkSession")
    def test_score_batch_scores_all_rows(self, mock_spark_session, mock_cache_class):
        """Test that score_batch scores all query-document pairs using batch."""
        from autoeval_lib.llm_judge import LLMJudge

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Create mock input rows
        mock_row1 = MagicMock()
        mock_row1.__getitem__ = lambda self, key: {"query": "test query 1", "retrieved_text": "doc text 1", "retrieved_doc_id": "doc1"}[key]
        mock_row1.asDict.return_value = {"query": "test query 1", "retrieved_text": "doc text 1", "retrieved_doc_id": "doc1"}

        mock_row2 = MagicMock()
        mock_row2.__getitem__ = lambda self, key: {"query": "test query 2", "retrieved_text": "doc text 2", "retrieved_doc_id": "doc2"}[key]
        mock_row2.asDict.return_value = {"query": "test query 2", "retrieved_text": "doc text 2", "retrieved_doc_id": "doc2"}

        # Setup mock input DataFrame
        mock_results_df = MagicMock()
        mock_results_df.collect.return_value = [mock_row1, mock_row2]
        mock_results_df.columns = ["query", "retrieved_text", "retrieved_doc_id"]

        # Mock batch SQL result - rows with raw_score column
        mock_batch_row1 = MagicMock()
        mock_batch_row1.asDict.return_value = {
            "query": "test query 1", "retrieved_text": "doc text 1",
            "retrieved_doc_id": "doc1", "prompt": "...", "raw_score": "3"
        }
        mock_batch_row2 = MagicMock()
        mock_batch_row2.asDict.return_value = {
            "query": "test query 2", "retrieved_text": "doc text 2",
            "retrieved_doc_id": "doc2", "prompt": "...", "raw_score": "2"
        }

        mock_batch_df = MagicMock()
        mock_batch_df.collect.return_value = [mock_batch_row1, mock_batch_row2]
        mock_spark.sql.return_value = mock_batch_df

        # Mock createDataFrame and catalog
        mock_prompt_df = MagicMock()
        mock_result_df = MagicMock()
        mock_spark.createDataFrame.side_effect = [mock_prompt_df, mock_result_df]
        mock_spark.catalog = MagicMock()

        # Mock cache to return empty for all lookups (force scoring)
        mock_cache = MagicMock()
        mock_cache.get_cached_scores_batch.return_value = {}
        mock_cache_class.return_value = mock_cache

        judge = LLMJudge(
            model_endpoint=TEST_MODEL_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.cache"
        )
        result = judge.score_batch(mock_results_df)

        # Should make one batch SQL call (not N individual calls)
        assert mock_spark.sql.call_count == 1
        # Should create temp view and drop it
        mock_prompt_df.createOrReplaceTempView.assert_called_once()
        mock_spark.catalog.dropTempView.assert_called_once()

    @patch("autoeval_lib.llm_judge.QueryCache")
    @patch("autoeval_lib.llm_judge.SparkSession")
    def test_score_batch_adds_llm_relevance_score_to_rows(self, mock_spark_session, mock_cache_class):
        """Test that score_batch adds llm_relevance_score to each row."""
        from autoeval_lib.llm_judge import LLMJudge

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Create mock input row
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {"query": "test query", "retrieved_text": "doc text", "retrieved_doc_id": "doc1"}[key]
        mock_row.asDict.return_value = {"query": "test query", "retrieved_text": "doc text", "retrieved_doc_id": "doc1"}

        mock_results_df = MagicMock()
        mock_results_df.collect.return_value = [mock_row]
        mock_results_df.columns = ["query", "retrieved_text", "retrieved_doc_id"]

        # Mock batch SQL result
        mock_batch_row = MagicMock()
        mock_batch_row.asDict.return_value = {
            "query": "test query", "retrieved_text": "doc text",
            "retrieved_doc_id": "doc1", "prompt": "...", "raw_score": "2"
        }
        mock_batch_df = MagicMock()
        mock_batch_df.collect.return_value = [mock_batch_row]
        mock_spark.sql.return_value = mock_batch_df

        # Track createDataFrame calls
        created_data = []
        def track_create_df(data):
            created_data.append(list(data) if hasattr(data, '__iter__') else data)
            return MagicMock()
        mock_spark.createDataFrame.side_effect = track_create_df
        mock_spark.catalog = MagicMock()

        # Mock cache to return empty for all lookups (force scoring)
        mock_cache = MagicMock()
        mock_cache.get_cached_scores_batch.return_value = {}
        mock_cache_class.return_value = mock_cache

        judge = LLMJudge(
            model_endpoint=TEST_MODEL_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.cache"
        )
        judge.score_batch(mock_results_df)

        # Second createDataFrame call should have rows with llm_relevance_score
        final_rows = created_data[-1]
        assert len(final_rows) == 1
        assert "llm_relevance_score" in final_rows[0]
        assert final_rows[0]["llm_relevance_score"] == 2.0  # float for consistency with cache


class TestScoreBatchWithCache:
    """Tests for score_batch with caching enabled."""

    @patch("autoeval_lib.llm_judge.SparkSession")
    def test_checks_cache_when_configured(self, mock_spark_session):
        """Test that cache is checked using batch method when configured."""
        from autoeval_lib.llm_judge import LLMJudge

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Create mock row
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {"query": "test query", "retrieved_text": "doc text", "retrieved_doc_id": "doc1"}[key]
        mock_row.asDict.return_value = {"query": "test query", "retrieved_text": "doc text", "retrieved_doc_id": "doc1"}

        mock_results_df = MagicMock()
        mock_results_df.collect.return_value = [mock_row]
        mock_results_df.columns = ["query", "retrieved_text", "retrieved_doc_id"]

        mock_result_df = MagicMock()
        mock_spark.createDataFrame.return_value = mock_result_df

        judge = LLMJudge(
            model_endpoint=TEST_MODEL_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.cache"
        )

        # Mock the cache after creation - use batch method
        mock_cache = MagicMock()
        mock_cache.get_cached_scores_batch.return_value = {"test query": {"doc1": 3.0}}
        judge._cache = mock_cache

        judge.score_batch(mock_results_df, primary_key_column="retrieved_doc_id")

        # Should check cache using batch method
        mock_cache.get_cached_scores_batch.assert_called_once()
        call_args = mock_cache.get_cached_scores_batch.call_args[0][0]
        assert "test query" in call_args

    @patch("autoeval_lib.llm_judge.SparkSession")
    def test_stores_new_scores_in_batch_on_cache_miss(self, mock_spark_session):
        """Test that new scores are stored in cache using batch method on cache miss."""
        from autoeval_lib.llm_judge import LLMJudge

        mock_spark = MagicMock()
        mock_spark_session.builder.getOrCreate.return_value = mock_spark

        # Create mock row
        mock_row = MagicMock()
        mock_row.__getitem__ = lambda self, key: {"query": "test query", "retrieved_text": "doc text", "retrieved_doc_id": "doc1"}[key]
        mock_row.asDict.return_value = {"query": "test query", "retrieved_text": "doc text", "retrieved_doc_id": "doc1"}

        mock_results_df = MagicMock()
        mock_results_df.collect.return_value = [mock_row]
        mock_results_df.columns = ["query", "retrieved_text", "retrieved_doc_id"]

        # Mock batch SQL result
        mock_batch_row = MagicMock()
        mock_batch_row.asDict.return_value = {
            "query": "test query", "retrieved_text": "doc text",
            "retrieved_doc_id": "doc1", "prompt": "...", "raw_score": "2"
        }
        mock_batch_df = MagicMock()
        mock_batch_df.collect.return_value = [mock_batch_row]
        mock_spark.sql.return_value = mock_batch_df

        mock_prompt_df = MagicMock()
        mock_result_df = MagicMock()
        mock_spark.createDataFrame.side_effect = [mock_prompt_df, mock_result_df]
        mock_spark.catalog = MagicMock()

        judge = LLMJudge(
            model_endpoint=TEST_MODEL_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.cache"
        )

        # Mock the cache after creation
        mock_cache = MagicMock()
        mock_cache.get_cached_scores_batch.return_value = {}  # No cached scores
        judge._cache = mock_cache

        judge.score_batch(mock_results_df, primary_key_column="retrieved_doc_id")

        # Should store new scores in cache using batch method
        mock_cache.store_scores_batch.assert_called_once_with({"test query": {"doc1": 2.0}})
        # Old store_scores should NOT be called
        mock_cache.store_scores.assert_not_called()

