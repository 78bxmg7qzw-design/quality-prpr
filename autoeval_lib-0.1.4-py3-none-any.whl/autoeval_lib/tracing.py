"""MLflow tracing utilities for autoeval.

This module provides tracing functionality to capture detailed evaluation data
for each query, using MLflow's @trace decorator and Document objects for
visibility in Databricks MLflow UI.

Note: Tracing features require MLflow 2.14.0+. On older versions, tracing
functions will still work but won't create traces.
"""

from __future__ import annotations

import mlflow
from typing import Any

from .constants import Columns, MLflowParams, TracingFields, Defaults

# Try to import Document class (requires MLflow 2.14.0+)
try:
    from mlflow.entities import Document
    MLFLOW_TRACING_AVAILABLE = True
except ImportError:
    Document = None
    MLFLOW_TRACING_AVAILABLE = False


def _to_mlflow_document(result: dict[str, Any], original_doc_id: str):
    """Convert a result dict to MLflow Document for tracing.

    Args:
        result: Dictionary with result fields (from Columns/TracingFields constants)
        original_doc_id: The doc_id that generated the query (for recall check)

    Returns:
        MLflow Document with page_content and metadata, or dict if Document not available
    """
    C = Columns
    T = TracingFields
    truncate_limit = Defaults.TEXT_TRUNCATION_LIMIT

    retrieved_doc_id = result.get(C.RETRIEVED_DOC_ID)

    metadata = {
        "doc_id": retrieved_doc_id,
        "title": (result.get(C.TITLE) or "")[:truncate_limit],
        "rank": result.get(T.RANK),
        "search_score": result.get(C.SEARCH_SCORE, 0),
        "llm_relevance_score": result.get(C.LLM_RELEVANCE_SCORE),
        "original_doc_id": original_doc_id,
        "is_recall_hit": retrieved_doc_id == original_doc_id
    }

    page_content = (result.get(C.TEXT_PREVIEW) or "")[:truncate_limit]

    if MLFLOW_TRACING_AVAILABLE and Document is not None:
        return Document(page_content=page_content, metadata=metadata)
    else:
        # Fallback for older MLflow versions - return dict
        return {"page_content": page_content, "metadata": metadata}


def _trace_single_query_impl(
    query_text: str,
    original_doc_id: str,
    query_type: str,
    results: list[dict[str, Any]]
) -> list:
    """Implementation of trace_single_query that converts results to Documents.

    Args:
        query_text: The search query text
        original_doc_id: The doc_id that generated this query
        query_type: The search mode (FULL_TEXT, ANN, HYBRID)
        results: List of result dicts with TraceFields keys

    Returns:
        List of MLflow Document objects (or dicts) representing search results
    """
    return [_to_mlflow_document(r, original_doc_id) for r in results]


# Create the traced function if tracing is available
if MLFLOW_TRACING_AVAILABLE:
    @mlflow.trace(name="eval_query", span_type="RETRIEVER")
    def _trace_single_query(
        query_text: str,
        original_doc_id: str,
        query_type: str,
        results: list[dict[str, Any]]
    ) -> list:
        """Trace a single query's results.

        Each call to this function creates one trace in MLflow.

        Args:
            query_text: The search query text
            original_doc_id: The doc_id that generated this query
            query_type: The search mode (FULL_TEXT, ANN, HYBRID)
            results: List of result dicts with TraceFields keys

        Returns:
            List of MLflow Document objects representing search results
        """
        return _trace_single_query_impl(query_text, original_doc_id, query_type, results)
else:
    # No tracing available - just call the implementation directly
    _trace_single_query = _trace_single_query_impl


def log_query_type_traces(
    query_type: str,
    scored_df,  # Spark DataFrame with scored results
    endpoint_name: str,
    index_name: str,
    num_results: int
) -> list[str]:
    """Log traces for all queries in a query type evaluation.

    Creates one trace per query using the @trace decorator. Each trace is
    a RETRIEVER span containing Document objects with search results and
    LLM relevance scores.

    Args:
        query_type: The query type (FULL_TEXT, ANN, or HYBRID)
        scored_df: Spark DataFrame containing scored search results
        endpoint_name: Vector search endpoint name
        index_name: Vector search index name
        num_results: Number of results requested per query

    Returns:
        List of trace IDs for the logged traces
    """
    C = Columns
    T = TracingFields

    # Group results by query
    rows = scored_df.collect()
    queries: dict[str, dict[str, Any]] = {}

    for row in rows:
        row_dict = row.asDict()
        query = row_dict[C.QUERY]
        if query not in queries:
            queries[query] = {
                C.ORIGINAL_DOC_ID: row_dict[C.ORIGINAL_DOC_ID],
                T.RESULTS: []
            }
        queries[query][T.RESULTS].append({
            C.RETRIEVED_DOC_ID: row_dict[C.RETRIEVED_DOC_ID],
            T.RANK: row_dict[C.RESULT_RANK],
            C.TITLE: row_dict.get(C.RETRIEVED_TITLE),
            C.TEXT_PREVIEW: row_dict.get(C.RETRIEVED_TEXT),
            C.SEARCH_SCORE: row_dict.get(C.SEARCH_SCORE) or 0,
            C.LLM_RELEVANCE_SCORE: row_dict[C.LLM_RELEVANCE_SCORE]
        })

    # Log trace for each query
    trace_ids = []
    for query_text, data in queries.items():
        original_doc_id = data[C.ORIGINAL_DOC_ID]
        results = sorted(data[T.RESULTS], key=lambda x: x[T.RANK])

        # Call traced function - creates one trace per query
        _trace_single_query(query_text, original_doc_id, query_type, results)

        # Get the trace ID (only works with MLflow 2.14.0+)
        try:
            trace_id = mlflow.get_last_active_trace_id()
            if trace_id:
                trace_ids.append(trace_id)
        except AttributeError:
            # get_last_active_trace_id not available in older MLflow
            pass

    return trace_ids
