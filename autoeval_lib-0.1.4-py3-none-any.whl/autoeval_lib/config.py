"""Configuration dataclasses for AutoEval."""

from __future__ import annotations

from dataclasses import dataclass, field

from autoeval_lib.constants import APIKeys, Defaults, QueryStyle, QueryType, MLflowTags

# Lazy imports for permission validation (imported at module level for testability)
# These are imported here but used in methods to avoid circular imports
try:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import EndpointStateReady
except ImportError:
    WorkspaceClient = None  # Will fail at runtime if not installed
    EndpointStateReady = None


def quote_sql_identifier(identifier: str) -> str:
    """Quote a SQL identifier with backticks if needed.

    Adds backticks around identifiers that contain special characters
    (dashes, spaces, etc.) that would otherwise be invalid in SQL.

    Args:
        identifier: A single identifier (catalog, schema, or table name)

    Returns:
        The identifier wrapped in backticks if it contains special chars,
        or the original identifier if it's already safe.
    """
    # If already quoted, return as-is
    if identifier.startswith('`') and identifier.endswith('`'):
        return identifier

    # Characters that require quoting (non-alphanumeric except underscore)
    needs_quoting = not identifier.replace('_', '').isalnum()

    if needs_quoting:
        # Escape any existing backticks in the identifier
        escaped = identifier.replace('`', '``')
        return f'`{escaped}`'
    return identifier


def quote_table_name(table_name: str) -> str:
    """Quote each component of a fully qualified table name.

    Splits a table name like 'catalog.schema.table' into components
    and quotes each one with backticks if needed.

    Args:
        table_name: Fully qualified table name (catalog.schema.table)

    Returns:
        Table name with each component properly quoted if needed.
        e.g., 'my_catalog.vector-search-data.my_table' becomes
              'my_catalog.`vector-search-data`.my_table'
    """
    if not table_name:
        return table_name

    components = table_name.split('.')
    quoted_components = [quote_sql_identifier(c) for c in components]
    return '.'.join(quoted_components)


def compute_k_values(num_results: int) -> list[int]:
    """Compute k values for metrics based on num_results.

    Args:
        num_results: Maximum number of results per query

    Returns:
        List of k values (e.g., [1, 3, 5, 10] for num_results=10)
    """
    return [k for k in Defaults.STANDARD_K_VALUES if k <= num_results]


def _validate_endpoint_name(endpoint_name: str, field_name: str) -> None:
    """Validate endpoint name contains only safe characters for SQL.

    Endpoint names are interpolated into SQL strings for ai_query() calls.
    This validation prevents SQL injection by ensuring only safe characters.

    Args:
        endpoint_name: The model serving endpoint name
        field_name: Name of the config field (for error message)

    Raises:
        ValueError: If endpoint name contains unsafe characters
    """
    import re
    if not re.match(r'^[a-zA-Z0-9_-]+$', endpoint_name):
        raise ValueError(
            f"Invalid {field_name} '{endpoint_name}'. "
            "Endpoint names must contain only alphanumeric characters, hyphens, and underscores."
        )


@dataclass
class AutoEvalConfig:
    """Configuration for AutoEval evaluation runs.

    User-provided (Required):
        index_name: Vector search index name (catalog.schema.index)
        query_columns: Columns containing text content for query generation
        query_cache_table: Cache table for embeddings/scores (catalog.schema.table)

    User-provided (Optional):
        query_generation_llm_endpoint: LLM endpoint for query generation (default: databricks-gpt-5-mini)
        relevance_judge_llm_endpoint: LLM endpoint for relevance scoring (default: databricks-meta-llama-3-1-70b-instruct)
        embedding_model: Embedding model (default: "" - auto-derived for managed indexes)
        query_style: "natural", "keyword", or "mixed" (default: mixed)
        num_samples: Documents to sample for few-shot examples (default: 20)
        num_queries: Queries to generate for evaluation (default: 200)
        num_results: Results to fetch per query (default: 10)
        query_types: Search modes to evaluate (default: ["FULL_TEXT", "ANN", "HYBRID"])
        additional_retrieval_columns: Extra columns to retrieve (default: [])
        additional_reranker_columns: Extra columns for reranker (default: [])
        enable_reranker: Run with/without reranker (default: True)
        random_seed: Reproducibility seed (default: None)
        enable_mlflow_logging: Enable MLflow logging (default: True)
        mlflow_experiment_path: Custom MLflow experiment path (default: None - auto-generates)
        few_shot_examples: Custom few-shot examples (default: [])

    Auto-derived (from index.describe()):
        endpoint_name: Vector search endpoint
        corpus_table: Source table for the index
        primary_key: Primary key column
        embedding_model: Embedding model endpoint (derived if not provided)

    Computed:
        columns_to_retrieve: [primary_key] + query_columns + additional_retrieval_columns
        columns_to_rerank: query_columns + additional_reranker_columns
        k_values: Dynamic k values based on num_results
    """

    # Required (user must provide)
    index_name: str
    query_columns: list[str]
    query_cache_table: str

    # Optional with defaults
    query_generation_llm_endpoint: str = Defaults.QUERY_GENERATION_LLM_ENDPOINT
    relevance_judge_llm_endpoint: str = Defaults.RELEVANCE_JUDGE_LLM_ENDPOINT
    embedding_model: str = ""  # Empty = auto-derive from index
    query_style: str = QueryStyle.MIXED
    num_samples: int = Defaults.NUM_SAMPLES
    num_queries: int = Defaults.NUM_QUERIES
    num_results: int = Defaults.NUM_RESULTS
    query_types: list[str] = field(default_factory=lambda: QueryType.ALL.copy())
    additional_retrieval_columns: list[str] = field(default_factory=list)
    additional_reranker_columns: list[str] = field(default_factory=list)
    enable_reranker: bool = True
    random_seed: int | None = None
    enable_mlflow_logging: bool = True
    mlflow_experiment_path: str | None = None
    few_shot_examples: list[dict[str, str]] = field(default_factory=list)

    # Auto-derived (populated by validate(), not user-provided)
    endpoint_name: str | None = field(default=None, init=False)
    corpus_table: str | None = field(default=None, init=False)
    primary_key: str | None = field(default=None, init=False)

    # Computed (populated by validate())
    columns_to_retrieve: list[str] = field(default_factory=list, init=False)
    columns_to_rerank: list[str] = field(default_factory=list, init=False)
    k_values: list[int] = field(default_factory=list, init=False)

    # Internal
    _validated: bool = field(default=False, init=False, repr=False)

    def is_validated(self) -> bool:
        """Check if this config has been validated.

        Returns:
            True if validate() has been called successfully, False otherwise.
        """
        return self._validated

    def validate(self) -> "AutoEvalConfig":
        """Validate config and populate auto-derived fields from index metadata.

        Connects to the Vector Search index to:
        1. Validate user-provided fields (query_generation_llm_endpoint, relevance_judge_llm_endpoint, query_style, query_types)
        2. Verify the index exists and is ready
        3. Extract endpoint_name, corpus_table, primary_key, embedding_model
        4. Compute derived fields (columns_to_retrieve, columns_to_rerank, k_values)
        5. Validate all required derived fields exist

        Returns:
            self (for method chaining)

        Raises:
            ValueError: If validation fails
        """
        from databricks.vector_search.client import VectorSearchClient

        # ===== Step 1: Validate user-provided fields =====

        # Validate query_generation_llm_endpoint is not empty
        if not self.query_generation_llm_endpoint or not self.query_generation_llm_endpoint.strip():
            raise ValueError("query_generation_llm_endpoint cannot be empty")

        # Validate relevance_judge_llm_endpoint is not empty
        if not self.relevance_judge_llm_endpoint or not self.relevance_judge_llm_endpoint.strip():
            raise ValueError("relevance_judge_llm_endpoint cannot be empty")

        # Validate endpoint names contain only safe characters (SQL injection prevention)
        _validate_endpoint_name(self.query_generation_llm_endpoint, "query_generation_llm_endpoint")
        _validate_endpoint_name(self.relevance_judge_llm_endpoint, "relevance_judge_llm_endpoint")
        if self.embedding_model:
            _validate_endpoint_name(self.embedding_model, "embedding_model")

        # Validate and normalize query_style
        self.query_style = self.query_style.lower()
        if self.query_style not in QueryStyle.VALID:
            raise ValueError(
                f"query_style must be one of {QueryStyle.VALID}, got '{self.query_style}'"
            )

        # Validate and normalize query_types
        normalized_types = []
        for qt in self.query_types:
            if qt.lower() not in QueryType.VALID_LOWERCASE:
                raise ValueError(
                    f"Invalid query_type '{qt}'. Must be one of: {QueryType.ALL}"
                )
            # Normalize to uppercase for API calls
            normalized_types.append(qt.upper())
        self.query_types = normalized_types

        # Validate numeric fields
        if self.num_samples < 1:
            raise ValueError("num_samples must be at least 1")
        if self.num_queries < 1:
            raise ValueError("num_queries must be at least 1")
        if self.num_results < 1:
            raise ValueError("num_results must be at least 1")
        if self.num_results > Defaults.MAX_NUM_RESULTS:
            raise ValueError(f"num_results must be at most {Defaults.MAX_NUM_RESULTS}")
        if not self.query_columns:
            raise ValueError("query_columns must not be empty")

        # Validate query_cache_table is not empty
        if not self.query_cache_table or not self.query_cache_table.strip():
            raise ValueError("query_cache_table cannot be empty")

        # ===== Step 2: Connect to index and get metadata =====
        vsc = VectorSearchClient(disable_notice=True)
        try:
            index = vsc.get_index(index_name=self.index_name)
            index_info = index.describe()
        except Exception as e:
            raise ValueError(f"Failed to access index '{self.index_name}': {e}")

        # Validate index is ready
        status = index_info.get(APIKeys.STATUS, {})
        if not status.get(APIKeys.READY, False):
            raise ValueError(
                f"Index '{self.index_name}' is not ready. "
                f"Status: {status.get(APIKeys.DETAILED_STATE, 'unknown')}"
            )

        # ===== Step 3: Derive fields from index metadata =====
        self.endpoint_name = index_info.get(APIKeys.ENDPOINT_NAME)
        self.primary_key = index_info.get(APIKeys.PRIMARY_KEY)

        delta_spec = index_info.get(APIKeys.DELTA_SYNC_INDEX_SPEC, {})
        source_table = delta_spec.get(APIKeys.SOURCE_TABLE)
        # Quote table name components for SQL safety (handles dashes, etc.)
        self.corpus_table = quote_table_name(source_table) if source_table else None

        # Handle embedding_model: derive if empty/None
        if not self.embedding_model:
            embedding_cols = delta_spec.get(APIKeys.EMBEDDING_SOURCE_COLUMNS, [])
            if embedding_cols:
                self.embedding_model = embedding_cols[0].get(APIKeys.EMBEDDING_MODEL_ENDPOINT_NAME)

            # If still empty after derivation, raise error
            if not self.embedding_model:
                raise ValueError(
                    "embedding_model not provided and could not be derived from index. "
                    "This index may be self-managed (not using managed embeddings). "
                    "Please provide the embedding_model parameter explicitly."
                )

        # ===== Step 4: Validate derived fields are not empty =====
        if not self.endpoint_name:
            raise ValueError(
                f"Could not derive endpoint_name from index '{self.index_name}'"
            )
        if not self.primary_key:
            raise ValueError(
                f"Could not derive primary_key from index '{self.index_name}'"
            )
        if not self.corpus_table:
            raise ValueError(
                f"Could not derive corpus_table (source_table) from index '{self.index_name}'"
            )

        # ===== Step 5: Compute derived fields =====
        self.columns_to_retrieve = self._compute_columns_to_retrieve()
        self.columns_to_rerank = self._compute_columns_to_rerank()
        self.k_values = compute_k_values(self.num_results)

        # ===== Step 6: Validate permissions on resources =====
        self._validate_permissions()

        self._validated = True

        # Display derived configuration
        print("Configuration validated successfully!")
        print(f"  Endpoint: {self.endpoint_name}")
        print(f"  Corpus Table: {self.corpus_table}")
        print(f"  Primary Key: {self.primary_key}")
        print(f"  Embedding Model: {self.embedding_model}")
        print(f"  Columns to Retrieve: {self.columns_to_retrieve}")
        print(f"  Columns to Rerank: {self.columns_to_rerank}")

        return self

    def _compute_columns_to_retrieve(self) -> list[str]:
        """Compute columns_to_retrieve = [primary_key] + query_columns + additional."""
        cols = []
        if self.primary_key:
            cols.append(self.primary_key)
        cols.extend(self.query_columns)
        cols.extend(self.additional_retrieval_columns)
        # Deduplicate while preserving order
        return list(dict.fromkeys(cols))

    def _compute_columns_to_rerank(self) -> list[str]:
        """Compute columns_to_rerank = query_columns + additional_reranker_columns."""
        cols = list(self.query_columns)
        cols.extend(self.additional_reranker_columns)
        return list(dict.fromkeys(cols))

    def _validate_permissions(self) -> None:
        """Validate user has required permissions on all configured resources.

        Checks access to:
        1. Corpus table (SELECT permission)
        2. Embedding model endpoint (exists and ready)
        3. LLM endpoint (exists and ready)
        4. MLflow experiment (if tracing enabled)

        Note: Query cache table is NOT validated here - if cache creation fails
        at runtime, we warn and proceed without caching.

        Raises:
            ValueError: If user lacks required permissions on any resource
        """
        # 1. Corpus table - READ access (table name is already quoted)
        self._check_table_read_access(self.corpus_table)

        # 2. Query cache table - CREATE/WRITE access
        self._check_cache_table_access()

        # 3. Embedding model endpoint - USE access
        self._check_model_endpoint_access(self.embedding_model, "Embedding model")

        # 4. Query generation LLM endpoint - USE access
        self._check_model_endpoint_access(self.query_generation_llm_endpoint, "Query generation LLM")

        # 5. Relevance judge LLM endpoint - USE access
        self._check_model_endpoint_access(self.relevance_judge_llm_endpoint, "Relevance judge LLM")

        # 6. MLflow experiment - CREATE/WRITE access (if tracing enabled)
        if self.enable_mlflow_logging:
            # Use provided path or generate one
            from autoeval_lib.mlflow_tracker import generate_experiment_path
            exp_path = self.mlflow_experiment_path or generate_experiment_path(self.index_name)
            self._check_mlflow_experiment_access(exp_path)

        # Note: Vector search index access already validated by index.describe()

    def _check_table_read_access(self, table_name: str) -> None:
        """Verify SELECT access on a Delta table.

        Args:
            table_name: Fully qualified table name (already quoted if needed)

        Raises:
            ValueError: If user lacks SELECT permission or table doesn't exist
        """
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        try:
            # Minimal query - doesn't read actual data, just checks access
            spark.sql(f"SELECT 1 FROM {table_name} LIMIT 0")
        except Exception as e:
            error_msg = str(e).lower()
            if "permission" in error_msg or "access" in error_msg or "denied" in error_msg:
                raise ValueError(
                    f"Missing SELECT permission on table '{table_name}'. "
                    f"Grant access with: GRANT SELECT ON TABLE {table_name} TO `your_user`"
                ) from e
            elif "not found" in error_msg or "does not exist" in error_msg:
                raise ValueError(f"Table '{table_name}' does not exist.") from e
            raise  # Re-raise unknown errors

    def _check_cache_table_access(self) -> None:
        """Validate cache table can be created and accessed.

        Attempts to create the cache table (if it doesn't exist) and verifies
        the user has required permissions.

        Raises:
            ValueError: If table cannot be created due to permissions or invalid path
        """
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()

        # Quote table name for SQL safety
        quoted_table = quote_table_name(self.query_cache_table)

        try:
            spark.sql(f"""
                CREATE TABLE IF NOT EXISTS {quoted_table} (
                    query_text STRING NOT NULL,
                    query_hash STRING NOT NULL,
                    query_embedding ARRAY<FLOAT>,
                    rated_documents ARRAY<STRUCT<doc_id: STRING, rating: FLOAT>>
                )
                USING DELTA
                COMMENT 'Cache table for query embeddings and LLM scores'
            """)
        except Exception as e:
            error_msg = str(e).lower()
            if "permission" in error_msg or "access" in error_msg or "denied" in error_msg:
                raise ValueError(
                    f"Cannot create cache table '{self.query_cache_table}'. "
                    f"Ensure you have CREATE TABLE permission on the target schema."
                ) from e
            elif "not found" in error_msg or "does not exist" in error_msg:
                raise ValueError(
                    f"Schema for cache table '{self.query_cache_table}' does not exist. "
                    f"Ensure the catalog and schema exist before running."
                ) from e
            raise ValueError(f"Failed to create cache table '{self.query_cache_table}': {e}") from e

    def _check_model_endpoint_access(self, endpoint_name: str, endpoint_type: str) -> None:
        """Verify access to a model serving endpoint.

        Args:
            endpoint_name: Name of the model serving endpoint
            endpoint_type: Human-readable type ("Embedding model" or "LLM")

        Raises:
            ValueError: If endpoint doesn't exist, user lacks access, or endpoint not ready
        """
        if WorkspaceClient is None:
            raise ImportError("databricks-sdk is required for permission validation")
        try:
            w = WorkspaceClient()
            endpoint = w.serving_endpoints.get(endpoint_name)
            # Check if endpoint is ready
            state = endpoint.state
            if state and state.ready != EndpointStateReady.READY:
                raise ValueError(
                    f"{endpoint_type} endpoint '{endpoint_name}' is not ready. "
                    f"Status: {state.ready}"
                )
        except ValueError:
            raise  # Re-raise our own errors
        except Exception as e:
            error_msg = str(e).lower()
            if "permission" in error_msg or "denied" in error_msg or "unauthorized" in error_msg:
                raise ValueError(
                    f"Missing access to {endpoint_type} endpoint '{endpoint_name}'. "
                    f"Ensure you have CAN_QUERY permission on this endpoint."
                ) from e
            elif "not found" in error_msg or "does not exist" in error_msg:
                raise ValueError(
                    f"{endpoint_type} endpoint '{endpoint_name}' does not exist."
                ) from e
            raise

    def _check_mlflow_experiment_access(self, experiment_path: str) -> None:
        """Verify access to MLflow experiment (or ability to create it).

        Args:
            experiment_path: MLflow experiment path (e.g., "/Users/user@domain.com/my_experiment")

        Raises:
            ValueError: If user cannot access or create the experiment
        """
        import mlflow
        try:
            # Try to get existing experiment
            experiment = mlflow.get_experiment_by_name(experiment_path)
            if experiment is not None:
                # Experiment exists - check it's not deleted
                if experiment.lifecycle_stage == MLflowTags.LIFECYCLE_STAGE_DELETED:
                    raise ValueError(
                        f"MLflow experiment '{experiment_path}' has been deleted. "
                        f"Please restore it or use a different experiment path."
                    )
                # Experiment exists and is active - we can access it
                return

            # Experiment doesn't exist - try to create it to validate permissions
            # Then immediately delete it (we'll create it properly at runtime)
            experiment_id = mlflow.create_experiment(
                name=experiment_path,
                tags={
                    MLflowTags.PRODUCT: MLflowTags.PRODUCT_VALUE,
                    MLflowTags.TYPE: MLflowTags.TYPE_VALUE_VALIDATION
                }
            )
            # Created successfully - now delete it (validation complete)
            mlflow.delete_experiment(experiment_id)
        except ValueError:
            raise  # Re-raise our own errors
        except Exception as e:
            error_msg = str(e).lower()
            if "permission" in error_msg or "denied" in error_msg or "unauthorized" in error_msg:
                raise ValueError(
                    f"Cannot create MLflow experiment at '{experiment_path}'. "
                    f"Ensure you have permission to create experiments in this location."
                ) from e
            raise
