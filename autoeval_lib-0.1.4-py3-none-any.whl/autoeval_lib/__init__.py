"""AutoEval Library - Vector Search Quality Evaluation Tools.

This library provides tools for evaluating vector search quality using
synthetic query generation and LLM-based relevance scoring.
"""

from autoeval_lib.query_generator import QueryGenerator
from autoeval_lib.search_client import SearchClient
from autoeval_lib.llm_judge import LLMJudge
from autoeval_lib.metrics import MetricsAnalyzer, format_with_ci
from autoeval_lib.config import AutoEvalConfig, compute_k_values, quote_table_name
from autoeval_lib.mlflow_tracker import (
    MLFlowTracker,
    generate_experiment_path,
)
from autoeval_lib.evaluator import MultiQueryEvaluator, EvalResult
from autoeval_lib.query_cache import QueryCache
from autoeval_lib.constants import Columns, TracingFields, Defaults

__all__ = [
    "QueryGenerator",
    "SearchClient",
    "LLMJudge",
    "MetricsAnalyzer",
    "format_with_ci",
    "AutoEvalConfig",
    "MLFlowTracker",
    "generate_experiment_path",
    "MultiQueryEvaluator",
    "EvalResult",
    "compute_k_values",
    "quote_table_name",
    "QueryCache",
    "Columns",
    "TracingFields",
    "Defaults",
]

__version__ = "0.1.4"
