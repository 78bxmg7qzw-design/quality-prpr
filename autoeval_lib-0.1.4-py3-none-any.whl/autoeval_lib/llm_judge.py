"""LLM-based relevance scoring for search results."""

from __future__ import annotations

import re
from pyspark.sql import SparkSession, DataFrame

from autoeval_lib.prompts import build_relevance_scoring_prompt
from autoeval_lib.query_cache import QueryCache
from autoeval_lib.constants import Columns, Scoring


class LLMJudge:
    """Scores query-document pair relevance using LLM.

    Uses Databricks ai_query() to rate how relevant each retrieved document
    is to its query on a 0-3 scale. Supports caching scores to avoid
    redundant LLM calls across query types.

    Scale:
        3 - Highly Relevant: Document directly answers the query
        2 - Relevant: Document is related and provides useful information
        1 - Partially Relevant: Document mentions topic but not useful
        0 - Not Relevant: Document is unrelated to the query

    Example:
        from autoeval_lib.constants import Defaults

        judge = LLMJudge(
            model_endpoint=Defaults.RELEVANCE_JUDGE_LLM_ENDPOINT,
            index_name="catalog.schema.index",
            query_cache_table="catalog.schema.query_cache"
        )
        scored_df = judge.score_batch(results_df, primary_key_column="retrieved_doc_id")
    """

    def __init__(
        self,
        model_endpoint: str,
        index_name: str,
        query_cache_table: str
    ):
        """Initialize the LLMJudge.

        Args:
            model_endpoint: Model serving endpoint for ai_query() calls.
            index_name: Fully qualified index name (catalog.schema.index).
                Used in cache key computation to ensure scores are specific
                to each index.
            query_cache_table: Table to cache LLM scores.
                Format: "catalog.schema.table". Scores are cached/retrieved
                from this table to avoid redundant LLM calls.
        """
        self.spark = SparkSession.builder.getOrCreate()
        self.model_endpoint = model_endpoint
        self.index_name = index_name
        self.query_cache_table = query_cache_table
        self._cache = QueryCache(index_name, query_cache_table)

    def _parse_score(self, raw_score: str | None) -> float:
        """Parse LLM response to extract relevance score.

        Args:
            raw_score: Raw string response from ai_query

        Returns:
            Relevance score as float (0.0-3.0), or 0.0 if parsing fails
        """
        score_text = str(raw_score).strip() if raw_score is not None else "0"
        match = re.search(Scoring.SCORE_REGEX, score_text)
        if match:
            return float(match.group())
        else:
            print(f"Warning: Failed to parse relevance score from LLM response: '{score_text[:100]}'. Defaulting to 0.0.")
            return 0.0

    def score_batch(
        self,
        results_df: DataFrame,
        primary_key_column: str = "retrieved_doc_id"
    ) -> DataFrame:
        """Score all query-document pairs in the results.

        Uses batch ai_query() calls for performance. Uses cache when available
        to avoid redundant LLM calls for the same (query, document) pairs.

        Args:
            results_df: DataFrame with 'query', 'retrieved_text', and primary key columns
            primary_key_column: Name of the column containing the document primary key.
                Used for cache lookups.

        Returns:
            DataFrame with all original columns plus 'llm_relevance_score'
        """
        rows = results_df.collect()
        total_count = len(rows)

        # Build cached scores lookup (batch for efficiency)
        queries = list(set(row[Columns.QUERY] for row in rows))
        print(f"Checking cache for {len(queries)} unique queries...")
        cached_scores = self._cache.get_cached_scores_batch(queries)

        # Separate rows into cached and uncached
        cached_rows = []
        uncached_rows = []

        for row in rows:
            query = row[Columns.QUERY]
            doc_id = str(row[primary_key_column])
            row_dict = row.asDict()

            if query in cached_scores and doc_id in cached_scores[query]:
                row_dict[Columns.LLM_RELEVANCE_SCORE] = cached_scores[query][doc_id]
                cached_rows.append(row_dict)
            else:
                uncached_rows.append(row_dict)

        cache_hits = len(cached_rows)
        cache_misses = len(uncached_rows)

        print(f"Found {cache_hits} cached scores, {cache_misses} to score")

        # Batch score uncached rows
        if uncached_rows:
            scored_uncached = self._score_batch(uncached_rows, primary_key_column)

            # Store new scores in cache (batch operation for efficiency)
            new_scores_by_query: dict[str, dict[str, float]] = {}
            for row in scored_uncached:
                query = row[Columns.QUERY]
                doc_id = str(row[primary_key_column])
                score = row[Columns.LLM_RELEVANCE_SCORE]
                if query not in new_scores_by_query:
                    new_scores_by_query[query] = {}
                new_scores_by_query[query][doc_id] = float(score)

            print(f"Caching {len(scored_uncached)} new scores...")
            self._cache.store_scores_batch(new_scores_by_query)

            # Combine cached and newly scored rows
            all_rows = cached_rows + scored_uncached
        else:
            all_rows = cached_rows

        print(f"Scoring complete! ({cache_misses} new LLM calls, {cache_hits} cache hits)")

        return self.spark.createDataFrame(all_rows)

    def _score_batch(
        self,
        rows_to_score: list[dict],
        primary_key_column: str
    ) -> list[dict]:
        """Score query-document pairs in batch using temp view pattern.

        Args:
            rows_to_score: List of row dicts with 'query' and 'retrieved_text'
            primary_key_column: Name of the primary key column

        Returns:
            List of row dicts with 'llm_relevance_score' added
        """
        total = len(rows_to_score)

        # Build prompts for each row
        print(f"Building prompts for {total} query-document pairs...")
        rows_with_prompts = []
        for row in rows_to_score:
            prompt = build_relevance_scoring_prompt(row[Columns.QUERY], row[Columns.RETRIEVED_TEXT])
            rows_with_prompts.append({**row, Columns.PROMPT: prompt})

        prompt_df = self.spark.createDataFrame(rows_with_prompts)

        # Batch ai_query call using temp view pattern
        temp_view_name = f"_llm_score_{id(prompt_df)}"
        prompt_df.createOrReplaceTempView(temp_view_name)

        try:
            print(f"Running batch ai_query for {total} scores...")
            result_df = self.spark.sql(f"""
                SELECT *,
                    TRIM(ai_query('{self.model_endpoint}', {Columns.PROMPT})) as {Columns.RAW_SCORE}
                FROM {temp_view_name}
            """)
            # Force materialization before dropping temp view
            results = result_df.collect()
            print(f"Batch scoring complete!")

            # Parse scores from LLM response
            scored_rows = []
            for row in results:
                row_dict = row.asDict()
                raw_score = row_dict.pop(Columns.RAW_SCORE, "0")
                row_dict.pop(Columns.PROMPT, None)  # Remove prompt column
                row_dict[Columns.LLM_RELEVANCE_SCORE] = self._parse_score(raw_score)
                scored_rows.append(row_dict)

            return scored_rows
        finally:
            self.spark.catalog.dropTempView(temp_view_name)
