"""Multi-query type evaluator for running evaluations across search modes."""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING
from pyspark.sql import DataFrame, SparkSession, Row

from .config import AutoEvalConfig
from .search_client import SearchClient
from .llm_judge import LLMJudge
from .metrics import MetricsAnalyzer, format_with_ci
from .mlflow_tracker import generate_experiment_path, MLFlowTracker
from .constants import Columns, MetricType

if TYPE_CHECKING:
    import plotly.graph_objects as go


@dataclass
class EvalResult:
    """Results for a single query type evaluation.

    Attributes:
        query_type: The search mode used (FULL_TEXT, ANN, or HYBRID)
        scored_df: DataFrame with search results and LLM relevance scores
        analyzer: MetricsAnalyzer instance with computed metrics
    """
    query_type: str
    scored_df: DataFrame
    analyzer: MetricsAnalyzer


class MultiQueryEvaluator:
    """Runs evaluation across multiple query types.

    This class encapsulates the search → score → analyze flow and runs it
    for multiple query types, enabling easy comparison across search modes.

    Example:
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"]
        ).validate()

        evaluator = MultiQueryEvaluator(config=config)
        results = evaluator.evaluate(queries_df)

        # Compare metrics across query types
        display(evaluator.compare_metrics())

        # Access individual results
        for query_type, result in results.items():
            print(result.analyzer.summary())
    """

    def __init__(self, config: AutoEvalConfig):
        """Initialize the evaluator with a validated config.

        Args:
            config: AutoEvalConfig object (must be validated via config.validate())

        Raises:
            ValueError: If config is not validated
        """
        if not config.is_validated():
            raise ValueError("Config must be validated. Call config.validate() first.")

        self.config = config
        self.experiment_path: Optional[str] = None

        self.search_client = SearchClient(config.endpoint_name, config.index_name, config.primary_key)
        self.judge = LLMJudge(
            model_endpoint=config.relevance_judge_llm_endpoint,
            index_name=config.index_name,
            query_cache_table=config.query_cache_table
        )
        self.spark = SparkSession.builder.getOrCreate()

        self.results: Dict[str, EvalResult] = {}

    def _evaluate_single(
        self,
        queries_df: DataFrame,
        query_type: str,
        reranker,
        eval_key: str,
        run_name: str
    ) -> EvalResult:
        """Run evaluation for a single query type and reranker configuration.

        Args:
            queries_df: DataFrame with 'doc_id' and 'generated_query' columns
            query_type: Search type (FULL_TEXT, ANN, HYBRID)
            reranker: Optional DatabricksReranker instance (None for no reranking)
            eval_key: Key to use in results dict (e.g., "ANN" or "ANN_reranker")
            run_name: Name for MLflow run

        Returns:
            EvalResult for this evaluation
        """
        reranker_status = " (with reranker)" if reranker else ""
        print(f"\n{'='*50}")
        print(f"Evaluating: {eval_key}")
        print(f"{'='*50}")

        # Search
        print(f"Running {query_type} search{reranker_status}...")
        results_df = self.search_client.search_batch(
            queries_df=queries_df,
            num_results=self.config.num_results,
            query_type=query_type,
            columns=self.config.columns_to_retrieve,
            embedding_model=self.config.embedding_model,
            query_cache_table=self.config.query_cache_table,
            reranker=reranker
        )

        # Score - use retrieved_doc_id for cache lookups (contains primary key value)
        print(f"Scoring {eval_key} results with LLM judge...")
        scored_df = self.judge.score_batch(
            results_df,
            primary_key_column=Columns.RETRIEVED_DOC_ID
        )

        # Analyze
        print(f"Computing metrics for {eval_key}...")
        analyzer = MetricsAnalyzer(scored_df)

        eval_result = EvalResult(
            query_type=eval_key,
            scored_df=scored_df,
            analyzer=analyzer
        )

        print(f"Completed {eval_key}: {analyzer._total} query-document pairs scored")

        # Log traces and metrics for this evaluation within an MLflow run
        if self.config.enable_mlflow_logging:
            tracker = MLFlowTracker(
                scored_df=eval_result.scored_df,
                analyzer=eval_result.analyzer,
                config=self.config,
                query_type=eval_key,
                eval_queryset_size=queries_df.count(),
                reranker_enabled=reranker is not None,
                experiment_path=self.experiment_path
            )
            run_id, _, trace_ids = tracker.log_to_mlflow(run_name=run_name)
            print(f"Logged {len(trace_ids)} traces + metrics for {eval_key} (run_id: {run_id})")

        return eval_result

    def evaluate(self, queries_df: DataFrame) -> Dict[str, EvalResult]:
        """Run evaluation for each query type (and optionally with reranker).

        When enable_reranker is True, each query type is evaluated twice:
        once without reranker and once with reranker. Results are stored
        with keys like "ANN" and "ANN_reranker" to maintain proper ordering
        for comparison tables and plots.

        Args:
            queries_df: DataFrame with 'doc_id' and 'generated_query' columns

        Returns:
            Dictionary mapping eval_key to EvalResult.
            When enable_reranker=True, includes both base types and *_reranker variants.
        """
        # Set experiment for trace/metrics logging (if tracing enabled)
        if self.config.enable_mlflow_logging:
            import mlflow
            self.experiment_path = self.config.mlflow_experiment_path or generate_experiment_path(self.config.index_name)
            experiment = mlflow.set_experiment(self.experiment_path)
            print(f"MLflow logging enabled.")
            print(f"  Experiment path: {self.experiment_path}")
            print(f"  Experiment ID: {experiment.experiment_id}")

        self.results = {}

        # Create reranker instance if enabled
        reranker_instance = None
        if self.config.enable_reranker:
            from databricks.vector_search.reranker import DatabricksReranker
            reranker_instance = DatabricksReranker(columns_to_rerank=self.config.columns_to_rerank)
            print(f"Reranker enabled with columns: {self.config.columns_to_rerank}")

        for query_type in self.config.query_types:
            # Run WITHOUT reranker first
            eval_key= query_type
            self.results[eval_key] = self._evaluate_single(
                queries_df=queries_df,
                query_type=query_type,
                reranker=None,
                eval_key=eval_key,
                run_name=f"{eval_key}_eval"
            )

            # Run WITH reranker if enabled (immediately after for proper ordering)
            if self.config.enable_reranker:
                eval_key= f"{query_type}_reranker"
                self.results[eval_key] = self._evaluate_single(
                    queries_df=queries_df,
                    query_type=query_type,
                    reranker=reranker_instance,
                    eval_key=eval_key,
                    run_name=f"{eval_key}_eval"
                )

        print(f"\nCompleted evaluation for {len(self.results)} query types.")
        if self.config.enable_mlflow_logging:
            print(f"Results logged to MLflow experiment: {self.experiment_path}")

        return self.results

    def compare_metrics(self) -> DataFrame:
        """Return DataFrame comparing key metrics across query types.

        Returns:
            DataFrame with pretty column names, values include 95% CI.
        """
        if not self.results:
            raise ValueError("No results to compare. Call evaluate() first.")

        rows = []
        for query_type, result in self.results.items():
            a = result.analyzer
            metrics = a.get_metrics()

            rows.append({
                "Query Type": query_type,
                "MRR": format_with_ci(*metrics["mrr"]),
                "Avg Relevance Score": format_with_ci(*metrics["avg_relevance_score"]),
                "Highly Relevant (score=3) %": format_with_ci(*metrics["highly_relevant_pct"]),
                "Relevant+ (score>=2) %": format_with_ci(*metrics["relevant_plus_pct"]),
                "Not Relevant (score<=1) %": format_with_ci(*metrics["not_relevant_pct"]),
            })

        return self.spark.createDataFrame([Row(**r) for r in rows])

    def _compare_metric_at_k(
        self,
        metric_label: str,
        metric_method: str,
        k_values: Optional[List[int]] = None
    ) -> DataFrame:
        """Compare a metric@k across query types.

        Args:
            metric_label: Display name for the metric (e.g., "Recall", "NDCG")
            metric_method: Name of the analyzer method to call (e.g., "recall_at_k")
            k_values: List of k values. Defaults to self.config.k_values.

        Returns:
            DataFrame with metric@k values for each query type.
        """
        if not self.results:
            raise ValueError("No results to compare. Call evaluate() first.")

        if k_values is None:
            k_values = self.config.k_values

        rows = []
        for query_type, result in self.results.items():
            # Validate the metric method exists
            if not hasattr(result.analyzer, metric_method):
                available = ["recall_at_k", "precision_at_k", "ndcg_at_k", "map_at_k", "mrr"]
                raise AttributeError(
                    f"MetricsAnalyzer has no method '{metric_method}'. "
                    f"Available methods: {available}"
                )
            method = getattr(result.analyzer, metric_method)

            row = {"Query Type": query_type}
            for k in k_values:
                value, ci_margin = method(k=k)
                row[f"{metric_label}@{k}"] = format_with_ci(value, ci_margin)
            rows.append(row)

        return self.spark.createDataFrame([Row(**r) for r in rows])

    def compare_recall(self, k_values: Optional[List[int]] = None) -> DataFrame:
        """Return DataFrame comparing recall@k across query types."""
        return self._compare_metric_at_k(MetricType.LABELS[MetricType.RECALL], "recall_at_k", k_values)

    def compare_precision(self, k_values: Optional[List[int]] = None) -> DataFrame:
        """Return DataFrame comparing precision@k across query types."""
        return self._compare_metric_at_k(MetricType.LABELS[MetricType.PRECISION], "precision_at_k", k_values)

    def compare_ndcg(self, k_values: Optional[List[int]] = None) -> DataFrame:
        """Return DataFrame comparing NDCG@k across query types."""
        return self._compare_metric_at_k(MetricType.LABELS[MetricType.NDCG], "ndcg_at_k", k_values)

    def compare_map(self, k_values: Optional[List[int]] = None) -> DataFrame:
        """Return DataFrame comparing MAP@k across query types."""
        return self._compare_metric_at_k(MetricType.LABELS[MetricType.MAP], "map_at_k", k_values)

    def compare_dcg(self, k_values: Optional[List[int]] = None) -> DataFrame:
        """Return DataFrame comparing DCG@k across query types."""
        return self._compare_metric_at_k(MetricType.LABELS[MetricType.DCG], "dcg_at_k", k_values)

    def get_result(self, query_type: str) -> EvalResult:
        """Get the result for a specific query type.

        Args:
            query_type: The query type to get results for

        Returns:
            EvalResult for the specified query type

        Raises:
            KeyError: If query_type was not evaluated
        """
        if query_type not in self.results:
            raise KeyError(
                f"No results for query_type '{query_type}'. "
                f"Available: {list(self.results.keys())}"
            )
        return self.results[query_type]

    # Plotting methods

    def plot_metrics_at_k(
        self,
        metric_type: str,
        k_values: Optional[List[int]] = None,
        **kwargs
    ) -> Optional["go.Figure"]:
        """Plot metric@k comparison across query types.

        Args:
            metric_type: One of "recall", "precision", "ndcg", "map"
            k_values: k values to plot (default: self.config.k_values)
            **kwargs: Additional args passed to plotting function (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        if not self.results:
            print("Error: No results to plot. Call evaluate() first.")
            return None
        from .plotting import plot_metrics_at_k
        return plot_metrics_at_k(
            self.results, metric_type, k_values or self.config.k_values, **kwargs
        )

    def plot_recall(self, k_values: Optional[List[int]] = None, **kwargs) -> Optional["go.Figure"]:
        """Plot recall@k comparison across query types.

        Args:
            k_values: k values to plot (default: self.config.k_values)
            **kwargs: Additional args (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        return self.plot_metrics_at_k(MetricType.RECALL, k_values, **kwargs)

    def plot_precision(self, k_values: Optional[List[int]] = None, **kwargs) -> Optional["go.Figure"]:
        """Plot precision@k comparison across query types.

        Args:
            k_values: k values to plot (default: self.config.k_values)
            **kwargs: Additional args (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        return self.plot_metrics_at_k(MetricType.PRECISION, k_values, **kwargs)

    def plot_ndcg(self, k_values: Optional[List[int]] = None, **kwargs) -> Optional["go.Figure"]:
        """Plot NDCG@k comparison across query types.

        Args:
            k_values: k values to plot (default: self.config.k_values)
            **kwargs: Additional args (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        return self.plot_metrics_at_k(MetricType.NDCG, k_values, **kwargs)

    def plot_map(self, k_values: Optional[List[int]] = None, **kwargs) -> Optional["go.Figure"]:
        """Plot MAP@k comparison across query types.

        Args:
            k_values: k values to plot (default: self.config.k_values)
            **kwargs: Additional args (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        return self.plot_metrics_at_k(MetricType.MAP, k_values, **kwargs)

    def plot_dcg(self, k_values: Optional[List[int]] = None, **kwargs) -> Optional["go.Figure"]:
        """Plot DCG@k comparison across query types.

        Note: DCG values are not normalized (unlike NDCG), so the y-axis
        auto-scales by default. Use y_range kwarg to set explicit bounds.

        Args:
            k_values: k values to plot (default: self.config.k_values)
            **kwargs: Additional args (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        return self.plot_metrics_at_k(MetricType.DCG, k_values, **kwargs)

    def plot_mrr(self, **kwargs) -> Optional["go.Figure"]:
        """Plot MRR comparison across query types.

        Args:
            **kwargs: Additional args (title, y_range)

        Returns:
            Plotly Figure or None if error
        """
        if not self.results:
            print("Error: No results to plot. Call evaluate() first.")
            return None
        from .plotting import plot_mrr
        return plot_mrr(self.results, **kwargs)

    def plot_all_metrics(self) -> List[Tuple[str, Optional["go.Figure"]]]:
        """Generate all metric plots.

        Returns:
            List of (metric_name, figure) tuples. Figures may be None if error.
            Names are: "DCG@k", "NDCG@k", "MAP@k", "MRR", "Precision@k", "Recall@k"
        """
        if not self.results:
            print("Error: No results to plot. Call evaluate() first.")
            return []

        from .plotting import plot_metrics_at_k, plot_mrr

        return [
            ("DCG@k", plot_metrics_at_k(self.results, MetricType.DCG, self.config.k_values)),
            ("NDCG@k", plot_metrics_at_k(self.results, MetricType.NDCG, self.config.k_values)),
            ("MAP@k", plot_metrics_at_k(self.results, MetricType.MAP, self.config.k_values)),
            ("MRR", plot_mrr(self.results)),
            ("Precision@k", plot_metrics_at_k(self.results, MetricType.PRECISION, self.config.k_values)),
            ("Recall@k", plot_metrics_at_k(self.results, MetricType.RECALL, self.config.k_values)),
        ]
