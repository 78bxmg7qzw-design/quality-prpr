"""Query generation using LLM with few-shot prompting."""

from __future__ import annotations

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, concat_ws, rand, lower, trim

from autoeval_lib.config import AutoEvalConfig
from autoeval_lib.constants import Columns, QueryStyle, Defaults
from autoeval_lib.prompts import (
    DEFAULT_FEW_SHOT_EXAMPLES,
    build_query_generation_prompt,
)


class QueryGenerator:
    """Generates synthetic search queries from documents using LLM.

    This class samples documents from a corpus and generates search queries
    using Databricks ai_query() with few-shot prompting.

    Example:
        config = AutoEvalConfig(
            index_name="catalog.schema.index",
            query_columns=["text"]
        ).validate()

        generator = QueryGenerator(config=config)
        samples_df = generator.sample_and_generate_examples()
        display(samples_df)

        generator.set_few_shot_examples([
            {"document": "...", "query": "..."},
            ...
        ])

        queries_df = generator.generate_queries()

        # Optional: Change query style at runtime
        generator.set_query_style("keyword")
    """

    def __init__(self, config: AutoEvalConfig):
        """Initialize the QueryGenerator with a validated config.

        Args:
            config: AutoEvalConfig object (must be validated via config.validate())

        Raises:
            ValueError: If config is not validated
        """
        if not config.is_validated():
            raise ValueError("Config must be validated. Call config.validate() first.")

        self.config = config
        self.spark = SparkSession.builder.getOrCreate()

        # Initialize few_shot_examples in config if not provided
        if not config.few_shot_examples:
            config.few_shot_examples = DEFAULT_FEW_SHOT_EXAMPLES.copy()

    def set_query_style(self, query_style: str) -> None:
        """Change the query style for subsequent query generation.

        Args:
            query_style: One of "natural", "keyword", or "mixed"

        Raises:
            ValueError: If query_style is not valid
        """
        if query_style.lower() not in QueryStyle.VALID:
            raise ValueError(
                f"query_style must be one of {QueryStyle.VALID}, got '{query_style}'"
            )
        self.config.query_style = query_style.lower()

    def _sample_documents(
        self,
        corpus_table: str,
        columns: list[str],
        num_samples: int
    ) -> DataFrame:
        """Sample random documents from the corpus.

        Args:
            corpus_table: Fully qualified Delta table name
            columns: List of column names to concatenate for doc_text
            num_samples: Number of documents to sample

        Returns:
            DataFrame with primary_key and doc_text columns
        """
        # Get actual primary key column name from config
        primary_key = self.config.primary_key

        # Read table
        df = self.spark.read.table(corpus_table)

        # Build doc_text column from specified columns
        if len(columns) == 1:
            df = df.withColumn(Columns.DOC_TEXT, col(columns[0]))
        else:
            df = df.withColumn(Columns.DOC_TEXT, concat_ws(" ", *[col(c) for c in columns]))

        # Use deterministic random ordering based on primary key hash + seed
        # This ensures the same seed always produces the same sample,
        # regardless of partitioning or read order
        if self.config.random_seed is not None:
            # Hash primary key combined with seed for deterministic ordering
            from pyspark.sql.functions import hash as spark_hash, lit
            rand_col = spark_hash(col(primary_key), lit(self.config.random_seed))
        else:
            rand_col = rand()

        result_df = (
            df
            .select(primary_key, Columns.DOC_TEXT)
            .orderBy(rand_col)
            .limit(num_samples)
        )

        return result_df

    def sample_and_generate_examples(self) -> DataFrame:
        """Sample documents and generate example queries for user review.

        Generates both natural language and keyword-style queries for each
        sampled document so the user can see different query styles.
        Uses batch ai_query() calls for better performance.

        Returns:
            DataFrame with columns: primary_key, text_preview, natural_query, keyword_query
        """
        corpus_table = self.config.corpus_table
        columns = self.config.query_columns
        num_samples = self.config.num_samples
        primary_key = self.config.primary_key

        sample_df = self._sample_documents(corpus_table, columns, num_samples)

        # Materialize sample_df to ensure both query styles use the same documents
        # (Without this, lazy evaluation with rand() would sample different docs each time)
        sample_df = self.spark.createDataFrame(sample_df.collect())

        # Generate both styles using batch
        print("Generating natural language queries...")
        natural_df = self._batch_generate_queries(sample_df, style=QueryStyle.NATURAL)
        natural_df = natural_df.withColumnRenamed(Columns.GENERATED_QUERY, Columns.NATURAL_QUERY)

        print("Generating keyword queries...")
        keyword_df = self._batch_generate_queries(sample_df, style=QueryStyle.KEYWORD)
        keyword_df = keyword_df.withColumnRenamed(Columns.GENERATED_QUERY, Columns.KEYWORD_QUERY)

        # Join the two DataFrames on primary_key
        result_df = (
            natural_df.select(
                primary_key,
                col(Columns.DOC_TEXT).alias(Columns.TEXT_PREVIEW),
                Columns.NATURAL_QUERY
            )
            .join(keyword_df.select(primary_key, Columns.KEYWORD_QUERY), on=primary_key)
        )

        print("Example generation complete!")

        return result_df

    def set_few_shot_examples(self, examples: list[dict[str, str]]) -> None:
        """Set custom few-shot examples for query generation.

        Args:
            examples: List of dicts with "document" and "query" keys

        Raises:
            ValueError: If examples are not properly formatted
        """
        if not examples:
            raise ValueError("examples must not be empty")

        for i, ex in enumerate(examples):
            if "document" not in ex or "query" not in ex:
                raise ValueError(f"Example {i} must have 'document' and 'query' keys")

        self.config.few_shot_examples = examples
        print(f"Set {len(examples)} custom few-shot examples")

    def generate_queries(self) -> DataFrame:
        """Generate queries at scale from the corpus.

        Uses batch ai_query() calls for better performance.
        Generates extra queries to account for duplicates and invalid queries,
        then filters and deduplicates to return up to num_queries unique queries.

        Returns:
            DataFrame with columns: primary_key, doc_text, generated_query
        """
        corpus_table = self.config.corpus_table
        columns = self.config.query_columns
        num_queries = self.config.num_queries
        style = self.config.query_style

        # Generate extra queries to account for duplicates and invalid queries
        buffer_fraction = Defaults.QUERY_GENERATION_BUFFER_FRACTION
        num_to_generate = int(num_queries * (1 + buffer_fraction))

        sample_df = self._sample_documents(corpus_table, columns, num_to_generate)

        # Use batch generation
        result_df = self._batch_generate_queries(sample_df, style)

        # Filter out invalid queries
        valid_df = result_df.filter(
            (trim(lower(col(Columns.GENERATED_QUERY))) != "none") &
            (trim(col(Columns.GENERATED_QUERY)) != "")
        )

        # Deduplicate by generated_query text (keep first occurrence)
        deduped_df = valid_df.dropDuplicates([Columns.GENERATED_QUERY])

        # Limit to requested number of queries
        final_df = deduped_df.limit(num_queries)

        valid_count = final_df.count()
        print(f"Query generation complete! Generated {valid_count} valid unique queries.")

        return final_df

    def _batch_generate_queries(self, sample_df: DataFrame, style: str) -> DataFrame:
        """Generate queries in batch using temp view pattern.

        Args:
            sample_df: DataFrame with primary_key and doc_text columns
            style: "natural", "keyword", or "mixed"

        Returns:
            DataFrame with primary_key, doc_text, and generated_query columns
        """
        primary_key = self.config.primary_key
        rows = sample_df.collect()
        total = len(rows)

        # Build prompts for each document
        print(f"Building prompts for {total} documents...")
        rows_with_prompts = []
        for i, row in enumerate(rows):
            # Determine style for this query (for mixed mode)
            if style == QueryStyle.MIXED:
                query_style = QueryStyle.NATURAL if i % 2 == 0 else QueryStyle.KEYWORD
            else:
                query_style = style

            prompt = build_query_generation_prompt(
                doc_text=row[Columns.DOC_TEXT],
                few_shot_examples=self.config.few_shot_examples,
                style=query_style
            )
            rows_with_prompts.append({
                primary_key: row[primary_key],
                Columns.DOC_TEXT: row[Columns.DOC_TEXT],
                Columns.PROMPT: prompt
            })

        prompt_df = self.spark.createDataFrame(rows_with_prompts)

        # Batch ai_query call using temp view pattern
        temp_view_name = f"_query_gen_{id(prompt_df)}"
        prompt_df.createOrReplaceTempView(temp_view_name)

        try:
            print(f"Running batch ai_query for {total} queries...")
            result_df = self.spark.sql(f"""
                SELECT
                    `{primary_key}`,
                    `{Columns.DOC_TEXT}`,
                    TRIM(ai_query('{self.config.query_generation_llm_endpoint}', `{Columns.PROMPT}`)) as `{Columns.GENERATED_QUERY}`
                FROM {temp_view_name}
            """)
            # Force materialization before dropping temp view
            materialized = result_df.collect()
            print(f"Batch generation complete!")
            return self.spark.createDataFrame(materialized)
        finally:
            self.spark.catalog.dropTempView(temp_view_name)
